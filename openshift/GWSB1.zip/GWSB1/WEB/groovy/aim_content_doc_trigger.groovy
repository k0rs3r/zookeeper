import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){;
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		//TEMPORANEO, ELIMINARE QUANDO IL WIDGET CON I CONTENUTI DI TIPO DOCUMENTO FUNZIONA
		log.info("valuesMap:   "+valuesMap);
		def idDoc = valuesMap.get("id_doc");
		
		def fileName = valuesMap.get("file_name");
		
		if(fileName!=null){
			def selectCodContent = "select cod_content from aim_content_doc where id_doc="+idDoc;
			def select = services.queryService.executeQuery(selectCodContent,null);
			log.info("select cod document: "+select);
			def codContent = select[0].cod_content;
			def contentHM = [:];
			contentHM.cod_content = codContent;
			def updateContent = "UPDATE AIM_CONTENT SET is_uploaded=1,upload_date=CURRENT_TIMESTAMP where cod_content=#{map.cod_content}";
			def ins = services.queryService.executeQuery(updateContent,contentHM);	
			
		}
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 