//user:    APA
//date:    10/10/2019
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_bim_model_structure
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		//se la struttura di modello è associata ad un drawing => deve essere creato il layout corrispondente, se non esiste
		
		def system = valuesMap.system;
		def query = "SELECT COD_SYSTEM_TYPE, DRAWING_TYPE FROM GWD_BIM_SYSTEM WHERE COD_SYSTEM_TYPE = #{map.system}";
		def map = [:];
		map.system = system;
		def select = services.queryService.executeQuery(query, map);
		
		if(select==null || select.size()==0){
			throw new RuntimeException("ATTENZIONE! Modello dati corrotto, non esiste il system associato alla struttura di modello");
		}
		log.info("loggo il system APA: "+valuesMap.system);
		log.info("loggo il project APA: "+valuesMap.project);
		log.info("loggo il level APA: "+valuesMap.level);
		if(select[0].drawing_type!=null){
			def project = valuesMap.project;
			def level = valuesMap.level;
			def layoutMap = [:];
			
			def layoutQuery = null;
			def tenantCode = valuesMap.tenant_code;
			if(tenantCode!=null){
				layoutMap.tenant_code = tenantCode;
				layoutMap.layout_code = tenantCode+"_"+project+"_"+level;
				layoutQuery = "SELECT PK_LAYOUT FROM GWD_LAYOUT WHERE LAYOUT_CODE = #{map.layout_code} AND layout_type='2D' AND TENANT_CODE = #{map.tenant_code}";
			} else{
				layoutMap.layout_code = project+"_"+level;
				layoutQuery = "SELECT PK_LAYOUT FROM GWD_LAYOUT WHERE LAYOUT_CODE = #{map.layout_code} AND layout_type='2D'";
			}
			
			def selectLayout = services.queryService.executeQuery(layoutQuery, layoutMap);
			log.info("sono dentro al alyuyh: "+selectLayout);
			if(selectLayout==null || selectLayout.size()==0){
				log.info("sono dentro");
				//il layout corrisponde alla concatenzione tra progetto e livello
				layoutMap.put("layout_label",layoutMap.layout_code);
				layoutMap.put("layout_type",'2D');
				def pkLayout = services.classService.insertClassRecord('gwd_layout',layoutMap);
				log.info("loggo il pklayout ABA: "+pkLayout);
				def drawingSet = [:];
				drawingSet.drawing_set_code = layoutMap.layout_code;
				drawingSet.drawing_set_label = "Default Drawing Set per "+layoutMap.layout_code;
				drawingSet.map = "bimDataMap";
				drawingSet.is_default = 1;
				drawingSet.fk_layout = pkLayout;
				services.classService.insertClassRecord('gwd_drawing_set',drawingSet);
				
			}
		}
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	    return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 