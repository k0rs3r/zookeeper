import com.geowebframework.dataservice.model.GwHeaderClassInfo;
import org.apache.commons.lang.StringUtils;
import com.geowebframework.dataservice.service.GwImportUtilService;
import com.geowebframework.dataservice.service.GwClassListService;
import java.lang.RuntimeException;
import org.apache.commons.lang.StringUtils;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImportHandlerExt extends com.geowebframework.dataservice.service.ImportHandler  {
	
	
	public boolean beforeImport(){
		
				
		return true;
	};
	
	/**
	 * Function for crud operations of class data in file row
	 *
	 *
	 * @param  headerClasses 		(required) 	Processed header classes by {@link #handleClassHeaders(String[], String, String, String)}
	 * @param  row 					(required)  row 
	 * @param  mainClassName 		(required) 	Main class name
	 * @param  mainRecordParent 	(optional) 	Parent record of main class, null if optional
	 * @param  mainAdditionalMap 	(optional) 	Additional info for main class, null if optional
	 * @param  importType 			(required)  Information concerning main class crud operations
	 * @param  locale 				(optional)	locale
	 * @param  codColumnsSplitted 	(optional)	Column codes for selectClassRecordByCodeList filters
	 * @param  projectName 			(required)  Project Name
	 * @return      a List<String> representing keys of created/updated data
	 *
	 */
	public boolean handle(
			HashMap<String, GwHeaderClassInfo> headerClasses, 
			Map<String, String> row,  //riga csv
			String mainClassName,
			HashMap<String, Object> mainRecordParent,
			HashMap<String, Object> mainAdditionalMap,
			Integer importType,
			Locale locale,
			String[] codColumnsSplitted,
			String projectName
		) throws Exception {
			
			
			
			log.info("<BR>\n row caricate"+row);
			log.info("ARCHIVIO:"+row.cod_class_arc);
			log.info("CATEGORIA:"+row.cod_class_cat);
			log.info("SOTTOCATEGORIA:"+row.cod_class_subcat);
			
			
				//CONTROLLO SE HA L ARCHIVIO PRIMA DI INSERIRLA ALTRIMENTI MANDO ERRORE
				HashMap<String, Object> objRecordArchivio = services.classService.selectClassRecordByCode("aim_class_archive", row.cod_class_arc, "name_class_arc");
				def cod_class_arc=null;
				if(objRecordArchivio!=null && objRecordArchivio.cod_class_arc){
					cod_class_arc=objRecordArchivio.cod_class_arc;
				}else{
					/*def insertMapArc=[:];
					insertMapArc.name_class_arc=row.archivio;
					def itemId=services.classService.insertClassRecord('aim_class_archive',insertMapArc);
					HashMap<String, Object> arcNew=services.classService.selectClassRecord("aim_class_archive", itemId);
					cod_class_arc=arcNew.cod_class_arc;*/
					def messageErr="Archivio inesistente!";
					throw new RuntimeException(messageErr);
					return false;
				}
				
				//CONTROLLO SE HA LA CATEGORIA PRIMA DI INSERIRLA ALTRIMENTI INSERISCO PRIMA LA CATEGORIA
				//HashMap<String, Object> objRecordCategory = services.classService.selectClassRecordByCode("aim_class_category", row.cod_class_cat, "name_class_cat");
				HashMap<String, Object> objRecordCategory =services.queryService.executeQuery("select * from aim_class_category where name_class_cat=#{map.name_class_cat} and cod_class_arc=#{map.cod_class_arc}",[name_class_cat:row.cod_class_cat,cod_class_arc:cod_class_arc]);
				def cod_class_cat=null;
				if(objRecordCategory!=null && objRecordCategory.cod_class_cat){
					cod_class_cat=objRecordCategory.cod_class_cat;
				}else{
					def queryRecRec=" select coalesce(max(CAST(RIGHT(cod_class_cat, CHARINDEX('.', REVERSE(cod_class_cat)) - 1) as int))+ 1,1) as prog  FROM AIM_CLASS_CATEGORY where cod_class_arc=#{map.cod_class_arc}";
					def record_conta_obj =services.queryService.executeQuery(queryRecRec,[cod_class_arc:cod_class_arc]);
					def cod_class_cat_calc=cod_class_arc+"."+StringUtils.leftPad("" + record_conta_obj[0].prog, 2, "0");
					def insertMapCat=[:];
					insertMapCat.name_class_cat=row.cod_class_cat;
					insertMapCat.cod_class_arc=cod_class_arc;
					insertMapCat.cod_class_cat=cod_class_cat_calc;
					log.info("CATEGORIA HASHMAP INSERITO "+insertMapCat);
					def itemId=services.classService.insertClassRecord('aim_class_category',insertMapCat);
					HashMap<String, Object> catNew=services.classService.selectClassRecord("aim_class_category", itemId);
					cod_class_cat=catNew.cod_class_cat;
				}
				// FATTO TUTTO INSERISCO LA SOTTOCATEGORIA SE NON PRESENTE
				def queryControllaSottocategoria=" select cod_class_subcat FROM AIM_CLASS_SUBCATEGORY where cod_class_cat=#{map.cod_class_cat} and name_class_subcat=#{map.cod_class_subcat}";
				def record_controlla_sottocategoria =services.queryService.executeQuery(queryControllaSottocategoria,[cod_class_cat:cod_class_cat,cod_class_subcat:row.cod_class_subcat]);
				//HashMap<String, Object> objRecordSubcategory = services.classService.selectClassRecordByCode("aim_class_subcategory", row.cod_class_subcat, "name_class_subcat");
				//if(objRecordSubcategory!=null && objRecordSubcategory.cod_class_subcat){
				if(record_controlla_sottocategoria!=null && record_controlla_sottocategoria.cod_class_subcat){
					def messageErr="Sottocategoria già presente!";
					throw new RuntimeException(messageErr);
					return false;
				}else{
					//COSTRUISCO IL MENMONIC CODE
					def queryRecRec2=" select coalesce(max(CAST(RIGHT(cod_class_subcat, CHARINDEX('.', REVERSE(cod_class_subcat)) - 1) as int))+ 1,1) as prog FROM AIM_CLASS_SUBCATEGORY where cod_class_cat=#{map.cod_class_cat}";
					def record_conta_obj2 =services.queryService.executeQuery(queryRecRec2,[cod_class_cat:cod_class_cat]);
					def cod_class_subcat_calc=cod_class_cat+"."+StringUtils.leftPad("" + record_conta_obj2[0].prog, 2, "0");
						
					//INSERISCO CON IL METODO DELL IMPORTAZIONE
						row.cod_class_cat=cod_class_cat;
						row.name_class_subcat=row.cod_class_subcat;
						row.cod_class_subcat=cod_class_subcat_calc;
						//row.cod_class_arc=cod_class_arc;
						return (((GwImportUtilService) services.get("gwImportUtilService")).doHeaderClassesCrudOperations(
						headerClasses, 
						row,
						mainClassName,
						mainRecordParent,
						mainAdditionalMap,
						importType,
						locale,
						codColumnsSplitted,
						projectName)!=null);
						//log.info("RISPOSTA:"+res);
						//return res;
				}
			
		}
	
	public boolean afterImport(HashMap<String, Object> additionalMap){
		
		return true;
	};
	
}