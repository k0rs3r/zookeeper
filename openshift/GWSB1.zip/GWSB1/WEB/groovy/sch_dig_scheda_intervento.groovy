public class sch_dig_scheda_intervento extends com.geowebframework.transfer.objects.digitaldocument.GwDigitalDocumentConfigImpl {
	
	public Boolean isVisible(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){

		log.error("templateName: "+templateName);
		log.error("sectionName: "+sectionName);
		log.error("entityName: "+entityName);
		log.error("entityStatus: "+entityStatus);
		def isVisible = false;
		if(templateName.equals("sch_dig_scheda_intervento")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("INT_TRAINANTI")||
				sectionName.equals("INT_TRAINATI")||
				sectionName.equals("INT_ALTRO")||
				sectionName.equals("DATI_GEST")
			)
				{
					isVisible = true;
					log.error("isVisible = true");
				}
			
		}
		log.error("isVisible: "+isVisible);
		return isVisible;
	}
	public Boolean isEditable(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isEditable = false;
		if(templateName.equals("sch_dig_scheda_intervento")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("INT_TRAINANTI")||
				sectionName.equals("INT_TRAINATI")||
				sectionName.equals("INT_ALTRO")||
				sectionName.equals("DATI_GEST")
			)
				{
					isEditable = true;
				}
			
		}
		return isEditable;
	}
	
	public Boolean isDefaultSelected(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isDefaultSelected = false;
		return isDefaultSelected;
	}

}