//user:    MPE 
//date:    14/01/2017
//ver:     4.2.5
//project: cde
//type:    event trigger (TRIGGER DI CLASSE)
//class:   cde_01_project
//note:    il groovy effettua le seguenti operazioni:
//         controllo del parametro di licenza Numero Risorse
//         controllo codice istat comune (per import CSV)
//         calcolo del codice immobile
//         valorizzazione codice stato fabbricato
//         calcola geometria a partire dalle coordinate
//         ecc. ecc.

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


import org.apache.commons.lang.StringUtils;


public class aim_building_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
	
		// RECUPERO TIPO DI DATABASE
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);

		// RECUPERO UTENTE IN SESSIONE (controllo per import CSV)
		def curr_user = valuesMap.get("curr_user");
		log.info("utente corrente: " +curr_user);
		
		// RECUPERO CODICE ISTAT COMUNE (controllo per import CSV)
		def cod_istat = valuesMap.get("cod_city");
		log.info("codice istat del comune: " + cod_istat);

		// CONTROLLO SE IL CODICE ISTAT ESISTE IN ARCHIVIO
		// verifico se esiste il codice istat nella tabella dei comuni
		def check_city = services.queryService.executeQuery("SELECT COUNT(1) as check_city FROM aim_tab_city WHERE cod_city='" + cod_istat + "'",null)[0].check_city;
		log.info("flag di esistenza codice istat del comune: " + check_city);

		// se il codice non esiste, blocco inserimento e visualizzo messaggio di errore
		if (check_city==0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='L\'immobile non puo\' essere inserito.<br>';			
			def warning_check ='Il codice istat del comune di ubicazione non esiste nell\'archivio dei comuni. <br>Verificare che il codice istat sia stato scritto correttamente.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
			
			
		}
			
		// SE IL CODICE ESISTE, CALCOLO IL CODICE DELL'IMMOBILE
		else if (check_city>0){
			// istanzio la variabile del progressivo e del codice 
			def prog = null;
			def cod = null;
			
			// conto il numero di immobile per comune
			def num_rec = services.queryService.executeQuery("SELECT count(1) AS num_rec FROM gwd_building WHERE cod_city='" + cod_istat + "'",null)[0].num_rec;
			log.info("numero record: " + num_rec); 
			
			// se il conteggio è pari a zero, allora assegno al progressivo il valore 1
			if (num_rec==0){prog = 1}
			
			// se il conteggio è maggiore di zero, allora assegno al progressivo il valore max prog + 1
			else if (num_rec>0){
				// recupero il max
				def max_prog = services.queryService.executeQuery("SELECT MAX(prog_building) AS max_prog FROM gwd_building WHERE cod_city='" + cod_istat + "'",null)[0].max_prog;
				log.info("numero record: " + max_prog);
				// valorizzo il progressivo
				prog = max_prog + 1;			
				};
			
			// calcolo il codice dell'immobile (prefisso SB + codice istat comune + progressivo a 6 caratteri)
			cod = "SB" + cod_istat + StringUtils.leftPad(prog.toString(), 6, "0");
			log.info("codice immobile: " + cod);
				
			// valorizzo il codice ed il progressivo
			valuesMap.put("cod_building",cod);	
			valuesMap.put("prog_building",prog);			
			
			// valorizzo lo stato del fabbricato con PREVENTIVATO
			valuesMap.put("cod_folder_status",'PRO');			
			
			
			// STORICIZZO INSERIMENTO NUOVO FABBRICATO
			
			// definisco oggetto di inserimento
			def ins_action = [:];
			ins_action.cod_building = cod;
			ins_action.date_action = new Date();
			ins_action.user_action = valuesMap.curr_user;
			ins_action.type_action = 'INSERIMENTO';
			ins_action.note = 'Inserimento Immobile ' + cod + ' - Stato PREVENTIVATO';
			log.info("mappa di inserimento: " + ins_action);
			
			// inserisco il record
			services.classService.insertClassRecord("aim_folder_action",ins_action);			
			
			};
		

		
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	
		// RECUPERO TIPO DI DATABASE
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);


		// CALCOLO DELLA GEOMETRIA A PARTIRE DALLA COPPIA DI COORDINATE
		
		// recupero valori
		def cx = valuesMap.get("coord_x");
		def cy = valuesMap.get("coord_y");
		def pk_rec = valuesMap.id;
		log.info("coordinate X-Y " + cx + "; " +  cy + " del record " + pk_rec);
	
		// se le coordinate sono non nulle calcolo la geometria (query diretta su database, SRID 4326)
		if (cx!=null && cy != null) {
			// eseguo query di update geometria (SQL SERVER)
			if (db_type=='SQLServer'){
				def upd_geometry_ss = services.queryService.executeQuery("UPDATE gwd_building set geometry = geometry::STGeomFromText('POINT(' + CAST(CAST(coord_x AS decimal(18, 7)) AS varchar)+ ' '  + CAST(CAST(coord_y AS decimal(18, 7)) AS varchar) + ')', 4326) WHERE id_building=" + pk_rec,null);
				}
			// eseguo query di update geometria (Postgres)
			else if (db_type=='Postgres'){
				def upd_geometry_pos = services.queryService.executeQuery("UPDATE gwd_building set geometry = ST_MakePoint(coord_x, coord_y) WHERE id_building=" + pk_rec,null);	
				};
			};	
			
			
		// INSERISCO NELLA TABELLA DI ASSOCIAZIONE AI FILTRI

		// recupero classificazione immobile
		def cod_building_class = valuesMap.cod_building_classification;
		log.info("classificazione immobile: " + cod_building_class);
		
		// recupero ambito gestionale immobile
		def cod_geo_filter = valuesMap.cod_territorial_area;
		log.info("ambito gestionale immobile: " + cod_geo_filter);
		
		// definisco query per ricerca filtri
		def query_filter = "SELECT cod_bim_filter FROM aim_bim_filter WHERE ";
		// seleziono filtri che non parzializzato per classificazione/ambito
		query_filter = query_filter + "type_select_building is null ";
		// seleziono i filtri che parzializzano solo per ambito
		query_filter = query_filter + " OR type_select_building='A' and cod_geo_filter='" + cod_geo_filter + "'";
		// selezioni i filtri che parzializzano solo per classificazione immobile
		query_filter = query_filter + " OR type_select_building='C' and cod_building_class='" + cod_building_class + "'";
		// seleziono i filtri che parzializzano per ambito e classificazione
		query_filter = query_filter + " OR type_select_building='M' and cod_geo_filter='" + cod_geo_filter + "' and cod_building_class='" + cod_building_class + "'"
        log.info("query per ricerca filtri: " + query_filter);
		// eseguo query per ricerca filtri
		def list_filter = services.queryService.executeQuery(query_filter,null);
		log.info("elenco dei filtri di interesse: " + list_filter);
		
		// se la lista non è vuota, allora inserisco nella tabella di relazione
		if (list_filter!=null && list_filter.size()>0){
			// ciclo inserimento
			for (int i=0; i<list_filter.size(); i++){
				// definisco oggetto di inserimento
				def ins_fil = [:];
				ins_fil.cod_building = valuesMap.cod_building;
				ins_fil.cod_bim_filter = list_filter[i].cod_bim_filter;
				log.info("mappa di inserimento: " + ins_fil);
				services.classService.insertClassRecord("aim_bim_filter_r_building",ins_fil);
				};		
			};	
			
			
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		// RECUPERO TIPO DI DATABASE
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);

		// GENERO MAPPA TOTALE          
        def AllMap = [:] ;
        AllMap.putAll(oldvaluesMap);
        AllMap.putAll(valuesMap);

		// CALCOLO DELLA GEOMETRIA A PARTIRE DALLA COPPIA DI COORDINATE

		// SE UTENTE HA MODIFICATO LE COORDINATE
		if (valuesMap.get("coord_x")!=null || valuesMap.get("coord_y")!=null){
			
			// recupero valori
			def cx = AllMap.get("coord_x");
			def cy = AllMap.get("coord_y");
			def pk_rec = AllMap.id_building;
			log.info("coordinate X-Y " + cx + "; " +  cy + " del record " + pk_rec);			
			
			// se le coordinate sono non nulle calcolo la geometria (query diretta su database)
			if (cx!=null && cy != null) {
				if (db_type=='SQLServer'){
					// eseguo query di update geometria (SQL SERVER)
					def upd_geometry_ss = services.queryService.executeQuery("UPDATE gwd_building set geometry = geometry::STGeomFromText('POINT(' + CAST(CAST(coord_x AS decimal(18, 7)) AS varchar)+ ' '  + CAST(CAST(coord_y AS decimal(18, 7)) AS varchar) + ')', 4326) WHERE id_building=" + pk_rec,null);
				}
				else if (db_type=='Postgres'){
					// eseguo query di update geometria (POSTRGRES)
					def upd_geometry_pos = services.queryService.executeQuery("UPDATE gwd_building set geometry = ST_MakePoint(coord_x, coord_y) WHERE id_building=" + pk_rec,null);	
					};
				};				
			};
			
			
			// VERIFICO SE UTENTE HA CAMBIATO VALORI DI AMBITO/CLASSIFICAZIONE
			if (valuesMap.get("cod_building_classification")!=null || valuesMap.get("cod_territorial_area")!=null){
								
				// cancello dalla tabella di associazione filtri-immobili i record per l'immobile
				def del_r_filter = services.queryService.executeDeleteQuery("DELETE FROM aim_bim_filter_r_building WHERE cod_building='" + AllMap.cod_building + "'",null);
				
				// recupero valore corrente per classificazione immobile
				def cod_building_class = AllMap.cod_building_classification;
				log.info("classificazione immobile: " + cod_building_class);				
				
				// recupero valore corrente per ambito gestionale
				def cod_geo_filter = AllMap.cod_territorial_area;
				log.info("ambito gestionale immobile: " + cod_geo_filter);

				// definisco query per ricerca filtri
				def query_filter = "SELECT cod_bim_filter FROM aim_bim_filter WHERE ";
				// seleziono filtri che non parzializzato per classificazione/ambito
				query_filter = query_filter + "type_select_building is null ";
				// seleziono i filtri che parzializzano solo per ambito
				query_filter = query_filter + " OR type_select_building='A' and cod_geo_filter='" + cod_geo_filter + "'";
				// selezioni i filtri che parzializzano solo per classificazione immobile
				query_filter = query_filter + " OR type_select_building='C' and cod_building_class='" + cod_building_class + "'";
				// seleziono i filtri che parzializzano per ambito e classificazione
				query_filter = query_filter + " OR type_select_building='M' and cod_geo_filter='" + cod_geo_filter + "' and cod_building_class='" + cod_building_class + "'"
				log.info("query per ricerca filtri: " + query_filter);
				// eseguo query per ricerca filtri
				def list_filter = services.queryService.executeQuery(query_filter,null);
				log.info("elenco dei filtri di interesse: " + list_filter);
				
				// se la lista non è vuota, allora inserisco nella tabella di relazione
				if (list_filter!=null && list_filter.size()>0){
					// ciclo inserimento
					for (int i=0; i<list_filter.size(); i++){
						// definisco oggetto di inserimento
						def ins_fil = [:];
						ins_fil.cod_building = AllMap.cod_building;
						ins_fil.cod_bim_filter = list_filter[i].cod_bim_filter;
						log.info("mappa di inserimento: " + ins_fil);
						services.classService.insertClassRecord("aim_bim_filter_r_building",ins_fil);
						};		
					};		
				};
			
	
        return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){

		// recupero chiave record
		def pk_rec = valuesMap.get("id_building");
		log.info("chiave del record: " + pk_rec);
		
		// recupero codice univoco del record
		def cod_rec = services.queryService.executeQuery("SELECT cod_building AS cod_rec FROM gwd_building WHERE id_building=" + pk_rec, null)[0].cod_rec;
		log.info("codice univoco del record: " + cod_rec);

		// associo le info alla mappa per after delete
		valuesMap.cod_record=cod_rec;
        log.info("chiave univoca recofd in cancellazione: " + valuesMap.cod_record);
		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){

		// recupero codice da mappa
		  def cod_record = valuesMap.cod_record;
		
		// ripulisco la tabella delle azioni associate all'immobile AIM_FOLDER_ACTION
		def del_action = services.queryService.executeDeleteQuery("DELETE FROM aim_folder_action WHERE cod_building='" + cod_record + "'",null);
		
		// ripulisco tabella dei filtri associati all'immobile aim_bim_filter_r_building
		def del_r_filter = services.queryService.executeDeleteQuery("DELETE FROM aim_bim_filter_r_building WHERE cod_building='" + cod_record + "'",null);
		
		
        return true;
    };

};