//user:    MPE 
//date:    08/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    class groovy
//class:   aim_sch_fasc_fabbricato_qc
//note:    il groovy effettua le seguenti operazioni
//         recupera lista delle consistenze dalla tabella di configurazione AIM_SCH_FASC_FABBRICATO_QC_MOD
//         scrive le consistenze recuperatw nella tabella di lista AIM_SCH_FASC_FABBRICATO_QC_CON
//         aggiorna lo stato di completamento su contenuto collegato


public class aim_sch_fasc_fabbricato_qc_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		// RECUPERO IL CODICE DEL CONTENUTO
		def cod_cont = valuesMap.get("cod_content");
		log.info("codice del contenuto: " + cod_cont);

		// RECUPERO LISTA DELLE CONSISTENZE DALLA TABELLA DI CONFIGURAZIONE
		def list_int = services.queryService.executeQuery("SELECT * FROM aim_sch_fasc_fabbricato_qc_mod",null);
		log.info("elenco degli interventi: " + list_int);

		// SE LA LISTA NON E' VUOTA, CICLO INSERIMENTO NELLA TABELLA DELLE CONSISTENZE ASSOCIATE AL CONTENUTO
		if (list_int!=null && list_int.size()>0){
			// ciclo for
			for (int i=0; i<list_int.size(); i++){
				// definisco oggetti di inserimento
				def ins_rec = [:];
				ins_rec.cod_content = cod_cont;
				ins_rec.categoria = list_int[i].categoria;
				ins_rec.tipologia = list_int[i].tipologia;
				ins_rec.ord = list_int[i].ord;
				log.info("mappa di inserimento: " + ins_rec) ;
				// inserisco il record (uso una delle 4 classi)
				services.classService.insertClassRecord("aim_sch_fasc_fabbricato_qc_con_sv", ins_rec);
				
			};
		};		
		
		
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

	//GENERO MAPPA TOTALE
	def AllMap = [:] ;
	AllMap.putAll(oldvaluesMap);
	AllMap.putAll(valuesMap);
		
	// recupero codice contenuto
	def cod_content = AllMap.get("cod_content");
	log.info("codice del contenuto: " + cod_content);	
	
	// recupero valore del flag di compilazione
	def is_sch_complete = AllMap.get("is_sch_complete");
	log.info("flag di contenuto completato: " + is_sch_complete);	
	
	// se il flag di compilazione è passato da 0 a 1, allora dichiaro il contenuto completato
	if (valuesMap.is_sch_complete!=null && valuesMap.is_sch_complete==1){		
		// eseguo query di aggiornamento
		services.queryService.executeQuery("UPDATE aim_content SET is_sch_complete=1 WHERE cod_content='" + cod_content + "'",null);	
		};

	// valorizzo la data di ultima modifica con la data corrente
	valuesMap.put("upload_date",new Date());
		
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 