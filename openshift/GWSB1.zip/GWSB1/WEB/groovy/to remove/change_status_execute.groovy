//user:    MPE 
//date:    24/11/2020
//ver:     4.4.7
//project: AIM-SUPERBONUS
//type:    workflow
//class action:   multipla
//class process:   aim_wpi_change_status
//note:    groovy per l'esecuzione del processo di cambio stato di un elaborato (AZIONI IN DETTAGLIO E IN LISTA)



import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument; 
import org.springframework.context.i18n.LocaleContextHolder;

def msg_email="";
boolean almenoUnContenuto = false;
def locale = LocaleContextHolder.getLocale();

// recupero chiave (id_document) del documento per cui effettuare l'aggiornamento
log.info("AIM_CHANGE_STATUS:start info document updating for process n. " + execution.getProcessInstanceId()); 
def id_change_status=queryService.executeQuery("SELECT * FROM aim_wpi_change_status WHERE ACT_PID='"+ execution.getProcessInstanceId().toString()+"'",null)[0];
def query_rec = queryService.executeQuery("select * from aim_wpi_content_r_proc where id_change_status="+id_change_status.id_change_status+"",null);
log.info("AIM_CHANGE_STATUS:mappa query_rec "+query_rec);

//--------------------------------------------------------------tutto ok--------------------------------------------------------------------------------------------------------
//DEFINISCO LE VARIABILI CHE ANDRò AD UTILIZZARE
Boolean invio_singolo = null;
def query_cont = null;
def track = null;
def status = null;
def rec_upd = [:];


//INIZIO A CALCOLARE IL CAMBIO STATO: SE CI SONO CONTENUTI COLLEGATI AL PROCESSO PROCEDO!
if(query_rec!=null){
	invio_singolo = query_rec.size()==1;
	log.info("AIM_CHANGE_STATUS:invio_singolo: "+invio_singolo);
	//VALUTO TUTTI I CONTENUTI INTERESSATI DALLA SELEZIONE DEL CAMBIO STATO
	for(int i=0; i<query_rec.size(); i++){
		//RECUPERO TUTTE LE INFO RELATIVE AI CONTENUTI
		query_cont = queryService.executeQuery("select * from AIM_CONTENT where cod_content='"+query_rec[i].cod_content+"'",null);
		log.info("AIM_CHANGE_STATUS:mappa query_cont "+query_cont);
		if(query_cont!=null){
			for(int k=0; k<query_cont.size(); k++){			
				//query per recuperare il tipo di azione interessata dal cambio stato
				def action = queryService.executeQuery("SELECT * FROM AIM_TRACK_STATUS_R_ACTION WHERE cod_track_status='"+query_cont[k].status_approval+"' and cod_track_status_end='"+cod_track_status_end+"'",null)[0];
				log.info("AIM_CHANGE_STATUS:action.cod_action_type "+action.cod_action_type);
				log.info("AIM_CHANGE_STATUS:action.cod_action_type "+action.cod_track_status_end);
				//CONTROLLO CHE CI SIA ALMENO UN AZIONE PER IL CAMBIO DI STATO
				if(action!=null && action.size()>0){
					//INIZIO A VALUTARE I CAMBI STATO SULLA BASE DELLE TIPOLOGIE DI AZIONE SPECIFICATE
					log.info("AIM_CHANGE_STATUS:LOG action "+action);
					//comincio a recuperare l'area dallo stato finale definito nella track
					def queryArea1 = queryService.executeQuery("SELECT cod_status FROM AIM_TRACK_STATUS WHERE uk_track_status='"+action.cod_track_status_end+"'",null)[0];
					def queryArea2 = queryService.executeQuery("SELECT area FROM AIM_TRACK_STATUS_TEMPLATE WHERE cod_status='"+queryArea1.cod_status+"'",null)[0];
					log.info("AIM_CHANGE_STATUS:queryArea1: "+queryArea1);
					log.info("AIM_CHANGE_STATUS:queryArea2: "+queryArea2);
					log.info("AIM_CHANGE_STATUS:action.cod_track_status_end: "+action.cod_track_status_end);
					//COMINCIO A VALUTARE LE TIPOLOGIE DI AZIONI
					//ora gestisco le azioni di tipo REVISIONE
					if(action.cod_action_type!=null && (action.cod_action_type=='REV' || action.cod_action_type=='CON')){
										
					def MscGenericFunction = services.gse.getInstanceByScriptName("aim_RevisionGenericFunction.groovy");
					MscGenericFunction.init(services);
					MscGenericFunction.creaRevisione(query_cont[k],queryArea2.area);					
					
										
					/*
						log.info("AIM_CHANGE_STATUS:sono entrato in tipo revisione o approvazione con condizione");
						def cod_building = query_cont[k].cod_building;
						log.info("AIM_CHANGE_STATUS:cod_building: "+cod_building);
						log.info("AIM_CHANGE_STATUS:codice contenuto pre-revisione: "+query_cont[k].cod_content);
						def num_content = query_cont[k].num_content;
						log.info("AIM_CHANGE_STATUS:num_content pre revisione: "+query_cont[k].num_content);
						def rev_content = query_cont[k].rev_content;
						def new_rev = query_cont[k].rev_content+1;
						log.info("AIM_CHANGE_STATUS:new_rev: "+new_rev);
						log.info("AIM_CHANGE_STATUS:rev_content: "+rev_content);
						//StringUtils.leftPad(num_cont.toString(), 6, "0")
						def rec_ins_rev = [:];
						rec_ins_rev.single_insert = 1;
						rec_ins_rev.from_revision = 1;
						rec_ins_rev.cod_building=query_cont[k].cod_building;
						rec_ins_rev.num_content=query_cont[k].num_content;
						rec_ins_rev.rev_content=new_rev;
						rec_ins_rev.content_class=query_cont[k].content_class;
						rec_ins_rev.cod_class_type=query_cont[k].cod_class_type;
						rec_ins_rev.author=query_cont[k].author;
						rec_ins_rev.usergroup=query_cont[k].usergroup;
						rec_ins_rev.descr_content=query_cont[k].descr_content;						
						rec_ins_rev.content_area=queryArea2.area;
						log.info("AIM_CHANGE_STATUS:queryArea2.area della revisione: "+queryArea2.area);
						log.info("AIM_CHANGE_STATUS:loggo le info da nuovo cntenuto: "+rec_ins_rev);
						//il cod_content viene calcolato nel groovy dei contenuti (aim_content_trigger)
						classService.insertClassRecord('aim_content',rec_ins_rev);
					*/	
											
 						
						//blocco il contenuto revisionato impostanto il parametro a 1
						def rec_upd_rev = [:];
						if(action.cod_action_type=='REV') {
							rec_upd_rev.id_content=query_cont[k].id_content;
							rec_upd_rev.is_blocked = 1;
							rec_upd_rev.status_approval=action.cod_track_status_end;
							classService.updateClassRecord('aim_content',rec_upd_rev);
						}					
					}else{
						// aggiorno la classe degli contenuti
						log.info("AIM_CHANGE_STATUS:loggo l'ID: "+query_cont[k].id_content);
						log.info("AIM_CHANGE_STATUS:loggo il codice: "+query_cont[k].cod_content);
						rec_upd.id_content=query_cont[k].id_content;
						rec_upd.status_approval=action.cod_track_status_end;
						rec_upd.cod_action_type=action.cod_action_type;
						rec_upd.role_action=action.role_action;
						rec_upd.content_area=queryArea2.area;
						rec_upd.cod_content=query_cont[k].cod_content;
						//modifico il campo che determina l'annullamento
						if(action.cod_action_type!=null && action.cod_action_type=='ANN'){
							rec_upd.is_invalid = 1;				
						}
						if(action.cod_action_type!=null && action.cod_action_type=='APP'){
							rec_upd.is_approved = 1;				
						}						
						classService.updateClassRecord('aim_content',rec_upd);
					}
					//predispongo il popolamento della classe che tiene traccia dei cambi stato
					def rec_info = [:];
					rec_info.cod_content = query_cont[k].cod_content;
					rec_info.username = username;
					rec_info.date_process = date_process;
					rec_info.action_type = action.cod_action_type;
					rec_info.cod_track = cod_track;
					rec_info.note_process = note_process;
					rec_info.name_action = action.name_action;
					//Aggiunto inserimento documento da MRI il 24/05/19
					//rec_info.doc_name=id_change_status.doc_name;
					//rec_info.doc_ctype=id_change_status.doc_ctype;
					//rec_info.doc_file=id_change_status.doc_file;
					log.info("mappa di inserimento su classe storico: " + rec_info);
					// aggiorno la classe dei cambi stato dell'elaborato
					classService.insertClassRecord('aim_content_history',rec_info); 					
				}else{
					throw new RuntimeException("Non ci sono azioni associate allo stato corrente.<br>Impossibile proseguire!");					
				}
			}		


		}
		
	}
}	
		

log.info("AIM_CHANGE_STATUS:end info document updating for process n. " + execution.getProcessInstanceId()); 
