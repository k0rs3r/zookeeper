

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument; 
import org.springframework.context.i18n.LocaleContextHolder; 

def result = [:];
def success = false;
def description = "";
try{
	boolean avoidToStartProcess = false;
	String keyColumn			= "id_content";
	String className  			= "aim_content";
	def rec_ins = [:];
	//controllo che ci sia almeno un elaborato selezionato
	if(items!=null && items.size()>0){
	log.info("mappa contenuti partenza: "+items);
	log.info("loggo la grandezza della selezione: "+items.size())


		def last_cod_track;
		def last_status_approval;
		def last_action_role;
		
		for(int i=0;i<items.size();i++){
			
			String itemId        = items[i].get(keyColumn);
			item = classService.selectClassRecord(className,''+itemId);
			if(i==0) {
				//primo record
				last_area           = item.content_area;
				last_cod_track           = item.cod_track;
				last_status_approval = item.status_approval;
				last_file_name           = item.is_uploaded;
				log.info(item);
				log.info("i=0: last_cod_track: "+last_cod_track +" ; last_status_approval: "+last_status_approval);
				
			}else{
				log.info("Controllo : item.id_content:"+item.id_content+" ?= cod_track:"+item.cod_track+" ; last_cod_track:"+last_cod_track+" ; item.status_approval: "+item.status_approval+" ?= last_status_approval: "+last_status_approval);
				if(!item.cod_track.equals(last_cod_track) || !item.status_approval.equals(last_status_approval)){
					log.info("Trovati due campi diversi");
					avoidToStartProcess=true;
					break;
				}
					
			}
		}
		//faccio la query per controllare se l'utente in sessione dispone de diritti necessari per avviare l'azione
		def permission = queryService.executeQuery("select * from V_AIM_TRACK_PERMISSION where cod_content='"+item.cod_content+"' and username='"+activeUser+"'",null);
		//recupero l'azione tipo per il processo in corso (mi serve per recuperare il ruolo che può eseguire l'azione stessa)
		def action = queryService.executeQuery("select * from V_AIM_TRACK_PERMISSION where cod_track_status='"+item.status_approval+"'",null);
		def statusChk = queryService.executeQuery("select * from V_AIM_CONTENT where content_status='"+item.content_status+"' and content_status not in ('ANN','SUP','CLO')",null);
	
		if(avoidToStartProcess){			
			description= "Il Processo di cambio stato non può essere avviato. <br>Assicurarsi che i record selezionati abbiamo tutti stessa track <br>e stesso stato.";					
		} else if(item.is_uploaded==0){
			//restituisco il messaggio di eccezione
			description= "L'azione non può essere avviata. Caricare prima il contenuto";
		//gestisco l'eccezione in caso non ci siano azioni associate allo stato corrente
		}else if(statusChk==null || statusChk.size()==0){
			//controllo che gli stati del contenuto siano non validi e quindi lancio il messaggio
			description= "L'azione non può essere avviata.<br>Gli stati previsti sono o revsionati o annullati"; 	
		}else if(action==null || action.size()==0){
			//formulo il messaggio di eccezione per mancata azione associata allo stato corrente
			description= "L'azione non può essere avviata.<br>La track approvativa non prevede avanzamento per lo stato corrente";
		//controllo caso "nessun permesso associato al mio utente per l'azione disponibile	
		}else if(permission==null || permission.size()==0){
				//recupero la descrizone del ruolo che può avviare l'azione
			
				def role_action = queryService.executeQuery("select * from AIM_TRACK_ROLE where cod_track_role='"+action[0].role_action+"'",null);
				//recupero il nome dell'utente in sessione
				def nome_utente = queryService.executeQuery("select * from geow_users where username='"+activeUser+"'",null);
				//recupero la descrizione del ruolo in maiuscolo
				String descr_role = role_action[0].descr_track_role;  
				String descr_role_upper=descr_role.toUpperCase();
				//recupero la descrizione dell'utente in maiuscolo
				String descr_user = nome_utente[0].descr_user;  
				String descr_user_upper=descr_user.toUpperCase();
			//formulo il messaggio di eccezione in caso di mancati diritti
			def map = new HashMap<String,Object>();
			map.descr_user_upper = descr_user_upper;
			map.descr_role_upper = descr_role_upper;
			description = "L'utente "+descr_user_upper+" non dispone dei diritti necessari.<br>L'azione può essere eseguita da un utente con permessi di tipo <br>"+descr_role_upper;
		//proseguo con le condizioni valide per aprire la maschera di processo	
		} else{

			// definisco oggetto per le variabili di processo
			def processVariables = [:];

			// assegno all'utente di caricamento (user_upload) il valore dell'utente in sessione
			processVariables.username=activeUser; 

			// assegno alla data di caricamento (date_upload) la data di sistema
			processVariables.date_process=new Date();

			// definisco il record del documento oggetto di caricamento

			// recupero il nome dell'azione relativa allo status della deliverable
			def query = queryService.executeQuery("SELECT * FROM AIM_TRACK_STATUS_R_ACTION WHERE cod_track_status='"+item.status_approval+"'", null)[0];
			// assegno alle variabili di processo i valori richiesti di partenza
			processVariables.cod_track_status=last_status_approval;
			processVariables.cod_track=last_cod_track;
			processVariables.area=last_area;
			// instanzio le variabili
			def taskNextStepInfosHM = workflowService.startProcessByMessageForTaskNextStepInfos("change_status_start_by_message", processVariables);  // MessageRef
			log.info("taskNextStepInfosHM:");
			log.info(taskNextStepInfosHM);
			
			result.taskNextStepInfosHM = taskNextStepInfosHM;
			//recupero act_pid del processo
			def act_pid = taskNextStepInfosHM.processInstanceId;
			log.info("act_pidact_pid:"+act_pid);
			//recupero id della tabella di processo a partire dall'act_pid
			def itemId = workflowService.retrieveGwItemIdFromProcessInstanceId(act_pid);		
			log.info("itemIditemId:"+itemId);
			//effettuo l'insert sulla tabella di appoggio in cui scrivo i record selezionati prima dell'avvio del processo con la chiave esterna del processo
			for(int i=0;i<items.size();i++){
				rec_ins.id_change_status=itemId;
				rec_ins.cod_content=items[i].cod_content;
				classService.insertClassRecord("aim_wpi_content_r_proc",rec_ins);
			}
			
			success = true;
			log.info("success (after insert into records in aim_wpi_content_r_proc):"+success);
		}
	}else if (items==null || items.size()==0){
		description = "Attenzione: Nessun contenuto selezionato";
	}	
}catch(Exception e){
	success = false;
	description = e.getMessage();
}finally{
	result.success = success;
	result.description = description;
}
return result;
