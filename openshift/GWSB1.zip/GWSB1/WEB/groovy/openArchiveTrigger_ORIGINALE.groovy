//user:    AA 
//date:    04/03/2020
//ver:     4.4
//project: AIM
//type:    action groovy
//class:   aim_building
//note:    GROOVY INVOCATO ALL'APERTURA DEL FASCICOLO IMMOBILE, CONTROLLA LA PRESENZA DELLE SCHEDE DIGITALI DEFINITE PER IMMOBILE
//         IN CASO NON FOSSERO PRESENTI, CREA INDICE E CONTENUTO VUOTO

import com.geowebframework.transfer.model.metadataservice.Class;
//recupero i parametri passati dall'azione che richiama questo groovy
def cod_building = parameterMap.cod_building;
def author = parameterMap.author;

//seleziono la tipologia di edificio e controllo nella tabella di configurazione delle sch, quali sono le schede digitali da predisporre per l'immobile
def schClassesQuery = "select distinct s.class_name, c.cod_class_subcat, c.configuration_type from aim_build_class_sch s inner join gwd_building b on s.cod_classification=b.cod_building_classification "+
" inner join aim_bim_sch_conf c on c.class_name=s.class_name where b.cod_building=#{map.cod_building}";
def schClassesResult = services.queryService.executeQuery(schClassesQuery, [cod_building: cod_building]);
log.info("default sch of building: "+ schClassesResult);
if(schClassesResult!=null && schClassesResult.size()>0){
    //controllo se esistono i contenuti sch richiesti
    //se non esistono creo record su aim_content e su aim_content_sch 
    def contentQuery = "select cod_content from aim_content where cod_building=#{map.cod_building} and class_name=#{map.class_name}";   
    for(int i=0; i<schClassesResult.size(); i++){
        def class_name = schClassesResult[i].class_name;
        def cod_class_subcat = schClassesResult[i].cod_class_subcat;
        def map = [cod_building: cod_building, class_name: class_name];
        def contentResult = services.queryService.executeQuery(contentQuery, map);
        if(contentResult==null || contentResult.size()==0){
            def contentMap = [:];
            contentMap.author = author;
            contentMap.usergroup = 'AIM_BIM';
            contentMap.from_revision = 0;
            contentMap.single_insert = 0;
            contentMap.cod_building = cod_building;
            contentMap.class_name = class_name;
            contentMap.cod_class_type = "SCH";
            contentMap.content_class = cod_class_subcat;
            services.classService.insertClassRecord('aim_content', contentMap);
        } else  {
            log.debug("sch "+class_name+" content already exist: "+ contentResult[0].cod_content + " configuration_type="+schClassesResult[i].configuration_type);
            //se la scheda digitale è popolata da connettore devo andare a popolare il legame tra le due classi
            if(schClassesResult[i].configuration_type==2){
                map.cod_content = contentResult[0].cod_content;
                def isDigDocExist = services.queryService.executeQuery("select count(1) as is_exist, upload_date from "+class_name+" where cod_building=#{map.cod_building} group by upload_date", map);
                if(isDigDocExist.size()>0 && isDigDocExist[0].is_exist>0){
                    log.info("digital document exist for sch "+contentResult[0].cod_content);

                    Class gwClass = services.gwm_classService.selectByClassName(new Class(class_name));
			        map.fk_sch_class = gwClass.getGwid();
                    map.creation_date = isDigDocExist[0].upload_date;
                    services.queryService.executeQuery("update "+class_name+" set cod_content=#{map.cod_content} where cod_building=#{map.cod_building}", map);
                    services.queryService.executeQuery("update aim_content set is_uploaded=1 where cod_content=#{map.cod_content}",map);
                    services.queryService.executeQuery("update aim_content_sch set fk_sch_class=#{map.fk_sch_class}, sch_code_column='cod_content', "+
                    " sch_code=#{map.cod_content}, creation_date=#{map.creation_date}, sch_layout='default_sch' where cod_content=#{map.cod_content}",map);
                    
                }
            }
        }
        
    }
}


