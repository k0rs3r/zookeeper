if(binding.hasVariable("isConsistency")){
	sessionObject.addSessionParameter("isConsistency", isConsistency); 
}
if(binding.hasVariable("consistency")){
	def cod_content = services.queryService.executeQuery(
	"select AIM_CONTENT_SCH.cod_content from AIM_CONTENT_SCH inner join AIM_CONTENT on AIM_CONTENT_SCH.cod_content = AIM_CONTENT.cod_content inner join AIM_BIM_SCH_CONF ON AIM_CONTENT.cod_class_subcat = AIM_BIM_SCH_CONF.cod_class_subcat where AIM_CONTENT.cod_building = '"+var_cod_building+"' and AIM_BIM_SCH_CONF.class_name = 'aim_sch_consistency'", null)[0];
	def id_sch_consistency = services.queryService.executeQuery(
	"select AIM_SCH_CONSISTENCY.id_sch_consistency from AIM_CONTENT_SCH inner join AIM_CONTENT on AIM_CONTENT_SCH.cod_content = AIM_CONTENT.cod_content inner join AIM_BIM_SCH_CONF ON AIM_CONTENT.cod_class_subcat = AIM_BIM_SCH_CONF.cod_class_subcat inner join AIM_SCH_CONSISTENCY on AIM_SCH_CONSISTENCY.cod_content = AIM_CONTENT_SCH.sch_code where AIM_CONTENT.cod_building = '"+var_cod_building+"' and AIM_BIM_SCH_CONF.class_name = 'aim_sch_consistency'", null)[0];
	if(cod_content==null){
		//throw new Exception("cod_content not found");
	}else{
		sessionObject.addSessionParameter("cod_content", cod_content.get("cod_content")); 
	}
	
	if(id_sch_consistency==null){
		//throw new Exception("id_sch_consistency not found");
	}else{
		sessionObject.addSessionParameter("id_sch_consistency", id_sch_consistency.get('id_sch_consistency')); 
	}
	
}

if(binding.hasVariable("building_filter")){
	sessionObject.addSessionParameter("building_filter", building_filter); 
}
if(binding.hasVariable("session_label")){
	sessionObject.addSessionParameter("session_label", session_label); 
}
if(binding.hasVariable("var_cod_building")){
	sessionObject.addSessionParameter("var_cod_building", var_cod_building); 
}
if(binding.hasVariable("var_name_building")){
	sessionObject.addSessionParameter("var_name_building", var_name_building); 
}
return  sessionObject; 