import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import org.springframework.security.authentication.encoding.ShaPasswordEncoder;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.User;
import com.geowebframework.transfer.model.metadataservice.Group;

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){
		log.info("loggo la mappa in ingresso (valuesMap): "+valuesMap);
		log.info("--------------------------beforeInsert");
		def username = valuesMap.get("username");
		def email = valuesMap.get("email");
		def regex = "^(.+)@(.+)\$";
        def pattern = Pattern.compile(regex);
		def matcher = pattern.matcher((CharSequence) email);
		def okk=matcher.matches();
		if(!okk){
			return false;
		}
		
		//Servizio che controlla username nei metadati, se trova un utente con stesso username manda un errore!		
		User SelectUser = new User(username);
		def UtenteSelezionato = services.gwm_userService.selectByUserName(SelectUser);
		log.info("Utente selezionato dalla select sui metadati: "+UtenteSelezionato);
		log.info("SelectGROUP: "+SelectUser);
		
		if(UtenteSelezionato!=null){								
			throw new RuntimeException("ATTENZIONE: Username già in uso. Se possibile inserire un nuovo username.");
		} 
		
		//Servizio che controlla email nei metadati, se trova un'email uguale non permette la creazione!
		def SelectEmail = email;
		def EmailSelezionata = services.gwm_userService.selectByEmail(SelectEmail);
		
		if(EmailSelezionata!=null){								
			throw new RuntimeException("ATTENZIONE: Email già in uso. Se possibile inserire una nuova email.");
		} 
		
		//Crea una password temporanea finchè l'utente non la cambierà seguendo le istruzioni nella mail che verrà inviata subito dopo.
		 def passwordUtente=valuesMap.get("password");
		if(passwordUtente==null){
			passwordUtente = RandomStringUtils.randomAlphabetic(1)+RandomStringUtils.randomAlphanumeric(10);
		}
		
		ShaPasswordEncoder shaPasswordEncoder = new ShaPasswordEncoder(512);
		def encodedPassword = shaPasswordEncoder.encodePassword(passwordUtente, null);
		
		valuesMap.put("password_crittografata",encodedPassword);
		valuesMap.put("password",passwordUtente);
		//popolo i valori di default
		valuesMap.put("enable_bim_manager",0);
		valuesMap.put("is_active",1);
		valuesMap.put("is_bim_manager",0);
		valuesMap.put("is_bim_specialist",0);
		
		return true;
    };
    

    public boolean afterInsert(HashMap<String,Object> valuesMap){
	    def emailutente = valuesMap.get("email");
		def regex = "^(.+)@(.+)\$";
        def pattern = Pattern.compile(regex);
		def matcher = pattern.matcher((CharSequence) emailutente);
		def okk=matcher.matches();
		if(okk){
			
			def username = valuesMap.get("username");			
			def encodedPassword =valuesMap.get("password_crittografata");
			def passwordUtente =valuesMap.get("password");
			//def password_utente = "44f500593b30fa82cd27d405d1c398cdbd7cd6025660aba9067caa85057a27dbba6fc851c81653aefdd921d191fd04ce08d895db90916a38ee0b36a6580ce57a";
			def password_utente =encodedPassword;
			def nome = valuesMap.get("nome");
			def cognome = valuesMap.get("cognome");
			def email = valuesMap.get("email");

			log.debug("username: "+username);
			log.debug("password_crittografata: "+encodedPassword);
			log.debug("password: "+passwordUtente);
			log.debug("nome: "+nome);
			log.debug("cognome: "+cognome);
			log.debug("email: "+email);

			def valuesMap2 = [:] ;

			valuesMap2.put("username",username);
			valuesMap2.put("password_crittografata",encodedPassword);
			valuesMap2.put("password",passwordUtente);
			valuesMap2.put("usergroup","");
			
			//INSERISCO IL RECORD NEI METADATI PER LA TABELLA GWM_USERS
			User gwUser = new User(username,encodedPassword);
			services.gwm_userService.insert(gwUser);
			//Inserisco Email nei metadati
			services.gwm_userService.updateUserEmail(username,email)

			//INVIO LA MAIL DI AVVENUTA CREAZIONE UTENTE
			String title = ConfigurationProperties.getInstance().getProperty("info.title");			
			String subject = title+": Definizione nuovo utente";
			String message = "<html><body>Salve " + nome+" "+cognome+".";
			message= message +"<br>Ti notifichiamo che sei stato inserito come utente nel sistema Common Data Environment."
			message= message +"<br>Seguirà una notifica con i parametri di configurazione dell'utenza.";
			message= message +"<br>";
			message= message +"<br>";
			message= message +"<br></body></html>";
			
			String from = null;//optional
			Object to = email;//required
			Object cc = null;//optional
			Object bcc = null;//optional
			String replyTo = null;//optional
			//String subject = subject;//optional
			String text = message;//required
			Integer priority = null;//optional, 1 = high, 3 = normal, 5 = low
			List<GwBeanDocument> gwBeanDocumentList = null;
			services.gwMailService.sendMail(from, to, cc, bcc, replyTo, subject, text, priority, gwBeanDocumentList);

			//Invio notifica email con token
			//Inizializzo Variabili
			//CONTROLLARE LA VARIABILE appUrl, modificare l'url in base al proprio link dell'applicativo!
			def userEmail = email;
			def appUrl = ConfigurationProperties.getInstance().getProperty("url.in.conf");
			def locale = null;

			//Eseguo Servizio
			services.userSecurityDataService.sendUserResetPassword(userEmail,appUrl,locale);				
			return true;
		}else{
		    throw new RuntimeException("Attenzione email non valida");
			return false;
		}
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		log.debug("----------------------------beforeUpdate");	

        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		log.debug("----------------------------afterUpdate");
				
        return true;
		
    };
    
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		log.debug("----------------------------beforeDelete user_Trigger");
		def userkey = valuesMap.get("pk_geow_users");
		log.info("valuesMap: "+valuesMap);
		
		def valuesMap2 = [:] ;
		valuesMap2.put("userkey",userkey);
	
		def userMap=services.queryService.executeQuery("select username from geow_users where pk_geow_users=#{map.userkey}",valuesMap2);
		def user_delete=services.queryService.executeQuery("select * from geow_users where pk_geow_users=#{map.userkey}",valuesMap2);
		log.info("loggo userMap: "+userMap);
		
		if(userMap!=null && !userMap.isEmpty()){
		
			def username = userMap[0].username;
			def nome = user_delete[0].nome;
			def cognome = user_delete[0].cognome;
			def email = user_delete[0].email;
			
			//DELETE METADATI gwm_users
			User gwUser = new User(username);
			services.gwm_userService.deleteByUserName(gwUser);
			///DELETE TABELLA METADATI gwm_user_groups
			services.gwm_groupService.removeUserFromGroup(gwUser,null);

		
			//INVIO MAIL DI CANCELLAZIONE UTENTE
			String title = ConfigurationProperties.getInstance().getProperty("info.title");			
			String subject = title+": Cancellazione utente";
			String message = "<html><body>Salve " + nome+" "+cognome+".";
			message= message +"<br>Ti notifichiamo la tua utenza è stata eliminata dal sistema Asset Information Model."
			message= message +"<br>";
			message= message +"<br>";
			message= message +"<br></body></html>";
			
			String from = null;//optional
			Object to = email;//required
			Object cc = null;//optional
			Object bcc = null;//optional
			String replyTo = null;//optional
			//String subject = subject;//optional
			String text = message;//required
			Integer priority = null;//optional, 1 = high, 3 = normal, 5 = low
			List<GwBeanDocument> gwBeanDocumentList = null;
			services.gwMailService.sendMail(from, to, cc, bcc, replyTo, subject, text, priority, gwBeanDocumentList);
		
			def valuesMap3 = [:] ;
			valuesMap3.put("username",username);
			

			//PREDISPONGO L'ELIMINAZIONE DEI RUOLI ASSOCIATI ALL'UTENTE
			def del = services.queryService.executeDeleteQuery("DELETE FROM cde_user_map_role WHERE username='"+username+"'",null);			
			
			
			
		
		}else{
			log.debug("-------------------GEOWEB_ERROR: can't find username for pk_geow_users:"+userkey);
		}

        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){

			
        return true;
    };

} 