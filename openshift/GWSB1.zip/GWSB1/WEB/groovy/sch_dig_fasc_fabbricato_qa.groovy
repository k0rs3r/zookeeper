public class sch_dig_fasc_fabbricato_qa extends com.geowebframework.transfer.objects.digitaldocument.GwDigitalDocumentConfigImpl {
	
	public Boolean isVisible(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){

		log.error("templateName: "+templateName);
		log.error("sectionName: "+sectionName);
		log.error("entityName: "+entityName);
		log.error("entityStatus: "+entityStatus);
		def isVisible = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qa")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QA_01")||
				sectionName.equals("QA_02")||
				sectionName.equals("QA_03")||
				sectionName.equals("QA_04")||
				sectionName.equals("QA_05")||
				sectionName.equals("QA_06")||
				sectionName.equals("QA_07")||
				sectionName.equals("QA_08_1")||
				sectionName.equals("QA_08_2")||
				sectionName.equals("QA_08_3")||
				sectionName.equals("QA_08_4")||
				sectionName.equals("QA_09")||
				sectionName.equals("QA_10")||
				sectionName.equals("QA_99")
			)
				{
					isVisible = true;
					log.error("isVisible = true");
				}
			
		}
		log.error("isVisible: "+isVisible);
		return isVisible;
	}
	public Boolean isEditable(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isEditable = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qa")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QA_01")||
				sectionName.equals("QA_02")||
				sectionName.equals("QA_03")||
				sectionName.equals("QA_04")||
				sectionName.equals("QA_05")||
				sectionName.equals("QA_06")||
				sectionName.equals("QA_07")||
				sectionName.equals("QA_08_1")||
				sectionName.equals("QA_08_2")||
				sectionName.equals("QA_08_3")||
				sectionName.equals("QA_08_4")||
				sectionName.equals("QA_09")||
				sectionName.equals("QA_10")||
				sectionName.equals("QA_99")
			)
				{
					isEditable = true;
				}
			
		}
		return isEditable;
	}
	
	public Boolean isDefaultSelected(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isDefaultSelected = false;
		return isDefaultSelected;
	}

}