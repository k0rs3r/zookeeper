
import com.geowebframework.calendar.objects.Selection;
import com.geowebframework.calendar.objects.SelectionList;

public class LayoutGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {

	//private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger("com.geowebframework.groovy");
    
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		//popolare il campo (univoco) layout_code come concatenazione di tenant_code e user_layout_code
		def userLayoutCode = valuesMap.user_layout_code;
		def tenantCode = valuesMap.tenant_code;				
		if(userLayoutCode!=null)		
			valuesMap.put("layout_code", tenantCode + "_" + userLayoutCode);
				
		return true;
    };
    
    public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		//super.afterInsert(valuesMap);
		
		String layoutType = (String) valuesMap.get("layout_type");
		if(layoutType.equals("2D") ){
			services.queryService.executeQuery("update gwd_drawing_set set is_default=1 where fk_layout="+valuesMap.itemId, null);
		}
		return true;
		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> OldvaluesMap){
        
        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
       
        return true;
    };

	public boolean beforeDelete(HashMap<String,Object> valuesMap){
	        return true;
	};
} 