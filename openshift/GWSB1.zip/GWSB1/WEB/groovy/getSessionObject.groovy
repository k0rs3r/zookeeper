//groovy utilizzato per recuperare le variabili in sessione, nello specifico l'applicationContext che contiene l'utente in sessione
import com.geowebframework.transfer.objects.session.SessionObject;

SessionObject sessionObject = applicationContext.getBean("sessionObject");
return sessionObject;