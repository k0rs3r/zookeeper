
import org.springframework.context.i18n.LocaleContextHolder;

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		String cod_classification = valuesMap.get("cod_classification");
		String cod_class_subcat = valuesMap.get("cod_class_subcat");
		//controllo che non vengano associati stesso utente e stesso gruppo più di una volta
		def query = services.queryService.executeQuery("SELECT id_build_class_cont FROM AIM_BUILD_CLASS_CONT WHERE cod_classification='"+cod_classification+"' and cod_class_subcat='"+cod_class_subcat+"'", null)[0];
		if(query!=null && query.size()>0){
			throw new RuntimeException("Attenzione: Classificazione già in uso!");
		}
    };
    

    public boolean afterInsert(HashMap<String,Object> valuesMap){
			
        return true;
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		
		String cod_classification = oldvaluesMap.cod_classification;
		String cod_class_subcat = valuesMap.cod_class_subcat;
		log.info("cod_classification: "+cod_classification);
		log.info("cod_class_subcat: "+cod_class_subcat);
		def query = services.queryService.executeQuery("SELECT id_build_class_cont FROM AIM_BUILD_CLASS_CONT WHERE cod_classification='"+cod_classification+"' and cod_class_subcat='"+cod_class_subcat+"'", null)[0];
			if(query!=null && query.size()>0){	
				throw new RuntimeException("Attenzione: Classificazione già in uso!");
			}
		
		
        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		

		
        return true;
		
    };
    
    public boolean beforeDelete(HashMap<String,Object> valuesMap){

		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
				
        return true;
    };

} 