//user:    RMA 
//date:    28/12/2015
//ver:     4.2
//project: JobOrder
//type:    trigger
//class:   cde_rfi_appo
//note:    trigger della classe degli Interventi Richiesti. In inserimento inserisce la data e lo stato (REQ) e recupera in automatico la descrizione degli oggetti ed il luogo


import org.apache.commons.lang.StringUtils;
import groovy.time.TimeCategory
import com.geowebframework.calendar.objects.Selection;
import com.geowebframework.calendar.objects.SelectionList;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder;


public class RqmRequestInsertGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		//CALCOLO IL PROGRESSIVO DEL CODICE DEL TEAM
		def num_team = services.queryService.executeQuery("SELECT count(id_filter_team) as num_team FROM AIM_BIM_FILTER_TEAM", null)[0].num_team;
		log.info("loggo il num_team di partenza: "+num_team);
		if(num_team==0){
            num_team=1;
            def num_team_string = StringUtils.leftPad(num_team.toString(), 2, "0");
            valuesMap.put("cod_filter_team","FILTERTEAM_" + num_team_string);
            valuesMap.put("prog",num_team);
			log.info("loggo il num_team di arrivo: "+num_team);
        }else {
            def max_prog = services.queryService.executeQuery("SELECT max(prog) as max_prog FROM AIM_BIM_FILTER_TEAM", null)[0].max_prog;
            max_prog=++max_prog;
			log.info("max_prog: "+max_prog);
            def max_prog_string = StringUtils.leftPad(max_prog.toString(), 2, "0");
			log.info("loggo il max_prog_string di arrivo: "+max_prog_string);
            valuesMap.put("cod_filter_team","FILTERTEAM_" + max_prog_string);
            valuesMap.put("prog",max_prog);

        }	
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};
	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> valuesMapOld){		
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
	
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		return true;
	};
	
}
