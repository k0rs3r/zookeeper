import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.gwMnemonicCode.model.widget.MnemonicCodeSelectionWidget;
import com.geowebframework.gwMnemonicCode.model.widget.MnemonicCodeWidget;


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
/*
				
	//recupero la variabile della classificazione
	def cod_function_mc = valuesMap.get("cod_function_mc");
	def cod_building = valuesMap.get("cod_building");
	
	//recupero le parti del mnemonic code
	String nomeClasse= "gwd_hier_function";
	Class gwClass = services.gwm_classService.selectByClassName(new Class(nomeClasse));
	GwmMnemonicCode gwmMnemonicCode = services.gwm_mnemonicCodeService.selectByNameAndFkClass("mc_cod_function", gwClass.getGwid());
	ArrayList<String> valoreParti = services.gwMnemonicCodeService.handleMnemonicCode(valuesMap.cod_function_mc, (MnemonicCode) gwmMnemonicCode.getCtrlParam());
	log.info("valore_parti 0: "+valoreParti[0]);
	log.info("valore_parti 1: "+valoreParti[1].replace(valoreParti[0],""));
	log.info("valore_parti 2: "+valoreParti[2].replace(valoreParti[1],""));
	log.info("valore_parti 3: "+valoreParti[3].replace(valoreParti[2],""));
log.info("valore_parti 3: "+valoreParti[3].code);
log.info("valore_parti 3: "+valoreParti[3].full_code);
	valuesMap.put("cod_system_type",valoreParti[0].code);
	valuesMap.put("num_system",valoreParti[1].code);
	valuesMap.put("cod_element_type",valoreParti[2].code);
	valuesMap.put("num_element",valoreParti[3].code.replaceAll("-",""));
	//recupero il tipo team
	def cod_system_type = valuesMap.cod_system_type;
	def queryTeam = services.queryService.executeQuery("SELECT cod_team_type FROM GWD_SYSTEM_TYPE WHERE cod_system_type='"+cod_system_type+"'", null)[0];	
	valuesMap.put("cod_team_type",queryTeam.cod_team_type);
	//popolo il codice completo
	valuesMap.put("cod_function",cod_building+"-"+cod_function_mc);
	//popola la classe della funzione
	valuesMap.put("cod_function",valoreParti[0].code+valoreParti[2].code);
*/
	//recupero variabili in ingresso da CSV;
	log.info("loggo la mappa di valori in ingresso: "+valuesMap);
	def cod_building = valuesMap.get("cod_building");
	def cod_system_type = valuesMap.get("cod_system_type");
	def num_system = valuesMap.get("num_system");
	def cod_element_type = valuesMap.get("cod_element_type");
	def num_element = valuesMap.get("num_element");
	def num_sys = null;
	def num_ele = null;
	def element_type = null;
	log.info("loggo il num_system: "+num_system);
	log.info("loggo il cod_element_type: "+cod_element_type);
	log.info("loggo il num_element: "+num_element);

	if(num_system==null){
	num_sys='---';	
	}else{num_sys=num_system.toString().padLeft(3, '0');}
	
	if(cod_element_type==null){
	element_type='---';	
	}else{element_type=cod_element_type;}
	
	if(num_element==null){
	num_ele='---';	
	}else{num_ele=num_element.toString().padLeft(3, '0');}
	
	
	
	valuesMap.put("cod_function_mc",cod_system_type+num_sys+element_type+num_ele);
	valuesMap.put("cod_function",cod_building+"-"+cod_system_type+num_sys+element_type+num_ele);
	valuesMap.put("class_function",cod_system_type+element_type);
	def cod_function = valuesMap.cod_function;
	
	//controllo l'univocità del codice della funzione tecnica
		def query = services.queryService.executeQuery("SELECT id_function FROM gwd_hier_function WHERE cod_function='"+cod_function+"'", null)[0];
		if(query!=null && query.size()>0){		
			throw new RuntimeException("Attenzione: Funzione Tecnica già presente. <br>Impossibile creare elemento con stesse caratteristiche");
		}
	
	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 