//user:    MPE 
//date:    14/01/2017
//ver:     4.2.5
//project: cde
//type:    event trigger (TRIGGER DI CLASSE)
//class:   cde_doc_subcod04
//note:    inserire descrizione completa

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		//CONTROLLO CHE NON VENGANO INSERITI PIù DI UN VINCOLO CON LO STESSO NOME
		String name_sch_cons_bond = valuesMap.get("name_sch_cons_bond");
		
		//controllo che la configurazione della track sia corretta
		def queryName = services.queryService.executeQuery("SELECT id_sch_cons_bond FROM AIM_SCH_CONS_BOND WHERE name_sch_cons_bond=#{map.name_sch_cons_bond}",valuesMap);
		if(queryName!=null && queryName.size()>0){
			throw new RuntimeException("ATTENZIONE: Nome Vincolo già in Uso!");
		}
	
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
					
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		//CONTROLLO CHE NON VENGANO INSERITI PIù DI UN VINCOLO CON LO STESSO NOME
		String name_sch_cons_bond = valuesMap.get("name_sch_cons_bond");
		//controllo che la configurazione della track sia corretta
		def queryName = services.queryService.executeQuery("SELECT id_sch_cons_bond FROM AIM_SCH_CONS_BOND WHERE name_sch_cons_bond=#{map.name_sch_cons_bond}",valuesMap);
		if(queryName!=null && queryName.size()>0){
			throw new RuntimeException("ATTENZIONE: Nome Vincolo già in Uso!");
		}
				
        return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
					
        return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 