//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_track
//note:    il groovy effettua le seguenti operazioni
//         a) calcolo del codice della track
//         b) blocco cancellazione in caso di contenuti collegati
//         c) cancello stati in caso di contenuti non collegati


import org.apache.commons.lang.StringUtils;

public class aim_track_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		// CALCOLO CODICE UNIVOCO DELLA TRACK
		
		// istanzio variabili codice e progressivo
		def prog = null;
		def cod = null;
		
		// conto il numero di record 
		def num_rec = services.queryService.executeQuery("SELECT count(1) as num_rec FROM aim_track", null)[0].num_rec;
		log.info("numero di record: "+ num_rec);	

		// se il conteggio è pari a zero, assegno al progressivo il valore 1
		if (num_rec==0){prog = 1}
		
		// se il conteggio è maggiore di zero, assegno al progressivo il valore max progressivo + 1
		else if (num_rec>0){
			// recupero valore massimo del progressivo
			def max_prog = services.queryService.executeQuery("SELECT max(prog) as max_prog FROM aim_track", null)[0].max_prog;
			log.info("numero di record: "+ max_prog);
			// calcolo il progressivo
			prog = max_prog + 1;		
			};
		
		log. info("valore da assegnare al progressivo: " + prog);
		
		// calcolo il codice (prefisso AIMTRACK + progressivo)
		cod = 'AIMTRACK_' + StringUtils.leftPad(prog.toString(), 2, "0");
		log.info("codice della track: " + cod);
		
		// valorizzo codice e progressivo della track
		valuesMap.put("cod_track",cod);
		valuesMap.put("prog",prog);
		
		
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};
	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){		
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
	
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){

	// recupero chiave del record in cancellazione
	def pk_rec = valuesMap.id_track;
	log.info("chiave del record in cancellazione: " + pk_rec);
	
	// recupero codice del record in cancellazione
	def cod_rec_del = services.queryService.executeQuery("SELECT cod_track AS cod_rec_del FROM aim_track WHERE id_track=" + pk_rec,null)[0].cod_rec_del;7
	log.info("codice del record in cancellazione: " + cod_rec_del);
	
	// conto il numero di record che hanno il codice della track in cancellazione 
	def num_rec_del = services.queryService.executeQuery("SELECT COUNT(1) AS num_rec_del FROM v_aim_content WHERE cod_track='" + cod_rec_del + "'",null)[0].num_rec_del;
	log.info("numero di record associati al record in cancellazione: " + num_rec_del);
	
	// se il conteggio è maggiore di zero, blocco cancellazione
	if (num_rec_del>0){
		// configuro il messaggio di alert	
		def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
		def warning_info ='La track non puo\' essere eliminata.<br>';			
		def warning_check ='Sono presenti n. <b>' + num_rec_del + '</b> contenuti associati.';			
		def warning_message = warning_title + warning_info + warning_check;
		throw new RuntimeException(warning_message);		
	}
	
	// se il conteggio è pari a zero, passo il codice all'after delete per la cancellazione degli stati
	else if (num_rec_del==0){
		valuesMap.cod_delete=cod_rec_del;
        log.info("codice della track in eliminazione: " + valuesMap.cod_delete);
		};
	
	return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		
        // recupero codice della track eliminata
        def cod_delete = valuesMap.cod_delete;
        log.info("chiave della track eliminata: " + cod_delete);
		
        // cancello gli stati
		def delete_records = services.queryService.executeQuery("DELETE FROM aim_track_status WHERE cod_track='" + cod_delete + "'",null);
		log.info("cancellazione: " + delete_records);
				
		return true;
	};
	
}
