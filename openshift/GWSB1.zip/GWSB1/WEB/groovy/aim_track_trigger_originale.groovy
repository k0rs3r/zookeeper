//user:    RMA 
//date:    28/12/2015
//ver:     4.2
//project: JobOrder
//type:    trigger
//class:   cde_rfi_appo
//note:    trigger della classe degli Interventi Richiesti. In inserimento inserisce la data e lo stato (REQ) e recupera in automatico la descrizione degli oggetti ed il luogo


import org.apache.commons.lang.StringUtils;
import groovy.time.TimeCategory
import com.geowebframework.calendar.objects.Selection;
import com.geowebframework.calendar.objects.SelectionList;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder;


public class TrackInsertGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		//definisco la variabile della codifica
		def name_track = "AIMTRACK";
		def priority = valuesMap.get("priority");
		def cod_bim_filter = valuesMap.get("cod_bim_filter");
		//CALCOLO IL PROGRESSIVO DEL CODICE DEL TEAM
		def num_track = services.queryService.executeQuery("SELECT count(id_track) as num_track FROM AIM_TRACK", null)[0].num_track;
		log.info("loggo il num_track di partenza: "+num_track);
		if(num_track==0){
            num_track=1;
            def num_track_string = StringUtils.leftPad(num_track.toString(), 2, "0");
            valuesMap.put("cod_track",name_track+"_" + num_track_string);
            valuesMap.put("prog",num_track);
        }else {
            def max_prog = services.queryService.executeQuery("SELECT max(prog) as max_prog FROM AIM_TRACK", null)[0].max_prog;
            max_prog=++max_prog;
			log.info("max_prog: "+max_prog);
            def max_prog_string = StringUtils.leftPad(max_prog.toString(), 2, "0");
			log.info("loggo il max_prog_string di arrivo: "+max_prog_string);
            valuesMap.put("cod_track",name_track+"_"+ max_prog_string);
            valuesMap.put("prog",max_prog);
        }	
		
		//blocco l'inserimento di nuove track con priorità al 99: è stato impostato un controllo inserimento da 1 a 99 su priorità (ADMIN)
		if(priority==99){
			throw new RuntimeException("Attenzione: Livello di priorità non ammesso<br>Selezionare valori da 1 a 98!");
		}
		//controllo che non ci sia un'altra track simile (permessi + priorità)
		def sameTrack = services.queryService.executeQuery("SELECT count(id_track) as num_track FROM AIM_TRACK where cod_bim_filter='"+cod_bim_filter+"' and priority="+priority, null)[0].num_track;
		if(sameTrack!=null && sameTrack>0){
			throw new RuntimeException("Attenzione: Configurazione track (Permessi + Priorità) già esistente!<br>Modificare uno dei due parametri o entrambi.");
		};
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};
	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){		
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
	
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		
	//predispongo l'eliminazione dei valori della classe delle azioni
	def pkTrack = valuesMap.id_track;
	def selectCode = "SELECT cod_track FROM AIM_TRACK where id_track="+pkTrack;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukTrack = result.cod_track;
	//controllo se ci sono contenuti associati alle track, in caso blocco la cancellazione
	def num_content = services.queryService.executeQuery("select count(id_content) as num_content from V_AIM_CONTENT where cod_track=#{map.cod_track}",[cod_track:ukTrack]);
	if(num_content!=null && num_content[0]!=null && num_content[0].num_content!=null && num_content[0].num_content>0){
		throw new Exception("Attenzione: Non è possibile cancellare la track!<br> Risulta associata ad uno o più contenuti");
	}else{
	def del = services.queryService.executeDeleteQuery("DELETE FROM AIM_TRACK_STATUS WHERE cod_track='"+ukTrack+"'",null);
	}
		return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		return true;
	};
	
}
