import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		log.info("sono in inserimento delle schede digitali ammesse per classificazione: "+valuesMap);
		//recupero i valori in ingresso
		String class_name = valuesMap.get("class_name");
		String cod_classification = valuesMap.get("cod_classification");
		def query1 = services.queryService.executeQuery("SELECT descr_class FROM AIM_BIM_SCH_CONF where class_name=#{map.class_name}", valuesMap)[0];
		def query2 = services.queryService.executeQuery("SELECT descr_classification FROM AIM_BUILD_CLASSIFICATION where cod_classification=#{map.cod_classification}", valuesMap)[0];
		log.info("class_name: "+class_name);

		//controllo che non possano essere aggiunte più volte le stesse sottocategorie	
		def num_class = services.queryService.executeQuery("SELECT count(1) as num_class FROM AIM_BUILD_CLASS_SCH where class_name='"+class_name+"' and cod_classification='"+cod_classification+"'", null)[0].num_class;
		if(num_class>0){	
			throw new RuntimeException("Attenzione: il documento digitale  <b>"+query1.descr_class+"</b><br> già presente per la classificazione: <br><b>"+query2.descr_classification+"</b>");
		}

		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		

	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		log.info("sono in modifica delle schede digitali ammesse per classificazione: "+valuesMap);
		//recupero i valori in ingresso
		String class_name = valuesMap.get("class_name");
		String cod_classification = oldvaluesMap.get("cod_classification");
		def query1 = services.queryService.executeQuery("SELECT descr_class FROM AIM_BIM_SCH_CONF where class_name=#{map.class_name}", valuesMap)[0];
		def query2 = services.queryService.executeQuery("SELECT descr_classification FROM AIM_BUILD_CLASSIFICATION where cod_classification=#{map.cod_classification}", oldvaluesMap)[0];
		log.info("class_name: "+class_name);

		//controllo che non possano essere aggiunte più volte le stesse sottocategorie	
		def num_class = services.queryService.executeQuery("SELECT count(1) as num_class FROM AIM_BUILD_CLASS_SCH where class_name='"+class_name+"' and cod_classification='"+cod_classification+"'", null)[0].num_class;
		if(num_class>0){	
			throw new RuntimeException("Attenzione: il documento digitale <b>"+query1.descr_class+"</b><br> risulta essere presente per la classificazione: <br><b>"+query2.descr_classification+"</b>");
		}

        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 