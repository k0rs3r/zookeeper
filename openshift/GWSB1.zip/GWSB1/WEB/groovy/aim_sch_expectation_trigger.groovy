
//project: AIM
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_sch_expectation_trigger
//note:    inserire descrizione completa

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;
import com.geowebframework.dataservice.ConfigurationProperties;


public class aim_sch_expectation_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		def pkExp = valuesMap.id_expectation;
		def selectCode = "SELECT * FROM aim_sch_expectation where id_expectation="+pkExp;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukExp = result.cod_expectation;
		def pimPrj = result.cod_pim_project;

		//gestisco l'eliminazione delle classi  
		//def delPIM = services.queryService.executeDeleteQuery("DELETE FROM AIM_SCH_EXP_DELIVERABLE WHERE cod_expectation='"+ukExp+"'",null);
		def num_del = services.queryService.executeQuery("SELECT id_exp_r_deliverable FROM AIM_SCH_EXP_DELIVERABLE where cod_expectation=#{map.ukExp}",[ukExp:result.cod_expectation]).id_exp_r_deliverable;
		log.info("loggo num_del: "+num_del);
		services.classService.deleteClassRecords("AIM_SCH_EXP_DELIVERABLE",num_del);
		
		def delCSM = services.queryService.executeDeleteQuery("DELETE FROM AIM_SCH_EXP_SITE WHERE cod_expectation='"+ukExp+"'",null);
		def delBimPrj = services.queryService.executeDeleteQuery("DELETE FROM GWD_BIM_PROJECT WHERE project_code='"+pimPrj+"'",null);
		def del3DLay = services.queryService.executeDeleteQuery("DELETE FROM GWD_LAYOUT WHERE layout_type='3D' and layout_code='"+pimPrj+"'",null);
		def delModSet = services.queryService.executeDeleteQuery("DELETE FROM GWD_MODEL_SET WHERE layout_code='"+pimPrj+"'",null);
		def delFedMod = services.queryService.executeDeleteQuery("DELETE FROM GWD_FED_MODEL WHERE cod_project='"+pimPrj+"'",null);
		def delStruct = services.queryService.executeDeleteQuery("DELETE FROM GWD_BIM_MODEL_STRUCTURE WHERE project='"+pimPrj+"'",null);
		def delLev = services.queryService.executeDeleteQuery("DELETE FROM GWD_BIM_LEVEL WHERE cod_project='"+pimPrj+"'",null);
		

		

		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
	
        return true;
    };

} 