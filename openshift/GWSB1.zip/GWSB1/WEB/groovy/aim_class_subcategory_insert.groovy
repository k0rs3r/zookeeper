//user:    ABA 
//date:    27/02/2019
//project: AIM
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_class_subcategory

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import org.springframework.context.i18n.LocaleContextHolder;
import com.geowebframework.transfer.model.dataservice.GwdFolder;
import com.geowebframework.dataservice.GwdFolderService;
import com.geowebframework.dataservice.service.GwClassListService;
import com.geowebframework.gwMnemonicCode.model.widget.MnemonicCodeSelectionWidget;
import com.geowebframework.gwMnemonicCode.model.widget.MnemonicCodeWidget;
import com.geowebframework.metadataservice.ClassService;
import com.geowebframework.metadataservice.GwmMnemonicCodeService;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		// valorizzo il progressivo della sottocategoria (da import CSV)
		def prog = valuesMap.get("prog_subcat");
		valuesMap.put("prog_subcat",prog);
	
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){  

	def pkSubcat = valuesMap.id_class_subcat;
	def selectCode = "SELECT cod_class_subcat FROM aim_class_subcategory where id_class_subcat="+pkSubcat;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukSubcat = result.cod_class_subcat;
	//controllo se ci sono dei contenuti associati alla categoria in sessione
	def numContent = services.queryService.executeQuery("SELECT count(id_content) as numContent FROM aim_content WHERE cod_class_subcat='"+ukSubcat+"'", null)[0].numContent;
	if(numContent>0){	
		throw new RuntimeException("ATTENZIONE: Impossibile eliminare questa SOTTOCATEGORIA.<br>Sono presenti contenuti ad essa associati");
	}else{
	//cancello la codifica di classificazione associata ad un contenuto digitale
	def delSCH = services.queryService.executeDeleteQuery("DELETE FROM aim_bim_sch_conf WHERE cod_class_subcat='"+ukSubcat+"'",null);
	//cancello la codifica di classificazione associata ad una tipologi di edificio: contenuti minimi
		def delOBBL = services.queryService.executeDeleteQuery("DELETE FROM AIM_BUILD_CLASS_CONT WHERE cod_class_subcat='"+ukSubcat+"'",null);
	}
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 