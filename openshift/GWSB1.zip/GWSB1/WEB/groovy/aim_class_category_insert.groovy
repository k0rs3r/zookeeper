//user:    ABA 
//date:    27/02/2019
//project: AIM
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_class_category

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import org.springframework.context.i18n.LocaleContextHolder;


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// RECUPERO VALORI DI INTERESSE
		// recupero codice categoria
		def cod_class_cat = valuesMap.get("cod_class_cat");
		log.info("codice della categoria: " + cod_class_cat);
		
		// recupero progressivo della categoria
		def prog_cat = valuesMap.get("prog_cat");
		log.info("progressivo della categoria della categoria: " + prog_cat);		
		
		//recupero le parti del mnemonic code
		String nomeClasse= "aim_class_category";
		Class gwClass = services.gwm_classService.selectByClassName(new Class(nomeClasse));
		GwmMnemonicCode gwmMnemonicCode = services.gwm_mnemonicCodeService.selectByNameAndFkClass("mc_cod_category", gwClass.getGwid());
		ArrayList<String> valoreParti = services.gwMnemonicCodeService.handleStringMnemonicCode(valuesMap.cod_class_cat, (MnemonicCode) gwmMnemonicCode.getCtrlParam());
		valuesMap.put("cod_class_arc",valoreParti[0]);
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){

		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){  
	
	//predispongo l'eliminazione dei valori della classe aim_class_subcategory
	def pkCat = valuesMap.id_class_cat;
	def selectCode = "SELECT cod_class_cat FROM aim_class_category where id_class_cat="+pkCat;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukCat = result.cod_class_cat;
	//controllo se ci sono dei contenuti associati alla categoria in sessione
	def numContent = services.queryService.executeQuery("SELECT count(id_content) as numContent FROM aim_content WHERE cod_class_cat='"+ukCat+"'", null)[0].numContent;
	if(numContent>0){
		throw new RuntimeException("ATTENZIONE: Impossibile eliminare questa CATEGORIA.<br>Sono presenti contenuti ad essa associati");	
	}
	def del = services.queryService.executeDeleteQuery("DELETE FROM aim_class_subcategory WHERE cod_class_cat='"+ukCat+"'",null);
	def del1 = services.queryService.executeDeleteQuery("DELETE FROM aim_content_classification WHERE cod_class_cat='"+ukCat+"'",null);

		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 