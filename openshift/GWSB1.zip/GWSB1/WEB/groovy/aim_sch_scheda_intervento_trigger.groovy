//user:    MPE
//date:    11/10/2020
//ver:     4.4.5
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_sch_scheda_intervento

//note:    il groovy effettua le seguenti operazioni
//         recupera lista degli interventi dalla tabella di configurazione AIM_SCH_SCHEDA_INTERVENTO_MOD
//         scrive gli interventi recuperati nella tabella di lista AIM_SCH_SCHEDA_INTERVENTO_LS
//         aggiorna lo stato di completamento su contenuto collegato


public class aim_sch_scheda_intervento_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		return true;
	};
  
	public boolean afterInsert(HashMap<String,Object> valuesMap){

		// RECUPERO IL CODICE DEL CONTENUTO
		def cod_cont = valuesMap.get("cod_content");
		log.info("codice del contenuto: " + cod_cont);

		// RECUPERO LISTA DI INTERVENTI DALLA TABELLA DI CONFIGURAZIONE
		def list_int = services.queryService.executeQuery("SELECT * FROM aim_sch_scheda_intervento_mod",null);
		log.info("elenco degli interventi: " + list_int);

		// SE LA LISTA NON E' VUOTA, CICLO INSERIMENTO NELLA TABELLA DEGL INTERVENTI ASSOCIATI AL CONTENUTO
		if (list_int!=null && list_int.size()>0){
			// ciclo for
			for (int i=0; i<list_int.size(); i++){
				// definisco oggetti di inserimento
				def ins_rec = [:];
				ins_rec.cod_content = cod_cont;
				ins_rec.classe_intervento = list_int[i].classe_intervento;
				ins_rec.prog_tipo_intervento = list_int[i].prog_tipo_intervento;
				ins_rec.tipo_intervento = list_int[i].tipo_intervento;
				ins_rec.riferimento_normativo = list_int[i].riferimento_normativo;
				ins_rec.descr_intervento = list_int[i].descr_intervento;
				ins_rec.num_unita_abitative = list_int[i].num_unita_abitative;
				ins_rec.costo_tot_intervento = list_int[i].costo_tot_intervento;
				ins_rec.descr_massimale = list_int[i].descr_massimale;
				log.info("mappa di inserimento: " + ins_rec) ;
				// inserisco il record
				services.classService.insertClassRecord("aim_sch_scheda_intervento_ls", ins_rec);
				
			};
		};
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {	
	
	//GENERO MAPPA TOTALE
	def AllMap = [:] ;
	AllMap.putAll(oldvaluesMap);
	AllMap.putAll(valuesMap);
		
	// recupero codice contenuto
	def cod_content = AllMap.get("cod_content");
	log.info("codice del contenuto: " + cod_content);	
	
	// recupero valore del flag di compilazione
	def is_sch_complete = AllMap.get("is_sch_complete");
	log.info("flag di contenuto completato: " + is_sch_complete);	
	
	// se il flag di compilazione è passato da 0 a 1, allora dichiaro il contenuto completato
	if (valuesMap.is_sch_complete!=null && valuesMap.is_sch_complete==1){		
		// eseguo query di aggiornamento
		services.queryService.executeQuery("UPDATE aim_content SET is_sch_complete=1 WHERE cod_content='" + cod_content + "'",null);	
		};	

	// valorizzo la data di ultima modifica con la data corrente
	valuesMap.put("upload_date",new Date());	
	
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
       return true;
    };

}  