import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
  
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// chiave del record di origine e area del AIM recuperata dall'azione come valore iniziale della mappa
		def id_track_orig = valuesMap.get("id_track_orig");
		def name_track = "AIMTRACK";
		def priority = valuesMap.get("priority");
		def cod_bim_filter = valuesMap.get("cod_bim_filter");
		
		//CALCOLO IL PROGRESSIVO DEL CODICE DEL TEAM
		def num_track = services.queryService.executeQuery("SELECT count(id_track) as num_track FROM AIM_TRACK", null)[0].num_track;
		log.info("loggo il num_track di partenza: "+num_track);
		if(num_track==0){
            num_track=1;
            def num_track_string = StringUtils.leftPad(num_track.toString(), 2, "0");
            valuesMap.put("cod_track",name_track+"_" + num_track_string);
            valuesMap.put("prog",num_track);
        }else {
            def max_prog = services.queryService.executeQuery("SELECT max(prog) as max_prog FROM AIM_TRACK", null)[0].max_prog;
            max_prog=++max_prog;
			log.info("max_prog: "+max_prog);
            def max_prog_string = StringUtils.leftPad(max_prog.toString(), 2, "0");
			log.info("loggo il max_prog_string di arrivo: "+max_prog_string);
            valuesMap.put("cod_track",name_track+"_"+ max_prog_string);
            valuesMap.put("prog",max_prog);
        }	
		
		
		
		// query per recuperare tutti i dati del record di origine
		def track = services.queryService.executeQuery("SELECT * FROM AIM_TRACK where id_track="+id_track_orig, null)[0];
		log.info ("record della TRACK di origine: " + track);

		//controllo che la configurazione della track sia corretta
		def query_chk = services.queryService.executeQuery("SELECT id_track FROM AIM_TRACK WHERE cod_bim_filter='"+cod_bim_filter +"' and priority="+priority,null)[0];
		if(query_chk!=null && query_chk.size()>0){
			throw new RuntimeException("Attenzione: Configurazione track (Permessi + Priorità) già esistente!<br>Modificare uno dei due parametri o entrambi.");
		}
		
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){	

		// mappa dei valori del record inserito
		log.info("mappa dei valori della check list inserita: " + valuesMap);
		log.info("chiave della check-list di origine: " + valuesMap.id_track_orig);
		// recupero il codice della track di origine
		def cod_track_orig=services.queryService.executeQuery("SELECT cod_track AS cod_track_orig FROM AIM_TRACK where id_track="+valuesMap.id_track_orig, null)[0].cod_track_orig;
		log.info("codice della check-list di origine: " + cod_track_orig);
				
		
		/*********************** RECUPERO DEGLI STATI COLLEGATI ALLA TRACK DI ORIGINE*/
		
		// conto il numero di stati collegati alla track di origine	
		def count_status=services.queryService.executeQuery("SELECT count(1) as count_status FROM AIM_TRACK_STATUS where cod_track='"+cod_track_orig + "'", null)[0].count_status;
		log.info("conteggio degli stati collegati alla track di origine: " + count_status);
		
		// se il conteggio è maggiore di 0 allora recupero la lista per l'associazione alla nuova check-list
		if (count_status>0){
			// query per recuperare la lista delle attività associate
			def list_status_orig=services.queryService.executeQuery("SELECT * FROM AIM_TRACK_STATUS where cod_track='"+cod_track_orig + "'", null);
			log.info ("lista degli stati collegati alla track di origine: " + list_status_orig);
			// ciclo l'inserimento delle attività associate alla check-list duplicata
			for(int i=0; i<list_status_orig.size(); i++){
				// definisco l'oggetto per l'inserimento
				def ins_status = [:];
				ins_status.cod_track=valuesMap.cod_track;
				ins_status.is_cloned=1;						
				ins_status.cod_status=list_status_orig[i].cod_status;
				ins_status.uk_track_status=valuesMap.cod_track+list_status_orig[i].cod_status;
				ins_status.ord_track_status=list_status_orig[i].ord_track_status;
				ins_status.icon_name=list_status_orig[i].icon_name;
				ins_status.icon_ctype=list_status_orig[i].icon_ctype;
				ins_status.icon_file=list_status_orig[i].icon_file;				
				// inserisco il records
				services.classService.insertClassRecord('aim_track_status', ins_status);
				
				/*********************** RECUPERO LE AZIONI COLLEGATE AGLI STATI DELLA TRACK DI ORIGINE*/		
				def count_action=services.queryService.executeQuery("SELECT count(id_track_status_action) as count_action FROM AIM_TRACK_STATUS_R_ACTION where cod_track_status='"+list_status_orig[i].uk_track_status+"'",null)[0].count_action;
				log.info("conteggio dei campi addizionali collegati alla check-list di origine: " + count_action);

				// se il conteggio è maggiore di 0 allora recupero la lista per l'associazione alla nuova check-list
				if (count_action!= null && count_action>0){
					 
					def list_action = services.queryService.executeQuery("SELECT * FROM AIM_TRACK_STATUS_R_ACTION where cod_track_status='"+list_status_orig[i].uk_track_status+ "'", null);				
					log.info ("lista dei campi addizionali collegati all'azione di origine: " + list_action);
					
					// ciclo l'inserimento delle azioni associate agli stati della track
					for(int k=0; k<list_action.size(); k++){
						log.info ("list_action[k]: " + list_action[k]);
						log.info ("list_action[k] cde area: " +list_action[k].area);
						//cerco il codice libreria dello stato associato come stato finale
						def status_end_chk = services.queryService.executeQuery("select uk_track_status, cod_status from AIM_TRACK_STATUS where uk_track_status='"+list_action[k].cod_track_status_end+"'",null)[0];
						log.info ("codice end status su tabella track: " + status_end_chk);
						// recupero il nuovo codice stato inserito precedentemente nella nuova track
						def status_end_code = services.queryService.executeQuery("select uk_track_status, cod_status from AIM_TRACK_STATUS where uk_track_status='"+status_end_chk.uk_track_status+"'",null)[0];
						log.info ("vecchio end_status: " + status_end_code);
						log.info ("nuovo codice end_status: " + valuesMap.cod_track+status_end_chk.cod_status);
						// definisco l'oggetto per l'inserimento
						def ins_action = [:];
						ins_action.cod_track_status = valuesMap.cod_track+list_status_orig[i].cod_status;
						ins_action.cod_action_type = list_action[k].cod_action_type;
						ins_action.name_action = list_action[k].name_action;
						ins_action.cod_track_status_end = valuesMap.cod_track+status_end_chk.cod_status;
						ins_action.role_action = list_action[k].role_action;
						ins_action.area = list_action[k].area;						
						// inserisco il record
						//services.classService.insertClassRecord('cde_track_status_r_action', ins_action);
						

		
						//predispongo l'inserimento dei nuovi elaborati generati da IMPORTAZIONE CDE 1.0
						def actionIns = "INSERT INTO AIM_TRACK_STATUS_R_ACTION (cod_track_status, cod_action_type, name_action, cod_track_status_end, role_action)";
						actionIns+=" VALUES ";
						actionIns+="(#{map.cod_track_status},#{map.cod_action_type},#{map.name_action},#{map.cod_track_status_end},#{map.role_action})";
						def ins_act = services.queryService.executeQuery(actionIns,ins_action);
					}	
				}
				
			}
		}
	
		return true;
	};
	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		return true;
	};			
		
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){	
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
	return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
	return true;
	};
};