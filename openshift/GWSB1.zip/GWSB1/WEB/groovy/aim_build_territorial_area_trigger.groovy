//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_build_territorial_area
//note:    il groovy effettua le seguenti operazioni
//         a) blocco cancellazione in caso di oggetti collegati (immobili)
//         b) controllo univocit� nome in inserimento e modifica
//         c) controllo univocit� codice in iserimento e modifica


import org.apache.commons.lang.StringUtils;

public class aim_build_territorial_area_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// CONTROLLO UNIVOCITA' DEL CODICE
		
		// recupero codice ambito gestionale dell'immobile
		def cod_territorial_area = valuesMap.get("cod_territorial_area");
		log.info("codice ambito gestionale: " + cod_territorial_area);

		// conto il numero di fascicoli con lo stesso codice
		def num_cod = services.queryService.executeQuery("SELECT count(1) AS num_cod FROM aim_build_territorial_area WHERE UPPER(cod_territorial_area)=UPPER('" + cod_territorial_area + "')",null)[0].num_cod;
		log.info("numero record: " + num_cod);

		// se il conteggio � maggiore di zero, allora blocco inserimento
		if (num_cod>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='L\'ambito gestionale non puo\' essere inserito.<br>';			
			def warning_check ='In archivio e\' gia\' presente un ambito gestionale con codice <b>' + cod_territorial_area + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
			};


		// CONTROLLO UNIVOCITA' DEL NOME
		
		// recupero nome ambito gestionale dell'immobile
		def name_territorial_area = valuesMap.get("name_territorial_area");
		log.info("nome classificazione: " + name_territorial_area);

		// conto il numero di fascicoli con lo stesso nome
		def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_build_territorial_area WHERE UPPER(name_territorial_area)=UPPER('" + name_territorial_area + "')",null)[0].num_name;
		log.info("numero record: " + num_name);

		// se il conteggio � maggiore di zero, allora blocco inserimento
		if (num_name>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='L\'ambito gestionale non puo\' essere inserito.<br>';			
			def warning_check ='In archivio e\' gia\' presente un ambito gestionale con nome <br><b>' + name_territorial_area + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
			};

		return true;
	};
 


 
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {	

		// CONTROLLO MODIFICA DEL CODICE CON ALTRO GIA' ESISTENTE
		
		// verifico se utente ha modificato il codice ambito gestionale
		if (valuesMap.cod_territorial_area!=null){
			
			def new_cod = valuesMap.cod_territorial_area;
			log.info("nuovo codice assegnato ad ambito gestionale: " + new_cod);
			
			// conto il numero di classificazioni con lo stesso codice
			def num_cod = services.queryService.executeQuery("SELECT count(1) AS num_cod FROM aim_build_territorial_area WHERE cod_territorial_area='" + new_cod + "'",null)[0].num_cod;
			log.info("numero record: " + num_cod);

			// se il conteggio � maggiore di zero, allora blocco modifica
			if (num_cod>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il codice dell\'ambito gestionale non puo\' essere modificato.<br>';			
				def warning_check ='In archivio e\' gia\' presente un ambito gestionale con codice <b>' + new_cod + '</b>.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};


		// CONTROLLO MODIFICA DEL CODICE CON OGGETTI ASSOCIATI (IMMOBILI)
		
		// verifico se utente ha modificato il codice ambito gestionale
		if (valuesMap.cod_territorial_area!=null){
			
			log.info("nuovo codice ambito: " + valuesMap.cod_territorial_area);
			
			def old_cod = oldvaluesMap.cod_territorial_area;
			log.info("codice corrente (in modifica) ambito gestionale: " + old_cod);
			
			// conto il numero di immobili con il codice corrente
			def num_bui = services.queryService.executeQuery("SELECT count(1) AS num_bui FROM gwd_building WHERE cod_territorial_area='" + old_cod + "'",null)[0].num_bui;
			log.info("numero record: " + num_bui);

			// se il conteggio � maggiore di zero, allora blocco modifica
			if (num_bui>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il codice dell\'ambito gestionale non puo\' essere modificato.<br>';			
				def warning_check ='In archivio soon presenti n. <b>' + num_bui + ' immobili </b> associati al codice dell\' <br>ambito gestionale in modifica.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};




		// CONTROLLO MODIFICA DEL NOME CON ALTRO GIA' ESISTENTE
		
		// verifico se utente ha modificato il nome ambito gestionale
		if (valuesMap.name_territorial_area!=null){
			
			def new_name = valuesMap.name_territorial_area;
			log.info("nuovo nome assegnato alla classificazione: " + new_name);
			
			// conto il numero di classificazioni con lo stesso nome
			def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_build_territorial_area WHERE UPPER(name_territorial_area)=UPPER('" + new_name + "')",null)[0].num_name;
			log.info("numero record: " + num_name);

			// se il conteggio � maggiore di zero, allora blocco inserimento
			if (num_name>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il nome dell\'ambito gestionale non puo\' essere modificata.<br>';			
				def warning_check ='In archivio e\' gia\' presente un ambito gestionale con nome <br><b>' + new_name + '</b>.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};

	
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		
		// RECUPERO IDENTIFICATIVI OGGETTO IN CANCELLAZIONE

		// recupero la chiave del record
		Integer id = valuesMap.id_territorial_area;
		log.info("chiave del record in cancellazione: " + id);
		
		// recupero il valore del codice in cancellazione
		String cod_rec_del = services.queryService.executeQuery("SELECT cod_territorial_area AS cod_rec_del from aim_build_territorial_area where id_territorial_area=" + id,null)[0].cod_rec_del;			
		log.info("codice del record in cancellazione: " + cod_rec_del);


		// CONTROLLO OGGETTI ASSOCIATI AL CODICE IN CANCELLAZIONE (MMOBILI)
		
		// conto il numero di oggetti caratterizzati dal vecchio valore del codice (immobili)
		Integer count_object_del = services.queryService.executeQuery("SELECT count(1) AS count_object_del FROM gwd_building where cod_territorial_area='" + cod_rec_del + "'",null)[0].count_object_del;
		log.info("numero di oggetti associato al vecchio codice  " + cod_rec_del + ": " + count_object_del);
		
		// se il conteggio � maggiore di zero allora blocco la modifica e visualizzo un messaggio di errore
		if (count_object_del>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='L\'ambito gestionale non puo\' essere eliminato.<br>';			
			def warning_check ='Sono presenti n. <b>' + count_object_del + ' immobili </b> associati all\'ambito gestionale.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);		
		};		
		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  