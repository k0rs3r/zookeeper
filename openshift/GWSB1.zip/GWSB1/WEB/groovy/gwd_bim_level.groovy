//user:    APA
//date:    16/01/2020
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_bim_level
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();
		valuesMapAll.putAll(oldValuesMap);
		valuesMapAll.putAll(valuesMap);
		def isStructureExist = services.queryService.executeQuery("SELECT structure_code FROM gwd_bim_model_structure where project=#{map.cod_project} and level=#{map.level_order}", valuesMapAll);
		if(isStructureExist!=null && isStructureExist.size()>0){
			throw new Exception("Impossibile modificare il livello perchè già associato ad una struttura BIM");
		}	
		return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){		
	    def pkBimLevel = valuesMap.pk_bim_level;
		def bimLevelRes = services.queryService.executeQuery("SELECT level_order, cod_project FROM gwd_bim_level where pk_bim_level="+pkBimLevel, null)[0];
		def isStructureExist = services.queryService.executeQuery("SELECT structure_code FROM gwd_bim_model_structure where project=#{map.project} and level=#{map.level_order}", [level_order: bimLevelRes.level_order, project: bimLevelRes.cod_project]);
		if(isStructureExist!=null && isStructureExist.size()>0){
			throw new Exception("Impossibile modificare il livello perchè già associato ad una struttura BIM");
		}
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 