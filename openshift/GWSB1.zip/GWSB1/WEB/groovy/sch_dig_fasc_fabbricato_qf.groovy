public class sch_dig_fasc_fabbricato_qf extends com.geowebframework.transfer.objects.digitaldocument.GwDigitalDocumentConfigImpl {
	
	public Boolean isVisible(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){

		log.error("templateName: "+templateName);
		log.error("sectionName: "+sectionName);
		log.error("entityName: "+entityName);
		log.error("entityStatus: "+entityStatus);
		def isVisible = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qf")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QF_01")||
				sectionName.equals("QF_02")||
				sectionName.equals("QF_03")||
				sectionName.equals("QF_04")||
				sectionName.equals("QF_05")||
				sectionName.equals("QF_99")
			)
				{
					isVisible = true;
					log.error("isVisible = true");
				}
			
		}
		log.error("isVisible: "+isVisible);
		return isVisible;
	}
	public Boolean isEditable(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isEditable = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qf")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QF_01")||
				sectionName.equals("QF_02")||
				sectionName.equals("QF_03")||
				sectionName.equals("QF_04")||
				sectionName.equals("QF_05")||
				sectionName.equals("QF_99")
			)
				{
					isEditable = true;
				}
			
		}
		return isEditable;
	}
	
	public Boolean isDefaultSelected(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isDefaultSelected = false;
		return isDefaultSelected;
	}

}