import com.geowebframework.dataservice.ListService;
import java.io.BufferedOutputStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.activation.MimetypesFileTypeMap;
import org.apache.commons.io.IOUtils;
import java.nio.file.Path;
import java.nio.file.Paths;
import com.opencsv.CSVReader;

class CDEAIM_GenericFunction {

    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger("com.geowebframework.groovy");
    private static final int BUFFER_SIZE = 4096;
	
	def services;
	void init(s) {
		 services=s;
	}
	  
	public   byte[] unzip(/*String zipFilePath,*/ZipInputStream zipIn, String destDirectory) throws IOException {
        File destDir = new File(destDirectory);
		 byte[] data =null;
        //HashMap<String, String> estensioniFileTrovati=new   HashMap<String, String>();
        if (!destDir.exists()) {
            destDir.mkdir();
        }
       // ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();
        // iterates over entries in the zip file
        while (entry != null) {
        	String  entryName = entry.getName();
        	if (entryName.endsWith("zip")) throw new IOException();
        	
            String filePath = destDirectory + File.separator + entry.getName();
            String estenzione=filePath.substring(filePath.indexOf(".") + 1);
            //estensioniFileTrovati.put(estenzione.toUpperCase(), estenzione.toUpperCase());
            
            if (!entry.isDirectory()) {
                // if the entry is a file, extracts it
                extractFile(zipIn, filePath);
				 if (entryName.endsWith(".csv")){
					 data = Files.readAllBytes(Paths.get(filePath));
				 }
            } else {
                // if the entry is a directory, make the directory
                File dir = new File(filePath);
                dir.mkdir();
                //throw new IOException();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
        return data;
    }
    /**
     * Extracts a zip entry (file entry)
     * @param zipIn
     * @param filePath
     * @throws IOException
     */
    private void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        while ((read = zipIn.read(bytesIn)) != -1) {
            bos.write(bytesIn, 0, read);
        }
        bos.close();
    }
	
	
	public   byte[] getCsvFileIntoZip(ZipInputStream zipIn) throws IOException {
        
		byte[] data =null;
		ZipEntry entry = zipIn.getNextEntry();
        while (entry != null) {
        	String  entryName = entry.getName();    
			if (!entry.isDirectory()) {
				 if (entryName.endsWith(".csv") ){
				  InputStreamReader inputStreamReader = new InputStreamReader(zipIn);
				 /* CSVReader reader = new CSVReader(inputStreamReader);
				   String[] header = reader.readNext();
					log.info("HEADER CSV:"+header.toString());*/
					data=IOUtils.toByteArray(zipIn);
					log.info("Nome csv trovato:"+entryName);
				 }
			} 
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
        return data;
    }
	
	
	public  HashMap<String,Object>  getGenericFileIntoZipFromNameFile(/*String zipFilePath,*/ZipInputStream zipIn,String pathFile) throws IOException {
        
		HashMap<String,Object>  map=new HashMap<String,Object>();
		ZipEntry entry = zipIn.getNextEntry();
        while (entry != null) {
        	String  entryName = entry.getName();  
			log.debug("NOME ENTITA CORRENTE"+entryName);
			log.debug("NOME PATH CORRENTE DA CERCARE"+pathFile);
			 Path path = Paths.get(entryName);
			 //log.debug("PATH ENTITA CORRENTE"+path.toString());
			if (!entry.isDirectory()) {
				 if (entryName.contains(pathFile)){
					MimetypesFileTypeMap mtft = new MimetypesFileTypeMap();
					String mimeType = mtft.getContentType(entry.getName());
					String nameFile=entry.getName();
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					IOUtils.copy(zipIn, out);
					InputStream is = new ByteArrayInputStream(out.toByteArray());
					String name = nameFile.substring(nameFile.lastIndexOf("/")+1,nameFile.length() );
					
					map.put("mimeType",mimeType);
					map.put("is",is);
					map.put("nameFile",name);
					map.put("length",entry.getSize());
				 }
			} 
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
        return map;
    }	
	
	
	

	public  HashMap<String,Object>  getGenericFileIntoZip(/*String zipFilePath,*/ZipInputStream zipIn,String pathFile) throws IOException {
        
		HashMap<String,Object>  map=new HashMap<String,Object>();
		ZipEntry entry = zipIn.getNextEntry();
        while (entry != null) {
        	String  entryName = entry.getName();  
			log.debug("NOME ENTITA CORRENTE"+entryName);
			log.debug("NOME PATH CORRENTE DA CERCARE"+pathFile);
			 Path path = Paths.get(entryName);
			 //log.debug("PATH ENTITA CORRENTE"+path.toString());
			if (!entry.isDirectory()) {
				 if (entryName.contains(pathFile)){
					MimetypesFileTypeMap mtft = new MimetypesFileTypeMap();
					String mimeType = mtft.getContentType(entry.getName());
					String nameFile=entry.getName();
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					IOUtils.copy(zipIn, out);
					InputStream is = new ByteArrayInputStream(out.toByteArray());
					String name = nameFile.substring(nameFile.lastIndexOf("/")+1,nameFile.length() );
					
					map.put("mimeType",mimeType);
					map.put("is",is);
					map.put("nameFile",name);
					map.put("length",entry.getSize());
				 }
			} 
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
        return map;
    }	
}
