//user:    MPE 
//date:    14/01/2017
//ver:     4.2.5
//project: cde
//type:    event trigger (TRIGGER DI CLASSE)
//class:   cde_doc_subcod04
//note:    inserire descrizione completa

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		//gestisco il popolamento automatico dei seguenti campi
		valuesMap.put("is_first_status",0);
		valuesMap.put("is_last_status",0);
		//recupero l'area del CDE assegnata allo status
		String cod_aim_area = valuesMap.get("cod_aim_area");
		
		//conto il progressivo per area
		def count_area = services.queryService.executeQuery("SELECT count(id_content_status) as count_area FROM aim_content_status WHERE cod_aim_area='"+cod_aim_area+"'", null)[0].count_area;
		log.info("count_area: "+count_area);
		if(count_area==0){
			count_area=1;
			valuesMap.put("prog_status",count_area);
			valuesMap.put("cod_content_status",cod_aim_area + StringUtils.leftPad(count_area.toString(), 2, "0"));
			}else {
				
			def max_area = services.queryService.executeQuery("SELECT max(prog_status) as max_area FROM aim_content_status WHERE cod_aim_area='"+cod_aim_area+"'", null)[0].max_area;
			max_area=max_area++;
			log.info("max_area: "+max_area++);
			valuesMap.put("prog_status",max_area);
			valuesMap.put("cod_content_status",cod_aim_area + StringUtils.leftPad(max_area.toString(), 2, "0"));
			}

		
		

		
		//CONTROLLO CHE NON VENGANO INSERITI PIù DI UNO STATUS CON LO STESSO NOME
		String descr_content_status = valuesMap.get("descr_content_status");
		
		//controllo che la configurazione della track sia corretta
		def query_chk = services.queryService.executeQuery("SELECT id_content_status FROM aim_content_status WHERE descr_content_status='"+descr_content_status +"'",null)[0];
		if(query_chk!=null && query_chk.size()>0){
			throw new RuntimeException("ATTENZIONE! Il nome utilizzato e' gia' in uso. <br>Selezionare una  nome differente");
		}
		
		
		
		
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
			
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		//CONTROLLO CHE NON VENGANO INSERITI PIù DI UNO STATUS CON LO STESSO NOME
		String descr_content_status = valuesMap.get("descr_content_status");
		
		//controllo che la configurazione della track sia corretta
		def query_chk = services.queryService.executeQuery("SELECT id_content_status FROM aim_content_status WHERE descr_content_status='"+descr_content_status +"'",null)[0];
		if(query_chk!=null && query_chk.size()>0){
			throw new RuntimeException("ATTENZIONE! Il nome utilizzato e' gia' in uso. <br>Selezionare una  nome differente");
		}
		
		
        return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
			
		
        return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		//controllo se esistono cde_deliverable associate a tale livello
		def pkStatus = valuesMap.id_deliverable_status;
		log.info("loggo il "+pkStatus);
		def status = services.queryService.executeQuery("SELECT cod_deliverable_status FROM cde_deliverable_status where id_deliverable_status="+pkStatus,null)[0];
		log.info("loggo la query: "+status);
		def num_track_status = services.queryService.executeQuery("SELECT count(id_track_status) as num_track_status FROM cde_track_status where cod_track_status='"+status.cod_deliverable_status+"'",null)[0].num_track_status;
		log.info("loggo il numero di track associate: "+num_track_status)
		if(num_track_status>0){
			throw new RuntimeException("ATTENZIONE! Una o più track sono associate a questo stato. <br>Per cancellarlo è necessario dissociare le relative track");
		}

		
		
		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 