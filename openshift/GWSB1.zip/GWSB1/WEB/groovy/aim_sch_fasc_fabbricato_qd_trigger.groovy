//user:    MPE 
//date:    22/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    class groovy
//class:   aim_sch_fasc_fabbricato_qd
//note:    il trigger effettua le seguenti operazioni:
//		   - aggiornamento stato di compilazione contenuto collegato
//         - popolamento tabella oggetti impianti idrico 
//         - popolamento tabella oggetti impianto fognario

public class aim_sch_fasc_fabbricato_qd_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		// RECUPERO INFO DI INTERESSE
		
		def cod_content = valuesMap.get("cod_content");
		log.info("codice del contenuto di riferimento: " + cod_content);

		// definisco variabili per inserimento impianto idrico
		def idr_descr = null;
		def idr_ord = null;

		// definisco variabili per inserimento impianto fognatura
		def fgn_descr = null;
		def fgn_ord = null;
		

		// INSERISCO RIGHE SU TABELLA OGGETTI RETE IDRICA
		
		// inserisco Tubazioni acqua
		idr_descr = 'Tubazioni acqua';
		idr_ord = 1;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

		// inserisco Tubazioni acqua Condutture acqua calda
		idr_descr = 'Condutture acqua calda';
		idr_ord = 2;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);
		
		// inserisco Condutture acqua fredda
		idr_descr = 'Condutture acqua fredda';
		idr_ord = 3;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);
		
		// inserisco Centrale idrica
		idr_descr = 'Centrale idrica';
		idr_ord = 4;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);
		
		// inserisco Altro
		idr_descr = 'Altro';
		idr_ord = 5;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);
		
		
		// INSERISCO RIGHE SU TABELLA OGGETTI RETE FOGNARIA
		
		// inserisco Gronde
		idr_descr = 'Gronde';
		idr_ord = 1;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);
			
		// inserisco Pluviali
		idr_descr = 'Pluviali';
		idr_ord = 2;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

		// inserisco Scarichi verticali
		idr_descr = 'Scarichi verticali';
		idr_ord = 3;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

		// inserisco Scarichi orizzontali
		idr_descr = 'Scarichi orizzontali';
		idr_ord = 4;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

		// inserisco Pozzetti
		idr_descr = 'Pozzetti';
		idr_ord = 5;
		services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

		// inserisco Altro
		idr_descr = 'Altro';
		idr_ord = 6;
	services.queryService.executeQuery("INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,ord) VALUES (nextval('seq_fb'),'" + cod_content + "','" + idr_descr + "'," + idr_ord + ")",null);

	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

	//GENERO MAPPA TOTALE
	def AllMap = [:] ;
	AllMap.putAll(oldvaluesMap);
	AllMap.putAll(valuesMap);
		
	// recupero codice contenuto
	def cod_content = AllMap.get("cod_content");
	log.info("codice del contenuto: " + cod_content);	
	
	// recupero valore del flag di compilazione
	def is_sch_complete = AllMap.get("is_sch_complete");
	log.info("flag di contenuto completato: " + is_sch_complete);	
	
	// se il flag di compilazione è passato da 0 a 1, allora dichiaro il contenuto completato
	if (valuesMap.is_sch_complete!=null && valuesMap.is_sch_complete==1){		
		// eseguo query di aggiornamento
		services.queryService.executeQuery("UPDATE aim_content SET is_sch_complete=1 WHERE cod_content='" + cod_content + "'",null);	
		};

	// valorizzo la data di ultima modifica con la data corrente
	valuesMap.put("upload_date",new Date());	
		
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 