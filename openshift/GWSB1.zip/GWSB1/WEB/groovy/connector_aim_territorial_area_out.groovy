//user:    MPE
//date:    30/01/2020
//ver:     4.4.8
//project: CA_ConnectorControl
//type:    connettor trigger
//class:   varie 
//note:    groovy per trasferimento ambiti gestionali (da AIM a MASTER DATA / RISK & COMPLIANCE)
//         sistema di origine: AIM
// 		   database origine = SUPERBONUS
//		   schema origine = cde_dati_gw
//		   tabella/vista origine = v_cnt_territorial_area_out

//		   sistema di destinazione = MASTER DATA
//		   database destinazione = SUPERBONUS
//		   schema destinazione = data_gw
//		   tabella destinazione = cnt_aim_territorial_area_out


// AVVIO CONNETTORE
log.info("INIZIO ESECUZIONE CONNETTORE cnt_aim_territorial_area_out " + new Date());

// CONTROLLO SE CI SONO RECORD NELLA VISTA DI PREDISPOSIZIONE DATI
def count_rec_orig = queryService.executeQuery("SELECT COUNT (1) AS count_rec_orig FROM v_cnt_territorial_area_out",null)[0].count_rec_orig;
log.info("numero record nella vista v_cnt_territorial_area_out: " + count_rec_orig);

// SE IL CONTEGGIO DEI RECORD NELLA VISTA DI PREDISPOSIZIONE DATI E' PARI A ZERO, INSERISCO EVENTO
if (count_rec_orig==0){
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_territorial_area_out';
	ins_event.date_start = new Date();
	ins_event.date_end = new Date();
	ins_event.record_insert = count_rec_orig;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'Non sono presenti ambiti gestionali degli immobili da trasferire.';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);
	};


// SE CI SONO, PROCEDO
if (count_rec_orig>0){
	def date_start = new Date(); 
	log.info("data e ora di inizio connettore: " + date_start);
	// recupero lista di record da inserire
	def list_record = queryService.executeQuery("SELECT * FROM v_cnt_territorial_area_out",null);
	log.info("elenco dei record da inserire: " + list_record);
	// definisco query di svuotamento della tabella del connettore
	def query_del = "DELETE FROM data_gw.aim_cnt_territorial_area_out";
	// eseguo query di svuotamento della tabella del connettore
	queryService.executeQuery(query_del ,null);	
	// ciclo inserimento
	for (int i=0; i<list_record.size(); i++){	
		// POPOLAMENTO TABELLA CONNETTORE
		// definisco query di inserimento nella tabella di appoggio del connettore
		def query_ins = "INSERT INTO data_gw.aim_cnt_territorial_area_out (cod_territorial_area,name_territorial_area,date_record_in) VALUES ('" + list_record[i].cod_territorial_area + "','" + list_record[i].name_territorial_area + "',current_timestamp)";		
		log.info("query di inserimento record " + i + ": " + query_ins);
		// eseguo query di inserimento nella tabella di appoggio del connettore
		queryService.executeQuery(query_ins ,null);
		};
	def num_record_ins = list_record.size();
	log.info("numero di record inseriti: " + num_record_ins);
	
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_territorial_area_out';
	ins_event.date_start = date_start
	ins_event.date_end = new Date();
	ins_event.record_insert = num_record_ins;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'E\' stata trasferita l\'anagrafica degli ambiti gestionali degli immobili (n. ' +  num_record_ins + ' record).';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);	

	};
	
	
	
	


// FINE CONNETTORE
log.info("FINE ESECUZIONE CONNETTORE cnt_aim_territorial_area_out " + new Date());