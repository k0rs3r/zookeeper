//user:    ABA 
//date:    27/02/2019
//ver:     4.2.5
//project: cde
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_class_archive

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import org.springframework.context.i18n.LocaleContextHolder;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		String cod_class_arc = valuesMap.get("cod_class_arc");
		//CONTROLLO CHE IL CODICE CATEGORIA SIA UNIVOCO
		def query = services.queryService.executeQuery("SELECT id_class_arc FROM aim_class_archive WHERE cod_class_arc='"+valuesMap.cod_class_arc+"'", null)[0];
		if(query!=null && query.size()>0){
			throw new RuntimeException("ATTENZIONE: Codice già in uso!");
		}	
		
		
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){

		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
	//predispongo l'eliminazione dei valori della classe aim_class_subcategory
	def pkArc = valuesMap.id_class_arc;
	def selectCode = "SELECT cod_class_arc FROM aim_class_archive where id_class_arc="+pkArc;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukArc = result.cod_class_arc;
	log.info("loggo ukArc: "+ukArc)
	def del = services.queryService.executeDeleteQuery("DELETE FROM aim_class_category WHERE cod_class_arc='"+ukArc+"'",null);
	def del1 = services.queryService.executeDeleteQuery("DELETE FROM aim_content_classification WHERE cod_class_arc='"+ukArc+"'",null);
	//controllo se ci sono dei contenuti associati alla categoria in sessione
	def numContent = services.queryService.executeQuery("SELECT count(id_content) as numContent FROM aim_content WHERE cod_class_arc='"+ukArc+"'", null)[0].numContent;
	if(numContent>0){
			
			throw new RuntimeException("Impossibile eliminare questo ARCHIVIO.<br>Sono presenti contenuti ad esso associati.");
	}
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 