//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_track_status
//note:    il groovy effettua le seguenti operazioni
//         a) calcolo del codice della track
//         b) blocco cancellazione in caso di contenuti collegati
//         c) cancello stati in caso di contenuti non collegati


import org.apache.commons.lang.StringUtils;

public class aim_track_status_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		// CONTROLLO CHE NON VENGA INSERITO ORDINE GIS' PRESENTE
		
		// recupero ordine inserito dall'utente
		def ord_rec = valuesMap.ord_track_status;
		log.info("ordine del record: " + ord_rec);
		
		// recupero codice della track
		def cod_track = valuesMap.cod_track;
		log.info("codice della track di riferimento: " + cod_track);
		
		// recupero codice dello stato
		def cod_status = valuesMap.cod_status;
		log.info("codice dello stato: " + cod_status);
		
		// verifico se esiste altro stato per la track con lo stesso ordine
		def count_ord_rec = services.queryService.executeQuery("SELECT COUNT(1) AS count_ord_rec FROM aim_track_status WHERE cod_track='" + cod_track + "' AND ord_track_status=" + ord_rec,null)[0].count_ord_rec;
		log.info("numero di record con stesso ordine e track: " + count_ord_rec);
		
		// se il conteggio è maggiore di zero, allora blocco inserimento 
		if (count_ord_rec>0){			
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Lo stato non puo\' essere inserito.<br>';			
			def warning_check ='E\' gia\' presente uno stato con progressivo ' + ord_rec + '.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);					
			}
		
		// se il conteggio è pari a zero, procedo e calcolo il codice univoco
		
		else if (count_ord_rec==0){
			// calcolo il codice univoco dello stato
			def cod_uk = cod_track + cod_status;
			log.info("codice univoco: " + cod_uk);
			// assegno codice univoco
			valuesMap.put("uk_track_status",cod_uk);
			};

		
		return true;
	};


	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};


	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){

		// CONTROLLO MODIFICA DELL'ORDINAMENTO
				
		// recupero codice della track
		def cod_track = oldValuesMap.cod_track;
		log.info("codice della track di riferimento: " + cod_track);		

		// recupero valore corrente dell'ordine
		def ord_track_status = valuesMap.ord_track_status;
		log.info("valore corrente dell'ordine: " + ord_track_status);
		
		// se l'utente ha modificato ordine, controllo se è già presente
		if (valuesMap.ord_track_status!=null){
			// conto stati con lo stesso ordine e track
			def count_ord_rec = services.queryService.executeQuery("SELECT COUNT(1) AS count_ord_rec FROM aim_track_status WHERE cod_track='" + cod_track + "' AND ord_track_status=" + ord_track_status,null)[0].count_ord_rec;
			log.info("numero di record con stesso ordine e track: " + count_ord_rec);			
			
			// se il conteggio è maggiore di zero, blocco modifica
			if (count_ord_rec>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il progressivo dello stato non puo\' essere modificato.<br>';			
				def warning_check ='E\' gia\' presente uno stato con progressivo ' + ord_track_status + '.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);					
				};			
			};
			
			
		return true;
	};


	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		return true;
	};


	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		// recupero chiave del record in cancellazione
		def pk_rec = valuesMap.id_track_status;
		log.info("chiave del record in cancellazione: " + pk_rec);
		
		// recupero codice del record in cancellazione
		def cod_rec_del = services.queryService.executeQuery("SELECT uk_track_status AS cod_rec_del FROM aim_track_status WHERE id_track_status=" + pk_rec,null)[0].cod_rec_del;7
		log.info("codice del record in cancellazione: " + cod_rec_del);
		
		// conto il numero di record che hanno il codice della track in cancellazione 
		def num_rec_del = services.queryService.executeQuery("SELECT COUNT(1) AS num_rec_del FROM v_aim_content WHERE status_approval='" + cod_rec_del + "'",null)[0].num_rec_del;
		log.info("numero di record associati al record in cancellazione: " + num_rec_del);
		
		// se il conteggio è maggiore di zero, blocco cancellazione
		if (num_rec_del>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Lo stato della track non puo\' essere eliminato.<br>';			
			def warning_check ='Sono presenti n. <b>' + num_rec_del + '</b> contenuti associati.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);		
		}
		
		// se il conteggio è pari a zero, passo il codice all'after delete per la cancellazione degli stati
		else if (num_rec_del==0){
			valuesMap.cod_delete=cod_rec_del;
			log.info("codice della track in eliminazione: " + valuesMap.cod_delete);
			};		
				
		return true;
	};


	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		
        // recupero codice della track eliminata
        def cod_delete = valuesMap.cod_delete;
        log.info("chiave della track eliminata: " + cod_delete);
		
        // cancello gli stati
		def delete_records = services.queryService.executeQuery("DELETE FROM aim_track_status_r_action WHERE cod_track_status='" + cod_delete + "'",null);
		log.info("cancellazione: " + delete_records);		
		
		return true;
	};
	
}
