//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_bim_filter
//note:    il groovy effettua le seguenti operazioni
//         a) controlla univocità del nome del filtro
//         b) calcolo il codice univoco del filtro
//         c) popolo la tabella di associazione agli immobili

import org.apache.commons.lang.StringUtils;

public class aim_bim_filter_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
	// CONTROLLO UNIVOCITA' DEL NOME DEL FILTRO
	// recupero nome del filtro
	def name_bim_filter = valuesMap.get("name_bim_filter");
	log.info("nome del filtro: " + name_bim_filter);
	
	// conto il numero di filtri con lo stesso nome
	def num_name = services.queryService.executeQuery("SELECT COUNT(1) AS num_name FROM aim_bim_filter WHERE name_bim_filter='" + name_bim_filter + "'", null)[0].num_name;
	log.info("numero di record con stesso nome: " + num_name);
			
	// se il conteggio è maggiore di zero, blocco inserimento
	if (num_name>0){	
		// configuro il messaggio di alert	
		def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
		def warning_info ='La regola ACL non puo\' essere inserita.<br>';			
		def warning_check ='E\' gia\' presente una regola con lo stesso nome.';			
		def warning_message = warning_title + warning_info + warning_check;
		throw new RuntimeException(warning_message);				
		}	
	
	// se il conteggio è uguale a zero, calcolo codice univoco del filtro
		else if (num_name==0) {
			
			// istanzio variabili del codice e del progressivo
			def prog = null;
			def cod = null;			
			
			// conto il numero di record della tabella
			def num_rec = services.queryService.executeQuery("SELECT COUNT(1) AS num_rec FROM aim_bim_filter", null)[0].num_rec;
			log.info("numero di record della tabella: " + num_rec);
			
			// se il conteggio è pari a zero, assegno al progressivo il valore 1
			if (num_rec==0){prog = 1}
			
			// se il conteggio è maggiore di zero, assegno al progressivo il valore max prog + 1 
			else if (num_rec>0){
				// recupero il valore massimo del progressivo
				def max_prog = services.queryService.executeQuery("SELECT MAX(prog) AS max_prog FROM aim_bim_filter", null)[0].max_prog;
				log.info("valore max del progressivo in tabella: " + max_prog);
				// assegno al progressivo max + 1
				prog = max_prog + 1;
				};
			log.info("valore da assegnare al progressivo: " + prog);
			
			// calcolo il codice della regola
			cod = 'AIM_FILTER_' + StringUtils.leftPad(prog.toString(), 2, "0");
			
			// valorizzo progressivo e codice regola
			valuesMap.put("prog",prog);
			valuesMap.put("cod_bim_filter",cod);
			
		};
					
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){

		// RECUPERO TIPO DI DATABASE
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);

		// RECUPERO I DATI DI INTERESSE
		
		// classificazione immobile
		def cod_building_class = valuesMap.cod_building_class;
		log.info("classificazione immobile: " + cod_building_class);
		
		// ambito gestionale immobile
		def cod_geo_filter = valuesMap.cod_geo_filter;
		log.info("ambito gestionale immobile: " + cod_geo_filter);
		
		// forma del contenuto
		def cod_content_type = valuesMap.cod_content_type;
		log.info("forma del contenuto: " + cod_content_type);
		
		// classe del contenuto
		def cod_class_filter = valuesMap.cod_class_filter;		
		log.info("classe del contenuto: " + cod_class_filter);

		// codice del filtro
		def cod_bim_filter = valuesMap.cod_bim_filter;
		log.info("codice del filtro: " + cod_bim_filter);
		
		// codice dell'immobile (scelta singola)
		def cod_building = valuesMap.cod_building;
		log.info("codice dell'immobile: " + cod_building);


		// RECUPERO IMMOBILI DI INTERESSE PER ACL

		// istanzio variabile della query di ricerca degli immobili
		def queryBuilding = null;
		
		// A) se ambito gestionale è nullo, classe immobile è nullo e codice immobile singolo è nullo prendo tutti gli edifici 
		if (cod_geo_filter==null && cod_building_class==null && cod_building==null){
			log.info("insert caso A");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING ",null);
			log.info("edifici per filtri nulli: "+queryBuilding);
			}
		// B) se ambito gestionale è nullo e classe immobile non è nullo e codice immobile singolo è nullo, prendo solo gli edifici della classe immobili
		else if (cod_geo_filter==null && cod_building_class!=null && cod_building==null){
			log.info("insert caso B");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building_classification='" + cod_building_class + "'",null);
			log.info("edifici per classe immobile non nullo: "+queryBuilding);			
			}
		// C) se ambito non è nullo e classe immobile è nullo e codice immobile singolo è nullo, prendo solo gli edifici dell'ambito
		else if (cod_geo_filter!=null && cod_building_class==null && cod_building==null){
			log.info("insert caso C");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='" + cod_geo_filter + "'",null);
			log.info("edifici per ambito immobile non nullo: "+queryBuilding);				
		}
		// D) se ambito è non nullo e classe immobile è non nullo e codice immobile singolo è nullo, prendo solo gli edifici dell'ambito e della classe
		else if(cod_geo_filter!=null && cod_building_class!=null && cod_building==null){
			log.info("insert caso D");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='" + cod_geo_filter + "' AND cod_building_classification='" + cod_building_class + "'",null);
			log.info("edifici per ambito immobile non nullo: "+queryBuilding);			
			}
		// E) se ambito è nullo, classe immobile è nullo e codice immobile non è nullo
		else if (cod_geo_filter==null && cod_building_class==null && cod_building!=null){
			log.info("insert caso E");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building='" + cod_building + "'",null);
			log.info("edifici per scelta immobile singolo: "+queryBuilding);				
			
		};	
			
		log.info("esito finale query immobili di interesse del filtro: " + queryBuilding);
		
		// SE LA QUERY NON é NULLA, CICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_BUILDING
		if (queryBuilding!=null && queryBuilding.size()>0){
			for(int k=0; k<queryBuilding.size(); k++){
				queryBuilding[k].cod_bim_filter=cod_bim_filter;	

				// caso A - database = SQLServer
				if (db_type=='SQLServer'){				
					def buildIns = "INSERT INTO aim_bim_filter_r_building (cod_bim_filter, cod_building)";
					buildIns+=" VALUES ";
					buildIns+="(#{map.cod_bim_filter},#{map.cod_building})";
					def ins_build = services.queryService.executeQuery(buildIns,queryBuilding[k]);							
					};				
				
				// caso B - database = Postgres
				if (db_type=='Postgres'){
					def buildIns = "INSERT INTO aim_bim_filter_r_building (id_filter_r_building,cod_bim_filter,cod_building)";
					buildIns+=" VALUES ";
					buildIns+="(nextval('seq_fb'),#{map.cod_bim_filter},#{map.cod_building})";
					def ins_build = services.queryService.executeQuery(buildIns,queryBuilding[k]);
					};				

				
				// VERIFICO SE CI SONO CONTENUTI, NEL CASO LI RECUPERO E LI CICLO PER IMMOBILE
				
				// istanzio variabile della query di ricerca dei contenuti
				def queryContent = null;
				
				// istanzio variabile della classe dei contenuti
				def class_type = null;
				
				// recupero la classificazione dei contenuti
				def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='" + cod_class_filter + "'",null);
				log.info("classificazione del filtro: " + classFilter);
				
				// se è presente una classificazione allora recupero i contenuti di interesse del filtro
				if (classFilter!=null && classFilter[0]!=null){class_type = classFilter[0].class_type};
				
				// A) forma non nulla, classificazione a livello di archivio
				if (cod_content_type!=null && class_type=='A'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione a livello di archivio: " + queryContent);			
					}
				// B) forma non nulla, classificazione a livello di categoria
				else if (cod_content_type!=null && class_type=='C'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione a livello di categoria: " + queryContent);				
					}
				// C) forma nulla, classificazione a livello di archivio
				else if (cod_content_type==null && class_type=='A'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione a livello di archivio: " + queryContent);			
					}		
				// D) forma nulla, classificazione a livello di categoria
				else if (cod_content_type==null && class_type=='C'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione a livello di categoria: " + queryContent);				
					}		
				// E) forma non nulla, classificazione nulla
				else if (cod_content_type!=null && cod_class_filter==null){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione nulla: " + queryContent);						
					}
				// F) forma nulla, classificazione nulla
				else if (cod_content_type==null && cod_class_filter==null){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione nulla: " + queryContent);						
					};
				log.info("esito finale query classificazione di interesse del filtro: " + queryContent);	
				
				
				// SE LA QUERY NON é NULLA, CICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_CONTENT
				if (queryContent!=null && queryContent.size()>0){
					for(int j=0; j<queryContent.size(); j++){
											
					// caso A - database = SQLServer
						if (db_type=='SQLServer'){				
							def ContIns = "INSERT INTO aim_bim_filter_r_content (cod_bim_filter, cod_content)";
							ContIns+=" VALUES ";
							ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
							def ins_cont = services.queryService.executeQuery(ContIns,queryContent[j]);							
							};				
						
						// caso B - database = Postgres
						if (db_type=='Postgres'){
							def ContIns = "INSERT INTO aim_bim_filter_r_content (id_filter_r_content,cod_bim_filter,cod_content)";
							ContIns+=" VALUES ";
							ContIns+="(nextval('seq_fb'),#{map.cod_bim_filter},#{map.cod_content})";
							def ins_cont = services.queryService.executeQuery(ContIns,queryContent[j]);
							};							
						};		
					};								
				};			
			};
		
/*			
		
		// RECUPERO CLASSIFICAZIONI DI INTERESSE PER ACL
		
		// istanzio variabile della query di ricerca dei contenuti
		def queryContent = null;
		
		// istanzio variabile della classe dei contenuti
		def class_type = null;
		
		// recupero la classificazione dei contenuti
		def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='" + cod_class_filter + "'",null);
		log.info("classificazione del filtro: " + classFilter);
		
		// se è presente una classificazione allora recupero i contenuti di interesse del filtro
		if (classFilter!=null && classFilter[0]!=null){class_type = classFilter[0].class_type};
		
		// A) forma non nulla, classificazione a livello di archivio
		if (cod_content_type!=null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "'",null);
			log.info("contenuti per forma non nulla e classificazione a livello di archivio: " + queryContent);			
			}
		// B) forma non nulla, classificazione a livello di categoria
		else if (cod_content_type!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "'",null);
			log.info("contenuti per forma non nulla e classificazione a livello di categoria: " + queryContent);				
			}
		// C) forma nulla, classificazione a livello di archivio
		else if (cod_content_type==null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "'",null);
			log.info("contenuti per forma nulla e classificazione a livello di archivio: " + queryContent);			
			}		
		// D) forma nulla, classificazione a livello di categoria
		else if (cod_content_type==null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "'",null);
			log.info("contenuti per forma nulla e classificazione a livello di categoria: " + queryContent);				
			}		
		// E) forma non nulla, classificazione nulla
		else if (cod_content_type!=null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='"+cod_content_type+"'",null);
			log.info("contenuti per forma non nulla e classificazione nulla: " + queryContent);						
			}
		// F) forma nulla, classificazione nulla
		else if (cod_content_type==null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT",null);
			log.info("contenuti per forma nulla e classificazione nulla: " + queryContent);						
			};
		log.info("esito finale query classificazione di interesse del filtro: " + queryContent);	
		
		
		// SE LA QUERY NON é NULLA, CICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_CONTENT
		if (queryContent!=null && queryContent.size()>0){
			for(int k=0; k<queryContent.size(); k++){
				queryContent[k].cod_bim_filter=cod_bim_filter;	
				def ContIns = "insert into aim_bim_filter_r_content (cod_bim_filter, cod_content)";
				ContIns+=" values ";
				ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
				def ins_cont = services.queryService.executeQuery(ContIns,queryContent[k]);
				};		
			};		
*/		

		return true;
	}
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		
		// CREO LA MAPPA TOTALE
        def AllMap = [:] ;
        AllMap.putAll(oldValuesMap);
        AllMap.putAll(valuesMap);
		log.info("mappa totale after update: "+AllMap);

		// RECUPERO TIPO DI DATABASE
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);

		// RECUPERO I DATI DI INTERESSE

		// codice del filtro
		String cod_bim_filter = AllMap.cod_bim_filter;
		log.info("codice del filtro (cod_bim_filter): " + cod_bim_filter);

		// ambito gestionale immobile
		String cod_geo_filter = AllMap.cod_geo_filter;
		log.info("ambito gestionale immobile (cod_geo_filter): " + cod_geo_filter);
		
		// classificazione immobile
		String cod_building_class = AllMap.cod_building_class;
		log.info("classificazione immobile (cod_building_class): " + cod_building_class);
		
		// codice dell'immobile (scelta singola)
		String cod_building = AllMap.cod_building;
		log.info("codice dell'immobile (cod_building): " + cod_building);
		
		// forma del contenuto
		String cod_content_type = AllMap.cod_content_type;
		log.info("forma del contenuto (cod_content_type): " + cod_content_type);
		
		// classe del contenuto
		String cod_class_filter = AllMap.cod_class_filter;		
		log.info("classe del contenuto (cod_class_filter): " + cod_class_filter);


		// FORZO LO SVUOTAMENTO DEL CODICE DI CLASSIFICAZIONE CONTENUTO CON QUERY DIRETTA SU DB
		// XCHE' L'EVENT HANDLER FALLISCE

		// recupero tipo di selezione contenuto
		def type_select_content=AllMap.type_select_content;
		log.info("tipo selezione contenuto: " + type_select_content);
		
		// se il tipo di selezione è vuoto, forzo la classificazione a vuoto
		if (type_select_content==null){
			log.info("forzo svuotamento classificazione contenuto");
			def query_update = services.queryService.executeQuery("UPDATE aim_bim_filter SET cod_class_filter=NULL where cod_bim_filter= '" + cod_bim_filter + "'",null);
		};		


		// RECUPERO IMMOBILI DI INTERESSE PER ACL

		// istanzio variabile della query di ricerca degli immobili
		def queryBuilding = null;
		
		// A) se ambito gestionale è nullo, classe immobile è nullo e codice immobile singolo è nullo prendo tutti gli edifici 
		
		log.info("Caso A - cod_geo_filter==null: " + (cod_geo_filter==null));
		log.info("Caso A - cod_building_class==null: " + (cod_building_class==null));
		log.info("Caso A - cod_building==null: " + (cod_building==null));
		if (cod_geo_filter==null && cod_building_class==null && cod_building==null){
			log.info("update caso A");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING ",null);
			log.info("edifici per filtri nulli: "+queryBuilding);
			}
		// B) se ambito gestionale è nullo e classe immobile non è nullo e codice immobile singolo è nullo, prendo solo gli edifici della classe immobili
		else if (cod_geo_filter==null && cod_building_class!=null && cod_building==null){
			log.info("update caso B");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building_classification='" + cod_building_class + "'",null);
			log.info("edifici per classe immobile non nullo: "+queryBuilding);			
			}
		// C) se ambito gestionale non è nullo e classe immobile è nullo e codice immobile singolo è nullo, prendo solo gli edifici dell'ambito
		else if (cod_geo_filter!=null && cod_building_class==null && cod_building==null){
			log.info("update caso C");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='" + cod_geo_filter + "'",null);
			log.info("edifici per ambito immobile non nullo: "+queryBuilding);				
		}
		// D) se ambito è non nullo e classe immobile è non nullo e codice immobile singolo è nullo, prendo solo gli edifici dell'ambito e della classe
		else if(cod_geo_filter!=null && cod_building_class!=null && cod_building==null){
			log.info("update caso D");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='" + cod_geo_filter + "' AND cod_building_classification='" + cod_building_class + "'",null);
			log.info("edifici per ambito immobile non nullo: "+queryBuilding);			
			}
		// E) se ambito è nullo, classe immobile è nullo e codice immobile non è nullo
		else if (cod_geo_filter==null && cod_building_class==null && cod_building!=null){
			log.info("update caso E");
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building='" + cod_building + "'",null);
			log.info("edifici per scelta immobile singolo: "+queryBuilding);				
			
		};	
			
		log.info("esito finale query immobili di interesse del filtro: " + queryBuilding);
		
		// SVUOTO LA TABELLA E RICICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_BUILDING
			// svuoto la tabella per il filtro in modifica (immobili)
			def delete_building = services.queryService.executeQuery("DELETE FROM aim_bim_filter_r_building WHERE cod_bim_filter='"+cod_bim_filter+"'",null);
			// svuoto la tabella per il filtro in modifica (contenuti)
			def delete_content = services.queryService.executeQuery("DELETE FROM aim_bim_filter_r_content WHERE cod_bim_filter='" + cod_bim_filter + "'",null);
				
			// ciclo l'inserimento per il filtro in modifica
			for(int k=0; k<queryBuilding.size(); k++){
				queryBuilding[k].cod_bim_filter=cod_bim_filter;	

				// caso A - database = SQLServer
				if (db_type=='SQLServer'){				
					def buildIns = "INSERT INTO aim_bim_filter_r_building (cod_bim_filter, cod_building)";
					buildIns+=" VALUES ";
					buildIns+="(#{map.cod_bim_filter},#{map.cod_building})";
					def ins_build = services.queryService.executeQuery(buildIns,queryBuilding[k]);							
					};				
				
				// caso B - database = Postgres
				if (db_type=='Postgres'){
					def buildIns = "INSERT INTO aim_bim_filter_r_building (id_filter_r_building,cod_bim_filter,cod_building)";
					buildIns+=" VALUES ";
					buildIns+="(nextval('seq_fb'),#{map.cod_bim_filter},#{map.cod_building})";
					def ins_build = services.queryService.executeQuery(buildIns,queryBuilding[k]);
					};	

				
				// // VERIFICO SE CI SONO CONTENUTI, NEL CASO LI RECUPERO E LI CICLO PER IMMOBILE
				
				// istanzio variabile della query di ricerca dei contenuti
				def queryContent = null;
				
				// istanzio variabile della classe dei contenuti
				def class_type = null;

				// recupero la classificazione dei contenuti
				def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='" + cod_class_filter + "'",null);
				log.info("classificazione del filtro: " + classFilter);
				
				// se è presente una classificazione allora recupero i contenuti di interesse del filtro
				if (classFilter!=null && classFilter[0]!=null){class_type = classFilter[0].class_type};
				
				// A) forma non nulla, classificazione a livello di archivio
				if (cod_content_type!=null && class_type=='A'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione a livello di archivio: " + queryContent);			
					}
				// B) forma non nulla, classificazione a livello di categoria
				else if (cod_content_type!=null && class_type=='C'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione a livello di categoria: " + queryContent);				
					}
				// C) forma nulla, classificazione a livello di archivio
				else if (cod_content_type==null && class_type=='A'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione a livello di archivio: " + queryContent);			
					}		
				// D) forma nulla, classificazione a livello di categoria
				else if (cod_content_type==null && class_type=='C'){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione a livello di categoria: " + queryContent);				
					}		
				// E) forma non nulla, classificazione nulla
				else if (cod_content_type!=null && cod_class_filter==null){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='" + cod_content_type + "' AND cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma non nulla e classificazione nulla: " + queryContent);						
					}
				// F) forma nulla, classificazione nulla
				else if (cod_content_type==null && cod_class_filter==null){
					queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_building='" + queryBuilding[k].cod_building + "'",null);
					log.info("contenuti per forma nulla e classificazione nulla: " + queryContent);						
					};
				log.info("esito finale query classificazione di interesse del filtro: " + queryContent);	


				//  SVUOTO LA TABELLA E RICICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_CONTENT
				
				// ciclo l'inserimento per il filtro in modifica
				for(int j=0; j<queryContent.size(); j++){
					queryContent[j].cod_bim_filter=cod_bim_filter;	
					
				// caso A - database = SQLServer
					if (db_type=='SQLServer'){				
						def ContIns = "INSERT INTO aim_bim_filter_r_content (cod_bim_filter, cod_content)";
						ContIns+=" VALUES ";
						ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
						def ins_cont = services.queryService.executeQuery(ContIns,queryContent[j]);							
						};				
					
					// caso B - database = Postgres
					if (db_type=='Postgres'){
						def ContIns = "INSERT INTO aim_bim_filter_r_content (id_filter_r_content,cod_bim_filter,cod_content)";
						ContIns+=" VALUES ";
						ContIns+="(nextval('seq_fb'),#{map.cod_bim_filter},#{map.cod_content})";
						def ins_cont = services.queryService.executeQuery(ContIns,queryContent[j]);
						};						
					};					
				};			
		

		
/*
		// RECUPERO CLASSIFICAZIONI DI INTERESSE PER ACL
		
		// istanzio variabile della query di ricerca dei contenuti
		def queryContent = null;
		
		// istanzio variabile della classe dei contenuti
		def class_type = null;

		// recupero la classificazione dei contenuti
		def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='" + cod_class_filter + "'",null);
		log.info("classificazione del filtro: " + classFilter);
		
		// se è presente una classificazione allora recupero i contenuti di interesse del filtro
		if (classFilter!=null && classFilter[0]!=null){class_type = classFilter[0].class_type};
		
		// A) forma non nulla, classificazione a livello di archivio
		if (cod_content_type!=null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "'",null);
			log.info("contenuti per forma non nulla e classificazione a livello di archivio: " + queryContent);			
			}
		// B) forma non nulla, classificazione a livello di categoria
		else if (cod_content_type!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "' and cod_class_type='" + cod_content_type + "'",null);
			log.info("contenuti per forma non nulla e classificazione a livello di categoria: " + queryContent);				
			}
		// C) forma nulla, classificazione a livello di archivio
		else if (cod_content_type==null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='" + cod_class_filter + "'",null);
			log.info("contenuti per forma nulla e classificazione a livello di archivio: " + queryContent);			
			}		
		// D) forma nulla, classificazione a livello di categoria
		else if (cod_content_type==null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='" + cod_class_filter + "'",null);
			log.info("contenuti per forma nulla e classificazione a livello di categoria: " + queryContent);				
			}		
		// E) forma non nulla, classificazione nulla
		else if (cod_content_type!=null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='"+cod_content_type+"'",null);
			log.info("contenuti per forma non nulla e classificazione nulla: " + queryContent);						
			}
		// F) forma nulla, classificazione nulla
		else if (cod_content_type==null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT",null);
			log.info("contenuti per forma nulla e classificazione nulla: " + queryContent);						
			};
		log.info("esito finale query classificazione di interesse del filtro: " + queryContent);	


		//  SVUOTO LA TABELLA E RICICLO INSERIMENTO DEI RECORD SU TABELLA DI APPOGGIO AIM_BIM_FILTER_R_CONTENT
			// svuoto la tabella per il filtro in modifica
			def delete_content = services.queryService.executeQuery("DELETE FROM aim_bim_filter_r_content WHERE cod_bim_filter='" + cod_bim_filter + "'",null);
			// ciclo l'inserimento per il filtro in modifica
			for(int k=0; k<queryContent.size(); k++){
				queryContent[k].cod_bim_filter=cod_bim_filter;	
				def ContIns = "insert into aim_bim_filter_r_content (cod_bim_filter, cod_content)";
				ContIns+=" values ";
				ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
				def ins_cont = services.queryService.executeQuery(ContIns,queryContent[k]);
				};	

*/				

		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){

		// recupero chiave del record in cancellazione
		def pk_rec = valuesMap.id_bim_filter;
		log.info("chiave del record in cancellazione: " + pk_rec);

		// recupero codice del record in cancellazione
		def cod_rec_del = services.queryService.executeQuery("SELECT cod_bim_filter AS cod_rec_del FROM aim_bim_filter WHERE id_bim_filter=" + pk_rec,null)[0].cod_rec_del;7
		log.info("codice del record in cancellazione: " + cod_rec_del);
	
		// passo codice del filtro all'after delete
		valuesMap.cod_delete=cod_rec_del;
		log.info("codice del filtro in eliminazione: " + valuesMap.cod_delete);	
	

		return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		
        // recupero codice del filtro eliminato
        def cod_delete = valuesMap.cod_delete;
        log.info("chiave del filtro eliminato: " + cod_delete);
		
        // cancello record dalla tabella di associazione agli immobili
		def delete_building = services.queryService.executeQuery("DELETE FROM aim_bim_filter_r_content WHERE cod_bim_filter='" + cod_delete + "'",null);
		log.info("cancellazione immobili: " + delete_building);		
		
		// cancello record dalla tabella di associazione ai contenuti
		def delete_content = services.queryService.executeQuery("DELETE FROM aim_bim_filter_r_building WHERE cod_bim_filter='" + cod_delete + "'",null);
		log.info("cancellazione immobili: " + delete_content);
		
		// cancello record dalla tabella di associazione agli utenti
		def delete_user = services.queryService.executeQuery("DELETE FROM aim_bim_filter_user_groups WHERE cod_bim_filter='" + cod_delete + "'",null);
		log.info("cancellazione immobili: " + delete_user);		
		
		
		return true;
	};
	
}
