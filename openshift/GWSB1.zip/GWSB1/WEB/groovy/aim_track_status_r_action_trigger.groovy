
//type:    class trigger
//class:   cde_track_status
//note:    groovy di classe per il calcolo della chiave univoca dello stato (concatenazione di codice track + codice stato inserito dall'utente)



import org.apache.commons.lang.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder; 

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		def cod_track_status = valuesMap.cod_track_status;
		/*
		///////modifica custom per Intesa: non � possibile inserire una track con priorit� 99! 
		def queryCodTrack = "select cod_track from AIM_TRACK_STATUS where uk_track_status=#{map.cod_track_status}";
		def resCodTrackQuery = services.queryService.executeQuery(queryCodTrack, [cod_track_status: cod_track_status])[0];
		log.info("loggo il cod_track "+resCodTrackQuery);
		
		def queryPriority = "select priority from AIM_TRACK where cod_track=#{map.cod_track}";
		def countPriority = services.queryService.executeQuery(queryPriority, [cod_track: resCodTrackQuery.cod_track]);
		log.info("calcolo se la track associatagli ha priorit� 99 "+countPriority);
		
		if(countPriority==null || countPriority[0].priority==99){
			throw new RuntimeException("Azione non consentita per questa track");
		}
		///////fine customizzazione Intesa
		*/
		def queryActionAlreadyExist = "select COUNT(id_track_status_action) as is_exist from AIM_TRACK_STATUS_R_ACTION where "+
			" cod_action_type=#{map.cod_action_type} and cod_track_status_end=#{map.cod_track_status_end} and role_action=#{map.role_action}"
		def isActionAlreadyExist = services.queryService.executeQuery(queryActionAlreadyExist, valuesMap)[0];
		log.info("controllo se esiste gi� un'azione identica nella sostanza: "+isActionAlreadyExist);
		
		if(isActionAlreadyExist!=null && isActionAlreadyExist.is_exist){
			throw new RuntimeException("Configurazione <b>Azione Tipo</b> - <b>Stato Finale </b> - <b>Ruolo</b> presente<br>Impossibile salvare il record.");
		}
	
				
		return true;
	};
    

	public boolean afterInsert(HashMap<String,Object> valuesMap){	
	return true;		
    };
 
 
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		log.info("aba oldvaluesMap: "+oldvaluesMap);

		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();
		valuesMapAll.putAll(oldvaluesMap);
		valuesMapAll.putAll(valuesMap);
		
		def queryActionAlreadyExist = "select COUNT(id_track_status_action) as is_exist from AIM_TRACK_STATUS_R_ACTION where "+
			" cod_action_type=#{map.cod_action_type} and cod_track_status_end=#{map.cod_track_status_end} and role_action=#{map.role_action}"
		def isActionAlreadyExist = services.queryService.executeQuery(queryActionAlreadyExist, valuesMapAll)[0];
		log.info("controllo se esiste gi� un'azione identica nella sostanza: "+isActionAlreadyExist);
		
		if(isActionAlreadyExist!=null && isActionAlreadyExist.is_exist){
			throw new RuntimeException("Configurazione <b>Azione Tipo</b> - <b>Stato Finale </b> - <b>Ruolo</b> presente<br>Impossibile salvare record");
		}
		
        return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 