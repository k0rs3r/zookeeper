
import org.springframework.context.i18n.LocaleContextHolder;

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		String cod_track_role = valuesMap.get("cod_track_role");
		String username = valuesMap.get("username");
		//controllo che non vengano associati stesso utente e stesso gruppo più di una volta
		def query = services.queryService.executeQuery("SELECT id_track_user_role FROM AIM_TRACK_USER_ROLE WHERE cod_track_role='"+cod_track_role+"' and username='"+username+"'", null)[0];
		if(query!=null && query.size()>0){
			throw new RuntimeException("Attenzione: Associazione Utente a Ruolo già in uso!");
		}
    };
    

    public boolean afterInsert(HashMap<String,Object> valuesMap){
			
        return true;
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		//CREAZIONE DI UNA TERZA MAPPA CHE PRENDE TUTTI I VALORI DELL'ATTRIBUTO!
		//SE TROVA VALORI NUOVI, PRENDE QUELLI, ALTRIMENTI PRENDE I VECCHI VALORI
		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();

		valuesMapAll.putAll(oldvaluesMap);
		valuesMapAll.putAll(valuesMap);		
		def cod_track_role = valuesMapAll.get("cod_track_role");
		def username = valuesMapAll.get("username");
		log.info("loggo la mappa completa: "+valuesMapAll);
		def query = services.queryService.executeQuery("SELECT id_track_user_role FROM AIM_TRACK_USER_ROLE WHERE cod_track_role='"+cod_track_role+"' and username='"+username+"'", null)[0];
			if(query!=null && query.size()>0){	
				throw new RuntimeException("Attenzione: Associazione Utente a Ruolo già in uso!");
			}

        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
			
        return true;
		
    };
    
    public boolean beforeDelete(HashMap<String,Object> valuesMap){

        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
				
        return true;
    };

} 