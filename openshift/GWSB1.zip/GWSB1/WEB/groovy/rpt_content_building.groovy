// RECUPERO IL VALORE DELL'UTENTE IN SESSIONE PASSATOMI DAL REPORT
String User = parameterMap.activeUser;
String Building = parameterMap.cod_building;
log.debug("utente in sessione: " + User);
log.debug("immobile in sessione: " + Building);

// VERIFICO L'ESISTENZA DEL RECORD NELLA TABELLA aim_rpt_folder_navig_setting ASSOCIATO ALL'UTENTE IN SESSIONE
Integer check_user = queryService.executeQuery("SELECT COUNT (1) AS check_user FROM aim_rpt_folder_navig_setting WHERE username_setting='" + User + "'",null)[0].check_user;
log.debug("esito del controllo: " + check_user);

// DEFINISCO UNA MAPPA DI VALORI
def map = [:];

// SE IL RECORD NON ESISTE, LO CREO
if (check_user==0){

	// CREO OGGETTO PER INSERIMENTO
	def ins_rec = [:];
	ins_rec.cod_building=Building;
	ins_rec.username_setting=User;
	ins_rec.is_building=1;
	ins_rec.is_archive=0;
	ins_rec.is_category=0;
	ins_rec.is_subcategory=0;
	ins_rec.cod_archive=null;
	ins_rec.cod_category=null;
	ins_rec.cod_subcategory=null;
	log.info("mappa dei valori: " + ins_rec);
	
	// INSERISCO RECORD
	def pk_record = services.classService.insertClassRecord("aim_rpt_folder_navig_setting", ins_rec);
	map.pk_record = pk_record;

	//SE IL RECORD ESISTE, AGGIORNO IL BUILDING
} else if (check_user==1){
	Integer pk_record = queryService.executeQuery("SELECT id_folder_navig_setting AS pk_record FROM aim_rpt_folder_navig_setting WHERE username_setting='" + User + "'",null)[0].pk_record;
	log.debug("chiave del nuovo record creato: " + pk_record);
	
	// CREO OGGETTO PER AGGIORNAMENTO
	def upd_rec = [:];
	upd_rec.id_folder_navig_setting=pk_record;
	upd_rec.cod_building=Building;
	upd_rec.is_building=1;
	upd_rec.is_archive=0;
	upd_rec.is_category=0;
	upd_rec.is_subcategory=0;
	upd_rec.cod_archive=null;
	upd_rec.cod_category=null;
	upd_rec.cod_subcategory=null;
	log.info("mappa dei valori: " + upd_rec);
	
	// AGGIORNO RECORD
	services.classService.updateClassRecord("aim_rpt_folder_navig_setting", upd_rec);	
    map.pk_record = pk_record;
	
	
	};
	
	
// RITORNO ALLA REPORT LA MAPPA DEI VALORI
map.success = true;
return map;