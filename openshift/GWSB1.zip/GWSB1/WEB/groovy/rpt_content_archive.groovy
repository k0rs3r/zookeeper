// GROOVY RICHIAMATO DA REPORT DI VISUALIZZAZIONE CONTENUTI FASCICOLO X CARTELLE
// EFFETTUA LA VALORIZZAZIONE DI DATI DELLA TABELLA DI CONFIGURAZIONE aim_rpt_folder_navig_setting PER LA VISUALIZZAZIONE DEL CORRETTO REPORT



// RECUPERO IL VALORE DELL'UTENTE IN SESSIONE PASSATOMI DAL REPORT
String User = parameterMap.activeUser;
String Building = parameterMap.cod_building;
String Archive = parameterMap.cod_archive;
log.debug("utente in sessione: " + User);
log.debug("immobile in sessione: " + Building);
log.debug("archivio in sessione: " + Archive);


// NON VERIFICO L'ESISTENZA DEL RECORD, ARRIVO SEMPRE DAL LIVELLO DI NAVIGAZIONE DEL BUILDING CHE EVENTUALMENTE CREA IL RECORD


// DEFINISCO UNA MAPPA DI VALORI
def map = [:];

// RECUPERO CHIAVE DEL RECORD DI CONFIGURAZIONE

Integer pk_record = queryService.executeQuery("SELECT id_folder_navig_setting AS pk_record FROM aim_rpt_folder_navig_setting WHERE username_setting='" + User + "'",null)[0].pk_record;
log.debug("chiave del record di configurazione: " + pk_record);

// CREO OGGETTO PER AGGIORNAMENTO
def upd_rec = [:];
upd_rec.id_folder_navig_setting=pk_record;
upd_rec.cod_building=Building;
upd_rec.is_building=0;
upd_rec.is_archive=1;
upd_rec.is_category=0;
upd_rec.is_subcategory=0;
upd_rec.cod_archive=Archive;
upd_rec.cod_category=null;
upd_rec.cod_subcategory=null;
log.info("mappa dei valori: " + upd_rec);

// AGGIORNO RECORD
services.classService.updateClassRecord("aim_rpt_folder_navig_setting", upd_rec);	
map.pk_record = pk_record;
	

	
	
// RITORNO ALLA REPORT LA MAPPA DEI VALORI
map.success = true;
return map;