import java.util.ArrayList;
import org.apache.commons.lang.StringUtils;

class ConsolidationRuleScript {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger("com.geowebframework.groovy");

	def services;
	void init(s) {
		 services=s;
	}
	public void insertStorey(Integer drawing){
		
		//controllo se è inserito un livello con DWG (query valida per SQL Server: cast integer to string)
		def queryLev = "SELECT distinct lv.*, pr.cod_building from GWD_BIM_LEVEL lv";
		queryLev+=" LEFT JOIN GWD_BIM_PROJECT pr on project_code=lv.cod_project";
		queryLev+=" LEFT JOIN GWD_BIM_MODEL_STRUCTURE st on st.project+cast(st.level as varchar)= lv.cod_project+cast(lv.level_order as varchar)";
		queryLev+=" inner join GWD_DRAWING dr on dr.structure_code=st.structure_code";
		queryLev+=" where dr.pk_drawing="+drawing;
		def queryLevExe = services.queryService.executeQuery(queryLev,null);
		log.info("result per recupero info bim level associato ad un drawing "+queryLevExe);
		
		if(queryLevExe!=null && queryLevExe.size()>0){
			
			def bimLevelHM = queryLevExe[0];
			def ins_storey = [:];
			if(bimLevelHM.name_level!=null){
				ins_storey.name = bimLevelHM.name_level;
			}else{
				ins_storey.name = "Livello "+bimLevelHM.level_order;
			}	
			ins_storey.cod_building = bimLevelHM.cod_building;
			ins_storey.storey_level = bimLevelHM.level_order;
			def cod_storey = bimLevelHM.cod_building+'-L'+ StringUtils.leftPad(bimLevelHM.level_order.toString(), 3, "0");
			ins_storey.cod_storey=cod_storey;
			ins_storey.floor=bimLevelHM.cod_level;
			log.info("mappa storey "+ins_storey);
				
			//controllo se esiste uno storey associato al level, in caso negativo procedo all'inserimento del record
			def queryStorey = services.queryService.executeQuery("select pk_storey from GWD_STOREY  where storey_level=#{map.level_order} AND cod_building=#{map.cod_building}",bimLevelHM); 
			log.info("esiste lo storey per AIM? "+queryStorey);
			
			def queryCodLayout = services.queryService.executeQuery("select l.layout_code from gwd_layout l inner join gwd_drawing d on l.pk_layout=d.fk_layout where d.pk_drawing="+drawing, null)[0].layout_code;
			ins_storey.cod_layout = queryCodLayout;
				
			if(queryStorey==null || queryStorey.size()==0){
				def insStorey = "INSERT INTO GWD_STOREY (cod_building,storey_level,cod_storey,name,floor,cod_layout)";
				insStorey+=" VALUES ";
				insStorey+="(#{map.cod_building},#{map.storey_level},#{map.cod_storey},#{map.name},#{map.floor},#{map.cod_layout})";
				def insert = services.queryService.executeQuery(insStorey,ins_storey);			
			}
			
			//controllo se esiste nello SPACE uno storey associato al level, in caso negativo procedo all'inserimento del record
			def selectSpmStorey = "select cod_storey from spm_dati_gw.gwd_storey where cod_storey=#{map.cod_storey}";
			log.info("esiste lo storey per lo SPACE? "+queryStorey);
			def querySpmStorey = services.queryService.executeQuery(selectSpmStorey,ins_storey);
			if(querySpmStorey==null || querySpmStorey.size()==0){
				def insSpmStorey = "INSERT INTO spm_dati_gw.GWD_STOREY (cod_building,storey_level,cod_storey,name,floor,cod_layout)";
				insSpmStorey+=" VALUES ";
				insSpmStorey+="(#{map.cod_building},#{map.storey_level},#{map.cod_storey},#{map.name},#{map.floor},#{map.cod_layout})";
				def insertResult = services.queryService.executeQuery(insSpmStorey,ins_storey);
			//cambio il valore del campo can_delete dalla tabella GWD_BIM_LEVEL dell 'AIM
				def updBIMlevel = "UPDATE GWD_BIM_LEVEL set can_delete=0 where pk_bim_level="+bimLevelHM.pk_bim_level;
				def updBIMlevelResult = services.queryService.executeQuery(updBIMlevel,null);		
			}
		}
	}
	
	public void insertSpaceLayouts(Integer drawing) throws Exception {
		//recupero il layout del dwg  (è un campo obbligatorio)
		def query = services.queryService.executeQuery("select l.pk_layout, l.template_code, l.layout_label, s.cod_storey, s.floor from cde_dati_gw.gwd_drawing d inner join cde_dati_gw.gwd_layout l on l.pk_layout=d.fk_layout inner join spm_dati_gw.gwd_storey s on l.layout_code=s.cod_layout where d.pk_drawing="+drawing, null)[0];
		def fkLayout = query.pk_layout;
		if(query.template_code!=null && query.template_code!=''){
			services.queryService.executeQuery("update cde_dati_gw.gwd_layout set template_code = 'lay_floor_01' where pk_layout="+fkLayout, null);
		}
		def codStorey = query.cod_storey;
		def layout_label = query.layout_label;
		def cod_building = (layout_label.split("-"))[0];
		def floor = query.floor;
		def map = [:];
		map.fk_layout = fkLayout;
		map.drawing_set_label = cod_building +"-"+ floor;
		map.is_default = 0;
		
		//drawing.structure_code campo obbligatorio nei bimdata => not null
		def structureCodeResult = services.queryService.executeQuery("select structure_code from gwd_drawing where pk_drawing="+drawing, null)[0].structure_code;
		map.structure_code = structureCodeResult;
		/*
		controllo se esistono i drawing set specifici per lo space
			non esiste il drawing set => lo creo e creo relazione tra drawing set e drawing
			esiste il drawing set =>
					il drawing è revisionato => deve essere sostituito su draw_set_draw
						controllo se esiste record di relazione tra drawing set ed un drawing con stessa struttura di modello del drawing da inserire
							esiste => aggiorno fk_drawing
							non esiste => creo record
					il drawing è aggiuntivo => deve essere creato nuovo record su draw_set_draw
		*/
		def drawingSet = null;
		def revDrawQuery = null;
		def revDrawQueryResult = null;
		def pkRdrawSetDraw = null;
		
		//drawing set INV
		map.drawing_set_code = "FPSI-"+codStorey;
		map.map = "FloorPlanSpaceInv";
		def pkDrawingSet = services.queryService.executeQuery("select pk_drawing_set from cde_dati_gw.gwd_drawing_set where map=#{map.map} and fk_layout=#{map.fk_layout}", map);
		
		if(pkDrawingSet!=null && pkDrawingSet.size>0){
			revDrawQuery = "select r.pk_r_draw_set_draw from GWD_DRAWING d inner join GWD_R_DRAW_SET_DRAW r on d.pk_drawing=r.fk_drawing"+
				" inner join GWD_DRAWING_SET s on r.fk_drawing_set=s.pk_drawing_set"+
				" where d.structure_code=#{map.structure_code} and s.drawing_set_code=#{map.drawing_set_code}";
			revDrawQueryResult = services.queryService.executeQuery(revDrawQuery, map);
			if(revDrawQueryResult!=null && revDrawQueryResult.size()>0){
				pkRdrawSetDraw = revDrawQueryResult[0].pk_r_draw_set_draw;
				services.queryService.executeQuery("update cde_dati_gw.GWD_R_DRAW_SET_DRAW set fk_drawing ="+drawing+" where pk_r_draw_set_draw="+pkRdrawSetDraw, null);
			} else {
				services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+pkDrawingSet[0].pk_drawing_set+")", null);
			}
		} else {
			drawingSet = services.classService.insertClassRecord('gwd_drawing_set',map);
			services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+drawingSet+")", null);
		}
		 
		//drawing set ASSI
		map.drawing_set_code = "FPSA-"+codStorey;
		map.map = "FloorPlanSpaceAssi";
		pkDrawingSet = services.queryService.executeQuery("select pk_drawing_set from cde_dati_gw.gwd_drawing_set where map=#{map.map} and fk_layout=#{map.fk_layout}", map);
		if(pkDrawingSet!=null && pkDrawingSet.size>0){
			revDrawQuery = "select r.pk_r_draw_set_draw from GWD_DRAWING d inner join GWD_R_DRAW_SET_DRAW r on d.pk_drawing=r.fk_drawing"+
				" inner join GWD_DRAWING_SET s on r.fk_drawing_set=s.pk_drawing_set"+
				" where d.structure_code=#{map.structure_code} and s.drawing_set_code=#{map.drawing_set_code}";
			revDrawQueryResult = services.queryService.executeQuery(revDrawQuery, map);
			if(revDrawQueryResult!=null && revDrawQueryResult.size()>0){
				pkRdrawSetDraw = revDrawQueryResult[0].pk_r_draw_set_draw;
				services.queryService.executeQuery("update cde_dati_gw.GWD_R_DRAW_SET_DRAW set fk_drawing ="+drawing+" where pk_r_draw_set_draw="+pkRdrawSetDraw, null);
			} else {
				services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+pkDrawingSet[0].pk_drawing_set+")", null);
			}
		} else {
			drawingSet = services.classService.insertClassRecord('gwd_drawing_set',map);
			services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+drawingSet+")", null);
		}
		
		//drawing set FURN
		map.drawing_set_code = "FPSF-"+codStorey;
		map.map = "FloorPlanSpaceFurn";
		if(pkDrawingSet!=null && pkDrawingSet.size>0){
			revDrawQuery = "select r.pk_r_draw_set_draw from GWD_DRAWING d inner join GWD_R_DRAW_SET_DRAW r on d.pk_drawing=r.fk_drawing"+
				" inner join GWD_DRAWING_SET s on r.fk_drawing_set=s.pk_drawing_set"+
				" where d.structure_code=#{map.structure_code} and s.drawing_set_code=#{map.drawing_set_code}";
			revDrawQueryResult = services.queryService.executeQuery(revDrawQuery, map);
			if(revDrawQueryResult!=null && revDrawQueryResult.size()>0){
				pkRdrawSetDraw = revDrawQueryResult[0].pk_r_draw_set_draw;
				services.queryService.executeQuery("update cde_dati_gw.GWD_R_DRAW_SET_DRAW set fk_drawing ="+drawing+" where pk_r_draw_set_draw="+pkRdrawSetDraw, null);
			} else {
				services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+pkDrawingSet[0].pk_drawing_set+")", null);
			}
		} else {
			drawingSet = services.classService.insertClassRecord('gwd_drawing_set',map);
			services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+drawingSet+")", null);
		}
		
		//drawing set WORK
		map.drawing_set_code = "FPSW-"+codStorey;
		map.map = "FloorPlanSpaceWork";
		if(pkDrawingSet!=null && pkDrawingSet.size>0){
			revDrawQuery = "select r.pk_r_draw_set_draw from GWD_DRAWING d inner join GWD_R_DRAW_SET_DRAW r on d.pk_drawing=r.fk_drawing"+
				" inner join GWD_DRAWING_SET s on r.fk_drawing_set=s.pk_drawing_set"+
				" where d.structure_code=#{map.structure_code} and s.drawing_set_code=#{map.drawing_set_code}";
			revDrawQueryResult = services.queryService.executeQuery(revDrawQuery, map);
			if(revDrawQueryResult!=null && revDrawQueryResult.size()>0){
				pkRdrawSetDraw = revDrawQueryResult[0].pk_r_draw_set_draw;
				services.queryService.executeQuery("update cde_dati_gw.GWD_R_DRAW_SET_DRAW set fk_drawing ="+drawing+" where pk_r_draw_set_draw="+pkRdrawSetDraw, null);
			} else {
				services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+pkDrawingSet[0].pk_drawing_set+")", null);
			}
		} else {
			drawingSet = services.classService.insertClassRecord('gwd_drawing_set',map);
			services.queryService.executeQuery("insert into cde_dati_gw.GWD_R_DRAW_SET_DRAW  (fk_drawing, fk_drawing_set) VALUES ("+drawing+","+drawingSet+")", null);
		}	
	}
	
	public void importFromMongoDBToSpace(Integer drawing) throws Exception {
		log.info("importFromMongoDBToSpace - drawing: "+drawing);
		def selectStructureCode = "select structure_code from gwd_drawing where pk_drawing="+drawing;
		def structureCodeResult = services.queryService.executeQuery(selectStructureCode, null)[0].structure_code;
		def project = structureCodeResult.split('_')[0]; 
		
		//Per ogni tabella dello Space da gestire controllo se il drawing caricato è la revisione di un altro drawing
		// se si=> aggiorno tutti i record delle tabelle degli oggetti con il nuovo pk drawing
		def isRevisionQuery = services.queryService.executeQuery("select pk_drawing from gwd_drawing where structure_code=#{map.structure_code} and pk_drawing!="+drawing+" order by rev DESC", [structure_code: structureCodeResult]);
		def isARevision = false;
		def oldPkDrawing = null;
		if(isRevisionQuery!=null && isRevisionQuery.size()>0){
			isARevision=true;
			oldPkDrawing = isRevisionQuery[0].pk_drawing;
			log.info("importFromMongoDBToSpace - il drawing è una revisione del drawing con pk="+oldPkDrawing);
		}
		
		//////Caricamento spi_room///////
		if(isARevision)
			services.queryService.executeQuery("update spm_dati_gw.spi_room set drawing="+drawing+" where drawing = "+oldPkDrawing, null);
		def mongoResults = services.bimDataService.retrieveUserDatasFromMongos(project,drawing, "spi_room");
		def existingRecordsQuery = "select room_code from spm_dati_gw.spi_room where drawing = "+drawing;
		def existingRecords = services.queryService.executeQuery(existingRecordsQuery, null);
		ArrayList<String> codeList = new ArrayList<String>();
		for(int i=0; i<existingRecords.size(); i++){
			codeList.add(existingRecords[i].room_code);
		}
		log.info("lista codici record room da aggiornare: "+codeList);
		for (int j=0;j<mongoResults.size(); j++){
			def mongoResult = mongoResults[j];
			mongoResult.drawing = drawing;
			def codeValue = (String) mongoResult.room_code;
			if(codeValue != null){
				if(codeList.contains(codeValue)){
					// update passando mongoResult come mappa alla query 
					services.queryService.executeQuery("update spm_dati_gw.spi_room set geometry_polygon=#{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, geometry_centroid=#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, drawing=#{map.drawing} where room_code = #{map.room_code}", mongoResult);
					codeList.remove(codeValue);
				}else{
					// insert passando mongoResult come mappa alla query
					services.queryService.executeQuery("insert into spm_dati_gw.spi_room (room_code, geometry_polygon, geometry_centroid, drawing) values (#{map.room_code},#{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler},#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.drawing})", mongoResult);
				}
			}
		}
		for (int k=0;k<codeList.size(); k++){
			log.info("record da dismettere: "+codeList);
			// update con drawing = null and status = 'Dismesso' where room_code=codeList[k];
			def map = [:];
			def room_code = codeList[k];
			map.room_code = room_code;
			services.queryService.executeQuery("update spm_dati_gw.spi_room set drawing=null, status = 'Dismesso' where room_code = #{map.room_code}", map);
		}
		////Fine Caricamento spi_room////
		
		////Caricamento spa_functional_area/////
		if(isARevision)
			services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set drawing="+drawing+" where drawing = "+oldPkDrawing, null);
		mongoResults = services.bimDataService.retrieveUserDatasFromMongos(project,drawing, "spa_functional_area");
		existingRecordsQuery = "select area_func_code from spm_dati_gw.spa_functional_area where drawing = "+drawing;
		existingRecords = services.queryService.executeQuery(existingRecordsQuery, null);
		codeList = new ArrayList<String>();
		for(int i=0; i<existingRecords.size(); i++){
			codeList.add(existingRecords[i].area_func_code);
		}
		log.info("lista codici record spa_functional_area da aggiornare: "+codeList);
		for (int j=0;j<mongoResults.size(); j++){
			def mongoResult = mongoResults[j];
			mongoResult.drawing = drawing;
			def codeValue = (String) mongoResult.area_func_code;
			if(codeValue != null){
				if(codeList.contains(codeValue)){
					services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set geometry_polygon=#{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, geometry_centroid=#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, drawing=#{map.drawing} where area_func_code = #{map.area_func_code}", mongoResult);
					codeList.remove(codeValue);
				}else{
					services.queryService.executeQuery("insert into spm_dati_gw.spa_functional_area (area_func_code, geometry_polygon, geometry_centroid, drawing) values (#{map.area_func_code},#{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler},#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.drawing})", mongoResult);
				}
			}
		}
		for (int k=0;k<codeList.size();k++){
			log.info("record da dismettere: "+codeList);
			def map = [:];
			def area_func_code = codeList[k];
			map.area_func_code = area_func_code;
			services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set drawing=null, status = 'Dismesso' where area_func_code = #{map.area_func_code}", map);
		}
		////Fine caricamento spa_functional_area/////
	
		////Caricamento wsm_workstation/////  -> genera un errore l'update o_O
		if(isARevision)
			services.queryService.executeQuery("update spm_dati_gw.wsm_workstation set drawing="+drawing+" where drawing = "+oldPkDrawing, null);
		mongoResults = services.bimDataService.retrieveUserDatasFromMongos(project,drawing, "wsm_workstation");
		existingRecordsQuery = "select cod_workstation from spm_dati_gw.wsm_workstation where drawing = "+drawing;
		existingRecords = services.queryService.executeQuery(existingRecordsQuery, null);
		codeList = new ArrayList<String>();
		for(int i=0; i<existingRecords.size(); i++){
			codeList.add(existingRecords[i].cod_workstation);
		}
		log.info("lista codici record wsm_workstation da aggiornare: "+codeList);
		for (int j=0;j<mongoResults.size(); j++){
			def mongoResult = mongoResults[j];
			mongoResult.drawing = drawing;
			def codeValue = (String) mongoResult.cod_workstation;
			if(codeValue != null){
				if(codeList.contains(codeValue)){
					services.queryService.executeQuery("update spm_dati_gw.wsm_workstation set geometry=#{map.geometry, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, drawing=#{map.drawing} where cod_workstation = #{map.cod_workstation}", mongoResult);
					codeList.remove(codeValue);
				}else{
					services.queryService.executeQuery("insert into spm_dati_gw.wsm_workstation (cod_workstation, geometry, drawing) values (#{map.cod_workstation},#{map.geometry, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.drawing})", mongoResult);
				}
				def resRoom = services.queryService.executeQuery("select b.room_code from spm_dati_gw.spi_room b where b.drawing=#{map.drawing} and b.geometry_polygon.STIntersects(#{map.geometry,typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler})=1",mongoResult);
				if(resRoom!=null && resRoom.size()>0 && resRoom[0]!=null) {
					mongoResult.room_code=resRoom[0].room_code;
					services.queryService.executeQuery("update spm_dati_gw.wsm_workstation set room_code=#{map.room_code} where cod_workstation = #{map.cod_workstation}", mongoResult);
				}
			}
		}
		for (int k=0;k<codeList.size();k++){
			// update con drawing = null and status = 'Dismesso' where room_code=codeList[k];
			log.info("record da dismettere: "+codeList);
			def map = [:];
			def cod_workstation = codeList[k];
			map.cod_workstation = cod_workstation;
			services.queryService.executeQuery("update spm_dati_gw.wsm_workstation set drawing=null where cod_workstation = #{map.cod_workstation}", map);
		}
		////Fine caricamento wsm_workstation/////	
		
		////Caricamento spi_gea/////
		if(isARevision)
			services.queryService.executeQuery("update spm_dati_gw.spi_gea set drawing="+drawing+" where drawing = "+oldPkDrawing, null);
		mongoResults = services.bimDataService.retrieveUserDatasFromMongos(project,drawing, "spi_gea");
		existingRecordsQuery = "select gea_code from spm_dati_gw.spi_gea where drawing = "+drawing;
		existingRecords = services.queryService.executeQuery(existingRecordsQuery, null);
		codeList = new ArrayList<String>();
		for(int i=0; i<existingRecords.size(); i++){
			codeList.add(existingRecords[i].gea_code);
		}
		log.info("lista codici record spi_gea da aggiornare: "+codeList);
		for (int j=0;j<mongoResults.size(); j++){
			def mongoResult = mongoResults[j];
			mongoResult.drawing = drawing;
			def codeValue = (String) mongoResult.gea_code;
			if(codeValue != null){
				if(codeList.contains(codeValue)){
					services.queryService.executeQuery("update spm_dati_gw.spi_gea set geometry_polygon=#{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, geometry_centroid=#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, drawing=#{map.drawing} where gea_code = #{map.gea_code}", mongoResult);
					codeList.remove(codeValue);
				}else{
					services.queryService.executeQuery("insert into spm_dati_gw.spi_gea (gea_code, geometry_polygon, geometry_centroid, drawing) values (#{map.gea_code}, #{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.drawing})", mongoResult);
				}
			}
		}
		for (int k=0;k<codeList.size();k++){
			// update con drawing = null and status = 'Dismesso' where room_code=codeList[k];
			log.info("record da dismettere: "+codeList);
			def map = [:];
			def gea_code = codeList[k];
			map.gea_code = gea_code;
			services.queryService.executeQuery("update spm_dati_gw.spi_gea set drawing=null where gea_code = #{map.gea_code}", map);
		}
		////Fine caricamento spi_gea/////	
		
		////Caricamento spi_ufa/////
		if(isARevision)
			services.queryService.executeQuery("update spm_dati_gw.spi_ufa set drawing="+drawing+" where drawing = "+oldPkDrawing, null);
		mongoResults = services.bimDataService.retrieveUserDatasFromMongos(project,drawing, "spi_ufa");
		existingRecordsQuery = "select ufa_code from spm_dati_gw.spi_ufa where drawing = "+drawing;
		existingRecords = services.queryService.executeQuery(existingRecordsQuery, null);
		codeList = new ArrayList<String>();
		for(int i=0; i<existingRecords.size(); i++){
			codeList.add(existingRecords[i].ufa_code);
		}
		log.info("lista codici record spi_ufa da aggiornare: "+codeList);
		for (int j=0;j<mongoResults.size(); j++){
			def mongoResult = mongoResults[j];
			mongoResult.drawing = drawing;
			def codeValue = (String) mongoResult.ufa_code;
			if(codeValue != null){
				if(codeList.contains(codeValue)){
					services.queryService.executeQuery("update spm_dati_gw.spi_ufa set classification=#{map.classification}, geometry_polygon=#{map.geometry_polygon typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, geometry_centroid=#{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, drawing=#{map.drawing} where ufa_code = #{map.ufa_code}", mongoResult);
					codeList.remove(codeValue);
				}else{
					services.queryService.executeQuery("insert into spm_dati_gw.spi_ufa (ufa_code, classification, geometry_polygon, geometry_centroid, drawing) values (#{map.ufa_code}, #{map.classification}, #{map.geometry_polygon, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.geometry_centroid, typeHandler=com.geowebframework.transfer.typehandler.MSSqlGeometryTypeHandler}, #{map.drawing})", mongoResult);
				}
			}
		}
		for (int k=0;k<codeList.size();k++){
			// update con drawing = null and status = 'Dismesso' where room_code=codeList[k];
			log.info("record da dismettere: "+codeList);
			def map = [:];
			def ufa_code = codeList[k];
			map.ufa_code = ufa_code;
			services.queryService.executeQuery("update spm_dati_gw.spi_ufa set drawing=null where ufa_code = #{map.ufa_code}", map);
		}
		////Fine caricamento spi_ufa/////	
	}
	
	public void executeSpaceTableUpdates(Integer drawing) throws Exception {
		//////consolidation rule//////
		services.queryService.executeQuery("update spm_dati_gw.spi_room set cod_company = 'ISP'  where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spi_room set height_med = 3  where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set cod_company = 'ISP'  where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spi_gea set area=round((spi_gea.geometry_polygon.STArea()/1),2) where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spi_ufa set area=round((spi_ufa.geometry_polygon.STArea()/1),2) where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spi_room set area=round((spi_room.geometry_polygon.STArea()/1),2) where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.wsm_workstation set spm_dati_gw.wsm_workstation.room_code=(select b.room_code from spm_dati_gw.spi_room b where wsm_workstation.drawing=b.drawing and wsm_workstation.geometry.STIntersects(b.geometry_polygon)=1) where wsm_workstation.drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set area=round((spa_functional_area.geometry_polygon.STArea()/1),2) where drawing="+drawing, null);
		services.queryService.executeQuery("update spm_dati_gw.spi_room set spm_dati_gw.spi_room.cod_functional_area=(select b.area_func_code from spm_dati_gw.spa_functional_area b where spi_room.drawing=b.drawing and spi_room.geometry_centroid.STIntersects(b.geometry_polygon)=1) where spm_dati_gw.spi_room.drawing="+drawing, null);
		
		def lres = services.queryService.executeQuery("select s.cod_storey from SPM_DATI_GW.GWD_STOREY s inner join CDE_DATI_GW.gwd_layout l on s.cod_layout=l.layout_code inner join CDE_DATI_GW.gwd_drawing d on l.pk_layout=d.fk_layout where d.pk_drawing="+drawing, null);
		if(lres!=null && !lres.isEmpty() &&  lres[0].cod_storey!=null){
			def l = lres[0].cod_storey;
			services.queryService.executeQuery("update spm_dati_gw.spi_room set cod_storey='"+l+"' where drawing="+drawing, null);
			services.queryService.executeQuery("update spm_dati_gw.spa_functional_area set cod_storey='"+l+"' where drawing="+drawing, null);
			services.queryService.executeQuery("update spm_dati_gw.spi_ufa set cod_storey='"+l+"' where drawing="+drawing, null);
			services.queryService.executeQuery("update spm_dati_gw.spi_gea set cod_storey='"+l+"' where drawing="+drawing, null);
		}
		
		def roomCodes = services.queryService.executeQuery("select room_code from spm_dati_gw.spi_room where drawing="+drawing, null);
		if(roomCodes!=null && roomCodes.size()>0) {
			for (int a=0;a<roomCodes.size(); a++){
				def room_code = roomCodes[a].room_code;
				int numPos = services.queryService.executeQuery("select count(*) as n from spm_dati_gw.wsm_workstation w where w.room_code='"+room_code+"'",null)[0].n;
				services.queryService.executeUpdateQuery("update spm_dati_gw.spi_room set num_workstation_eff=#{map.numPos} where room_code=#{map.room_code}",[numPos:numPos,room_code:room_code]);
			}
		}
		//
	}
}