//user:    RMA 
//date:    28/12/2015
//ver:     4.2
//project: JobOrder
//type:    trigger
//class:   cde_rfi_appo
//note:    trigger della classe degli Interventi Richiesti. In inserimento inserisce la data e lo stato (REQ) e recupera in automatico la descrizione degli oggetti ed il luogo



import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument; 
import org.springframework.context.i18n.LocaleContextHolder;



public class RqmRequestInsertGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
	//recupero il nome del filtro per poter controllarne l'univocità
	def name_bim_filter = valuesMap.get("name_bim_filter")
	//CALCOLO IL PROGRESSIVO DEL CODICE DEL FILTRO
	def num_fil = services.queryService.executeQuery("SELECT count(id_bim_filter) as num_fil FROM AIM_BIM_FILTER", null)[0].num_fil;
	log.info("num_fil: "+num_fil);
	if(num_fil==0){
		num_fil=1;
		valuesMap.put("cod_bim_filter","AIM_FILTER_" + num_fil.toString().padLeft(2, '0'));
		valuesMap.put("prog",num_fil);
		}else {
		def max_fil = services.queryService.executeQuery("SELECT max(prog) max_fil FROM AIM_BIM_FILTER", null)[0].max_fil;
		max_fil=max_fil++;
		log.info("max_fil: "+max_fil++);
		valuesMap.put("cod_bim_filter","AIM_FILTER_" + max_fil.toString().padLeft(2, '0'));
		valuesMap.put("prog",max_fil);
		}
		//CONTROLLO CHE IL LA DESCRIZIONE DEL FILTRO SIA UNIVOCA
		def query = services.queryService.executeQuery("SELECT id_bim_filter FROM AIM_BIM_FILTER WHERE name_bim_filter='"+name_bim_filter+"'", null)[0];
		if(query!=null && query.size()>0){
			throw new RuntimeException("<b>ATTENZIONE </b><br>Nome filtro già in uso.<br>Cambiare nome del filtro.");
		}			
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		//tutte le variabili in uso
		def cod_building_class = valuesMap.cod_building_class;
		def cod_geo_filter = valuesMap.cod_geo_filter;
		def cod_content_type = valuesMap.cod_content_type;
		def cod_class_filter = valuesMap.cod_class_filter;
		def cod_bim_filter = valuesMap.cod_bim_filter;
		
		def queryBuilding = null;
		def queryContent = null;
		//filtro il record selezionato sulla tipologia di filtri geografici per ottenere l'info sulla tipologia di classe;
		def geoFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_GEO_FILTER WHERE cod_geo_filter='"+cod_geo_filter+"'",null)
		def geo_type = null;
		if(geoFilter!=null && geoFilter[0]!=null){geo_type=geoFilter[0].geo_type;}
		log.info("loggo il codice geografico: "+cod_geo_filter);
		log.info("loggo la tipologia di classe: "+geo_type);
		//faccio le query per effettuare il filtro sugli edifici
		if(cod_building_class!=null && cod_geo_filter!=null && geo_type=='T'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='"+cod_geo_filter+"' and cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 12: "+queryBuilding);
		}else if (cod_building_class!=null && cod_geo_filter!=null && geo_type=='F'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_functional_area_mc='"+cod_geo_filter+"' and cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 12: "+queryBuilding);	
		}else if(cod_building_class==null && cod_geo_filter!=null && geo_type=='T'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='"+cod_geo_filter+"'",null);
			log.info("loggo la query EDIFICI 01: "+queryBuilding);	
		}else if(cod_building_class==null && cod_geo_filter!=null && geo_type=='F'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_functional_area_mc='"+cod_geo_filter+"'",null);
			log.info("loggo la query EDIFICI 02: "+queryBuilding);	
		}else if (cod_building_class!=null && cod_geo_filter==null){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 10: "+queryBuilding);	
		}else if (cod_building_class==null && cod_geo_filter==null){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING",null);
		}	
		log.info("queryBuilding: " + queryBuilding);
		
		//CICLO TUTTI GLI EDIFICI TROVATI DALLA SELEZIONI E LI MATERIALIZZO IN UNA TABELLA DI RELAZIONE
		for(int k=0; k<queryBuilding.size(); k++){
			queryBuilding[k].cod_bim_filter=cod_bim_filter;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def BuildIns = "INSERT INTO AIM_BIM_FILTER_R_BUILDING (cod_bim_filter, cod_building)";
			BuildIns+=" VALUES ";
			BuildIns+="(#{map.cod_bim_filter},#{map.cod_building})";
			def ins_build = services.queryService.executeQuery(BuildIns,queryBuilding[k]);
		}
		
		def class_type = null;
		//filtro il record selezionato sulla tipologia di filtri di classificazioni per ottenere l'info sulla tipologia di classe;
		def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='"+cod_class_filter+"'",null);
		if(classFilter!=null && classFilter[0]!=null){class_type=classFilter[0].class_type}

	
		//faccio le query per effettuare il filtro sui contenuti
		if(cod_content_type!=null && cod_class_filter!=null && class_type=='A' ){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='"+cod_class_filter+"' and cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 12: "+queryContent);
		}else if (cod_content_type!=null && cod_class_filter!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='"+cod_class_filter+"' and cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 120: "+queryContent);	
		}else if(cod_content_type==null && cod_class_filter!=null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='"+cod_class_filter+"'",null);
			log.info("loggo la query CONTENUTI 023: "+queryContent);	
		}else if(cod_content_type==null && cod_class_filter!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='"+cod_class_filter+"'",null);
			log.info("loggo la query CONTENUTI 020: "+queryContent);	
		}else if (cod_content_type!=null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 100: "+queryContent);	
		}else if (cod_content_type==null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT",null);
		}
		//CICLO TUTTI I CONTENUTI TROVATI DALLA SELEZIONI E LI MATERIALIZZO IN UNA TABELLA DI RELAZIONE
		for(int k=0; k<queryContent.size(); k++){
			queryContent[k].cod_bim_filter=cod_bim_filter;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def ContIns = "INSERT INTO AIM_BIM_FILTER_R_CONTENT (cod_bim_filter, cod_content)";
			ContIns+=" VALUES ";
			ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
			def ins_cont = services.queryService.executeQuery(ContIns,queryContent[k]);
		}
		return true;
	}
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> valuesMapOld){		
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		
		// recupero i nuovi e vecchi valori di codice e descrizione
		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();
		valuesMapAll.putAll(oldValuesMap);
		valuesMapAll.putAll(valuesMap);
		log.info("loggo la query valuesMapAll: "+valuesMapAll);
		
				//tutte le variabili in uso
		def cod_building_class = valuesMapAll.cod_building_class;
		def cod_geo_filter = valuesMapAll.cod_geo_filter;
		def cod_content_type = valuesMapAll.cod_content_type;
		def cod_class_filter = valuesMapAll.cod_class_filter;
		def cod_bim_filter = valuesMapAll.cod_bim_filter;
		
		def queryBuilding = null;
		def queryContent = null;
		//filtro il record selezionato sulla tipologia di filtri geografici per ottenere l'info sulla tipologia di classe;
		def geoFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_GEO_FILTER WHERE cod_geo_filter='"+cod_geo_filter+"'",null);
		def geo_type = null;
		if(geoFilter!=null && geoFilter[0]!=null){geo_type=geoFilter[0].geo_type;}
		log.info("loggo il valore cod_geo:: "+cod_geo_filter);
		log.info("loggo la tipologia di classe after UPD: "+geo_type);
		//faccio le query per effettuare il filtro sugli edifici
		if(cod_building_class!=null && cod_geo_filter!=null && geo_type=='T'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='"+cod_geo_filter+"' and cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 12T: "+queryBuilding);
		}else if (cod_building_class!=null && cod_geo_filter!=null && geo_type=='F'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_functional_area_mc='"+cod_geo_filter+"' and cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 12F: "+queryBuilding);	
		}else if(cod_building_class==null && cod_geo_filter!=null && geo_type=='T'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_territorial_area='"+cod_geo_filter+"'",null);
			log.info("loggo la query EDIFICI 01: "+queryBuilding);	
		}else if(cod_building_class==null && cod_geo_filter!=null && geo_type=='F'){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_functional_area_mc='"+cod_geo_filter+"'",null);
			log.info("loggo la query EDIFICI 02: "+queryBuilding);	
		}else if (cod_building_class!=null && cod_geo_filter==null){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING WHERE cod_building_classification='"+cod_building_class+"'",null);
			log.info("loggo la query EDIFICI 10: "+queryBuilding);	
		}else if (cod_building_class==null && cod_geo_filter==null){
			queryBuilding = services.queryService.executeQuery("SELECT cod_building FROM V_AIM_BUILDING",null);
		}

		def delBuild = services.queryService.executeQuery("DELETE FROM AIM_BIM_FILTER_R_BUILDING WHERE cod_bim_filter='"+cod_bim_filter+"'",null);
		//CICLO TUTTI GLI EDIFICI TROVATI DALLA SELEZIONI E LI MATERIALIZZO IN UNA TABELLA DI RELAZIONE
		for(int k=0; k<queryBuilding.size(); k++){
			queryBuilding[k].cod_bim_filter=cod_bim_filter;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def BuildIns = "INSERT INTO AIM_BIM_FILTER_R_BUILDING (cod_bim_filter, cod_building)";
			BuildIns+=" VALUES ";
			BuildIns+="(#{map.cod_bim_filter},#{map.cod_building})";
			def ins_build = services.queryService.executeQuery(BuildIns,queryBuilding[k]);
		}		
		
		
		//filtro il record selezionato sulla tipologia di filtri di classificazioni per ottenere l'info sulla tipologia di classe;
		def class_type = null;
		def classFilter = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_CLASS_FILTER WHERE cod_class='"+cod_class_filter+"'",null);
		if(classFilter!=null && classFilter[0]!=null){class_type=classFilter[0].class_type}
	
		//faccio le query per effettuare il filtro sui contenuti
		if(cod_content_type!=null && cod_class_filter!=null && class_type=='A' ){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='"+cod_class_filter+"' and cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 12: "+queryContent);
		}else if (cod_content_type!=null && cod_class_filter!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='"+cod_class_filter+"' and cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 120: "+queryContent);	
		}else if(cod_content_type==null && cod_class_filter!=null && class_type=='A'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_arc='"+cod_class_filter+"'",null);
			log.info("loggo la query CONTENUTI 023: "+queryContent);	
		}else if(cod_content_type==null && cod_class_filter!=null && class_type=='C'){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_cat='"+cod_class_filter+"'",null);
			log.info("loggo la query CONTENUTI 020: "+queryContent);	
		}else if (cod_content_type!=null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT WHERE cod_class_type='"+cod_content_type+"'",null);
			log.info("loggo la query CONTENUTI 100: "+queryContent);	
		}else if (cod_content_type==null && cod_class_filter==null){
			queryContent = services.queryService.executeQuery("SELECT cod_content FROM AIM_CONTENT",null);
		}
		
		def delCont = services.queryService.executeQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_bim_filter='"+cod_bim_filter+"'",null);
		//CICLO TUTTI I CONTENUTI TROVATI DALLA SELEZIONI E LI MATERIALIZZO IN UNA TABELLA DI RELAZIONE
		for(int k=0; k<queryContent.size(); k++){
			queryContent[k].cod_bim_filter=cod_bim_filter;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def ContIns = "INSERT INTO AIM_BIM_FILTER_R_CONTENT (cod_bim_filter, cod_content)";
			ContIns+=" VALUES ";
			ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
			def ins_cont = services.queryService.executeQuery(ContIns,queryContent[k]);
		}
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
	def pcFilt = valuesMap.id_bim_filter;
	def selectCode = "SELECT cod_bim_filter FROM AIM_BIM_FILTER where id_bim_filter="+pcFilt;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukFilt = result.cod_bim_filter;
	def delFilCont = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_bim_filter='"+ukFilt+"'",null);
	def delFilBui = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_BUILDING WHERE cod_bim_filter='"+ukFilt+"'",null);
	def delFilUsers = services.queryService.executeDeleteQuery("DELETE FROM aim_bim_filter_user_groups WHERE cod_bim_filter='"+ukFilt+"'",null);
		return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		return true;
	};
	
}
