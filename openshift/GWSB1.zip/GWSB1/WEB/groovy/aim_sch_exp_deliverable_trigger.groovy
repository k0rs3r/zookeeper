
//project: AIM
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_sch_exp_deliverable_trigger.groovy
//note:    inserire descrizione completa

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;
import com.geowebframework.dataservice.ConfigurationProperties;


public class aim_sch_exp_deliverable_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		def pkExpDel = valuesMap.id_exp_r_deliverable;
		def selectCode = "SELECT * FROM aim_sch_exp_deliverable where id_exp_r_deliverable="+pkExpDel;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukExpDel = result.cod_deliverable_full;
		def uk_02_team = result.uk_02_team;
		def cod_03_system = result.cod_03_system;
		def cod_04_level = result.cod_04_level;
		
		//gestisco l'eliminazione delle classi  
		def delCSM = services.queryService.executeDeleteQuery("DELETE FROM AIM_SCH_EXP_SITE WHERE cod_expectation='"+ukExpDel+"'",null);
		def delDraw = services.queryService.executeDeleteQuery("DELETE FROM GWD_DRAWING WHERE dwg_name='"+ukExpDel+"'",null);
		def delBimModel = services.queryService.executeDeleteQuery("DELETE FROM GWD_BIM_MODEL WHERE name='"+ukExpDel+"'",null);
		def del2DLay = services.queryService.executeDeleteQuery("DELETE FROM GWD_LAYOUT WHERE layout_type='2D' and layout_code='"+cod_04_level+"'",null);		
		def delTeam = services.queryService.executeDeleteQuery("DELETE FROM GWD_TEAM_TYPE WHERE cod_team_type='"+uk_02_team+"'",null);
		def delSys = services.queryService.executeDeleteQuery("DELETE FROM GWD_SYSTEM_TYPE WHERE cod_system_type='"+cod_03_system+"'",null);
		
		

		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
	
        return true;
    };

} 