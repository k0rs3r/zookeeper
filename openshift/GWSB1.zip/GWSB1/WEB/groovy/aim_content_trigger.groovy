import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;


public class aim_content_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		String author = valuesMap.get("author");
		String usergroup = valuesMap.get("usergroup");
		log.info("AIM_CONTENT_TRIGGER:loggo l'autore: "+author+usergroup);
		Integer from_revision = valuesMap.get("from_revision");
		Integer single_insert = valuesMap.get("single_insert");
		String cod_building = valuesMap.get("cod_building");
		log.info("AIM_CONTENT_TRIGGER:cod_building: "+cod_building);
		log.info("AIM_CONTENT_TRIGGER:single_insert: "+single_insert);
		def defCodContent = null;
		log.info("AIM_CONTENT_TRIGGER:loggo la mappa dei valori in ingresso x il nuovo contenuto: "+valuesMap);

/*
		if(!usergroup.equals("AIM_BIM")){


			//CONTROLLO CHE L'UTENTE ABBIA I PERMESSI PER L'INSERIMENTO; SONO GLI STESSI DELLA VISUALIZZAZIONE:
			def queryPermission = services.queryService.executeQuery("SELECT DISTINCT username FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='"+usergroup+"') or groups='AIM_CONTENT_VERIFIER'",null)[0];
			log.info("AIM_CONTENT_TRIGGER:queryPermission: "+queryPermission);
			if(queryPermission!=null && queryPermission.size()>0){
*/
				//VALUTO SE L'EDIFICIO SCELTO DALL'UTENTE è CORRETTO
				def queryBuildPerm = services.queryService.executeQuery("SELECT DISTINCT cod_building FROM V_AIM_BUILDING_PERMISSION WHERE cod_building='"+cod_building+"' and (username='"+author+"' and groups IN ('AIM_CONTENT_OWNER','AIM_CONTENT_OWNER_PRO','AIM_CONTENT_READER','AIM_CONTENT_VERIFIER')) ",null)[0];
				if(queryBuildPerm==null || queryBuildPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente <b>"+author+"</b> non detiene i permessi per creare <br>contenuti relativi all'edificio indicato: <b>"+cod_building+"</b>");
				}
				//VALUTO LA CLASSIFICAZIONE
				//RECUPERO L'ARCHIVIO DALLA CLASSIFICAZIONE (SOTTOCATEGORIA) 
				//def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",[content_class:valuesMap.content_class])[0]; 
				def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class} or cod_class=#{map.content_class_2}",[content_class:valuesMap.content_class,content_class_2:valuesMap.cod_class_subcat])[0]; 
				log.info("AIM_CONTENT_TRIGGER:queryCodClass: " + queryCodClass);
				
				//controllo che i dati di classificazione siano corretti o presenti
				if (queryCodClass==null || queryCodClass.size()==0){
					//gestisco la classificazione errata
					throw new RuntimeException("Attenzione: Classificazione inesistente. <br>Impossibile creare contenuto");
				}
				//else if(valuesMap.content_class==null){
				else if(valuesMap.content_class==null && valuesMap.cod_class_subcat==null){
					//gestisco la classificazione manacante (da csv)
					throw new RuntimeException("Attenzione: Classificazione non specificata. <br>Impossibile creare contenuto");
				}					
				//controllo se la classificazione scelta rientra nei filtri impostati per l'utente
				def queryClassPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups in ('AIM_CONTENT_OWNER','AIM_CONTENT_OWNER_PRO','AIM_CONTENT_READER','AIM_CONTENT_VERIFIER')) and (cod_class_filter is null or cod_class_filter='"+queryCodClass.cod_class_arc+"' or cod_class_filter='"+queryCodClass.cod_class_cat+"')", null);
				//controllo se la forma scelta rientra nei filtri impostati per l'utente
				def queryFormPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups in ('AIM_CONTENT_OWNER','AIM_CONTENT_OWNER_PRO','AIM_CONTENT_READER','AIM_CONTENT_VERIFIER')) and (cod_content_type is null or cod_content_type=#{map.cod_class_type})",[cod_class_type:valuesMap.cod_class_type]);			 
				log.info("loggo la query dei permessi sulla classificazione: "+queryClassPerm);
				log.info("loggo la query dei permessi sulla forma: "+queryFormPerm);
				//gestisco la mancanza di permessi per la classificazione e blocco l'inserimento con log di errore
				if(queryClassPerm==null || queryClassPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la classificazione selezionata. <br>Impossibile creare contenuto");					
				}
				
				//VALUTO LA FORMA INDICATA DALL'UTENTE
				//controllo che la forma indicata esista in quelle disponibili
				def queryForm = services.queryService.executeQuery("SELECT cod_class_type FROM AIM_CLASS_TYPE WHERE cod_class_type=#{map.cod_class_type}",[cod_class_type:valuesMap.cod_class_type])[0]; 
				//gestisco la mancanza di permessi per la forma del contenuto e blocco l'inserimento con log di errore
				if(queryFormPerm==null || queryFormPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la forma del contenuto selezionata. <br>Impossibile creare contenuto");				
				}else if(queryForm==null || queryForm.size()==0){
					//gestisco la forma errata
					throw new RuntimeException("Attenzione: La Forma indicata è inesistente. <br>Impossibile creare contenuto");	
				}else if (valuesMap.cod_class_type==null){
					//gestisco la forma manacante (da csv)
					throw new RuntimeException("Attenzione: La Forma non è stata inserita. <br>Impossibile creare contenuto");	
				}
				
				//controllo che in caso di scelta di forma del contenuto di tipo scheda digitale la scelta della classe
				//sia vincolata all'inserimento singolo o multiplo; se l'inserimento è singolo per immobile lo blocco
				def querySch = "select count(id_content) as count from aim_content cont left join AIM_BIM_SCH_CONF conf on conf.class_name=cont.class_name";
				querySch += " where cont.cod_building=#{map.cod_building} and  cont.class_name=#{map.class_name}";
				def queryClassIns = services.queryService.executeQuery(querySch,valuesMap)[0];
				//ora controllo che il conteggio dei contenuti di tipo scheda digitale per ogni edificio sia corretto
				if(valuesMap.cod_class_type=='SCH' && queryClassIns.count>0){
					def queryDigDoc =  services.queryService.executeQuery("SELECT descr_class FROM AIM_BIM_SCH_CONF where class_name=#{map.class_name}",valuesMap)[0];
					throw new RuntimeException("Attenzione: Impossibile creare il contenuto scheda digitale indicato.<br>Per l'edificio <b>"+valuesMap.cod_building+"</b> è già presente un contenuto di tipo: <b>"+queryDigDoc.descr_class+"</b>");
				}			
				
				//i permessi sono ok e posso procedere alla creazione
				if((queryClassPerm!=null && queryClassPerm.size()>0) && (queryFormPerm!=null && queryFormPerm.size()>0)){		 
						log.info("AIM_CONTENT_TRIGGER:loggo la queryCodClass: "+queryCodClass);
						valuesMap.put("cod_class_arc",queryCodClass.cod_class_arc);
						valuesMap.put("cod_class_cat",queryCodClass.cod_class_cat);	
						valuesMap.put("cod_class_subcat",queryCodClass.cod_class_subcat);
						valuesMap.put("creation_date",new Date());
					}					
				//gestisco la creazione da revisione
				log.info("loggo il valuesMap.from_revision: "+valuesMap.from_revision);
				log.info("loggo il valore della IF: "+valuesMap.from_revision==1);
				if(valuesMap.from_revision==1){
					Integer rev_content = valuesMap.get("rev_content");
					Integer num_content = valuesMap.get("num_content");
					defCodContent = cod_building +'-'+ StringUtils.leftPad(num_content.toString(), 6, "0") + "-"+StringUtils.leftPad(rev_content.toString(), 2, "0");
					log.info("AIM_CONTENT_TRIGGER:controllo i valori che mi arrivano: "+valuesMap);
					log.info("AIM_CONTENT_TRIGGER:sono arrivato a calcolare il codice della nuova revisione: "+defCodContent);
					valuesMap.put("cod_content", defCodContent);
				}else{
					//CALCOLO IL PROGRESSIVO DEL CODICE DEL CONTENUTO (CODICE EDIFICIO + PROGRESSIVO + REVISIONE)
					def num_cont = services.queryService.executeQuery("SELECT count(id_content) as num_cont FROM aim_content WHERE cod_building='"+cod_building+"'", null)[0].num_cont;
					log.info("AIM_CONTENT_TRIGGER:num_cont: "+num_cont);
					
					if(num_cont==0){
						num_cont=1;
						log.info("AIM_CONTENT_TRIGGER:num_cont lungo: "+StringUtils.leftPad(num_cont.toString(), 6, "0"));
						defCodContent = cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00";
						valuesMap.put("cod_content", defCodContent);
						valuesMap.put("num_content",num_cont);
						valuesMap.put("rev_content",0);
						log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00"));
					}else {
						def max_cont = services.queryService.executeQuery("SELECT max(num_content) max_cont FROM aim_content WHERE cod_building='"+cod_building+"'", null)[0].max_cont;
						max_cont=max_cont++;
						log.info("AIM_CONTENT_TRIGGER:max_cont: "+max_cont++);
						defCodContent = cod_building +'-'+ StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00";
						valuesMap.put("cod_content", defCodContent);
						valuesMap.put("num_content",max_cont);
						valuesMap.put("rev_content",0);
						log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(cod_building+'-'+StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00"));
					}
				}			
			
				Integer num_revision = valuesMap.get("num_revision");
				Integer num_content = valuesMap.get("num_content");

				//recupero il vlore appena inserito
				String cod_class_subcat = valuesMap.get("cod_class_subcat");
				
				//SEZIONE PER IL RECUPERO DELLO STATO DEL CONTENUTO
				//CONTROLLO SE CI SONO DELLE TRACK, IN CASO NEGATIVO NON FACCIO CREARE IL CONTENUTO
				def validQuery = false;
				def queryST = null;
			
				
/*
			}else{
				throw new RuntimeException("Attenzione: L'utente non dispone dei permessi di creazione di un nuovo contenuto");
			}

		};
*/		


		log.info("AIM_CONTENT_TRIGGER:loggo valuesMap fine inserimento: "+valuesMap);
		
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){

	// RECUPERO INFORMAZIONI UTILI
	
	// recupero codice contenuto inserito
	def cod_content = valuesMap.get("cod_content");
	log.info("codice del contenuto inserito: " + cod_content);
	
	// recupero cod_class_type
	def cod_class_type = valuesMap.get("cod_class_type");
	log.info("codice della forma del contenuto inserito: " + cod_class_type);

	// recupero author
	def author = valuesMap.get("author");
	log.info("autore del contenuto inserito: " + author);
	
	// recupero data di creazione
	def creation_date = valuesMap.get("creation_date");
	log.info("data di creazione del contenuto inserito: " + creation_date);	
	
	// recupero codice immobile per contenuto inserito
	def cod_building = services.queryService.executeQuery("SELECT cod_building FROM aim_content WHERE cod_content = '" + cod_content + "'",null)[0].cod_building;
	log.info("codice dell'immobile inserito: " + cod_building);

	// recupero nome della classe della scheda digitale
	def class_name = valuesMap.get("class_name");
	log.info("classe della scheda digitale del contenuto inserito: " + class_name);
	

	// POPOLAMENTO DELLA TABELLA AIM_BIM_FILTER_R_CONTENT
	// per la visualizzazione dei contenuti
	
	// conto il numero di filtri a cui è associato l'immobile (tabella AIM_BIM_FILTER_R_BUILDING)
	def num_bui_fil = services.queryService.executeQuery("SELECT COUNT(1) as num_bui_fil FROM aim_bim_filter_r_building WHERE cod_building = '" + cod_building + "'",null)[0].num_bui_fil;
	log.info("numero di filtri a cui è associato il codice immobile: " + num_bui_fil);
	
	// se il conteggio è pari a zero, loggo
	if (num_bui_fil==0){
		log.info ("NON CI SONO FILTRI ASSOCIATI ALL'IMMOBILE " + cod_building + " DEL CONTENUTO " + cod_content);
		}
	// se il conteggio è maggiore di zero, recupero elenco di filtri associato all'immobile
	else if (num_bui_fil>0){
		def list_filter = services.queryService.executeQuery("SELECT cod_bim_filter FROM aim_bim_filter_r_building WHERE cod_building = '" + cod_building + "'",null);
		log.info("elenco dei filtri a cui è associato il codice immobile: " + list_filter);
		// ciclo l'inserimento dei filtri associati al contenuto (tabella AIM_BIM_FILTER_R_CONTENT)
		for (int i=0; i<list_filter.size(); i++){
			// definisco oggetto per inserimento
			def ins_rec = [:];
			ins_rec.cod_content = cod_content;
			ins_rec.cod_bim_filter = list_filter[i].cod_bim_filter;
			log.info("mappa di inserimento su AIM_BIM_FILTER_R_CONTENT: " + ins_rec);
			services.classService.insertClassRecord('aim_bim_filter_r_content', ins_rec);
			};
		};
		

	// POPOLAMENTO DELLA TABELLA AIM_CONTENT_SCH E SCHEDA DIGITALE
	// se il contenuto è di tipo scheda digitale
	if (cod_class_type=='SCH'){	
		// recupero dati della classe GW
		Class gwClass = services.gwm_classService.selectByClassName(new Class(class_name));
		// recupero chiave della classe GW
		def pk_class_name = gwClass.getGwid();
		log.info("GWID della classe della scheda digitale: " + pk_class_name);
		
		// POPOLO AIM_CONTENT_SCH
 		// definisco oggetto per inserimento
		def ins_sch = [:];
		ins_sch.cod_content = cod_content;
		ins_sch.fk_sch_class = pk_class_name;
		ins_sch.sch_code_column = 'cod_content';
		ins_sch.sch_code = cod_content;
		ins_sch.sch_layout = 'default_sch';
		ins_sch.author = author;
		ins_sch.creation_date = creation_date;
		log.info("mappa di inserimento su AIM_CONTENT_SCH: " + ins_sch);
		services.classService.insertClassRecord('aim_content_sch', ins_sch);
		
		// POPOLA SCHEDA DIGITALE SPECIFICA
		def ins_sch_spec = [:];
		ins_sch_spec.cod_building = cod_building;
		ins_sch_spec.cod_content = cod_content;
		ins_sch_spec.is_sch_complete = 0;
		log.info("mappa di inserimento su scheda digitale specifica: " + ins_sch_spec);
		services.classService.insertClassRecord(class_name, ins_sch_spec);
		
		}
		
		
	// POPOLAMENTO DELLA TABELLA AIM_CONTENT_DOC (PROVA MPE + MBT del 14/01/2021)
	// se il contenuto è di tipo documento
	else if (cod_class_type=='DOC'){
		// POPOLO AIM_CONTENT_DOC
 		// definisco oggetto per inserimento
		def ins_doc = [:];
		ins_doc.cod_content = cod_content;
		ins_doc.file_path = cod_building + '/DOC/' + cod_content;
		log.info("mappa di inserimento su AIM_CONTENT_DOC: " + ins_doc);
		services.classService.insertClassRecord('aim_content_doc', ins_doc);		
	}
	

	// POPOLAMENTO DELLA TABELLA AIM_CONTENT_GAL (PROVA MPE + MBT del 14/01/2020
	// se il contenuto è di tipo galleria
	else if (cod_class_type=='GAL'){
		// POPOLO AIM_CONTENT_GAL
 		// definisco oggetto per inserimento
		def ins_gal = [:];
		ins_gal.cod_content = cod_content;
		ins_gal.file_path = cod_building + '/GAL/' + cod_content;
		log.info("mappa di inserimento su AIM_CONTENT_GAL: " + ins_gal);
		services.classService.insertClassRecord('aim_content_gal', ins_gal);		
	}	
		
		
		
		

	
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		//predispongo i controlli nel caso di modifica della classificazione del contenuto
		def content_class = valuesMap.content_class;
		def cod_class_type = oldvaluesMap.cod_class_type;
		log.info("loggo la mappa dei valori modificati: "+valuesMap);
		log.info("loggo la mappa dei valori immutati: "+oldvaluesMap);
		if(content_class!=null){
			if(cod_class_type!='SCH'){			
				//recupero le variabili in sessione	dal groovy di seguito:
				SessionObject sessionObject = services.gse.runScript("getSessionObject.groovy");
				log.info("loggo il sessionObject: "+sessionObject);
				if(sessionObject!=null){
					//recupero le variabili per la gestione della modifica della classificazione
					String user = sessionObject.getUser();
					log.info("loggo l'utente in sessione: "+user);				
				//recupero archivio e categoria dalla nuova classificazione scelta
					def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",[content_class:valuesMap.content_class])[0]; 
					log.info("loggo la mappa della classificazione modificata: "+queryCodClass);
				//controllo se la classificazione scelta rientra nei filtri impostati per l'utente
					def queryClassPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+user+"' and groups='AIM_CONTENT_OWNER') and (cod_class_filter is null or cod_class_filter='"+queryCodClass.cod_class_arc+"' or cod_class_filter='"+queryCodClass.cod_class_cat+"')", null);		
					log.info("loggo la mappa dei permessi della classificazione modificata: "+queryClassPerm);
					if(queryClassPerm==null || queryClassPerm.size()==0){
						throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la classificazione selezionata. <br>Impossibile modificare il contenuto");					
					}else{
						valuesMap.put("cod_class_arc",queryCodClass.cod_class_arc);
						valuesMap.put("cod_class_cat",queryCodClass.cod_class_cat);	
						valuesMap.put("cod_class_subcat",queryCodClass.cod_class_subcat);				
					}
				}
			}else{
				throw new RuntimeException("Attenzione: La forma del contenuto non consente di modificare<br> la classificazione.<br>La modifica riguarda i soli contenuti di forma <br>DOCUMENTO o MODELLO BIM");									
			}			
		}					
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	//recupero in caso di modifica della classificazione i parametri per rimappare la tabella materializzata dei permessi per contenuto
	def content_class = valuesMap.content_class;
	if (content_class!=null){
		//recupero archivio e categoria dalla nuova classificazione scelta
		def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",valuesMap)[0]; 	
		// controllo in quanti filtri ricade la nuova classificazione;
		def classFilterAll = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER WHERE  ((cod_class_filter=#{map.cod_class_arc} or cod_class_filter=#{map.cod_class_cat} or cod_class_filter is null) and  (cod_content_type is null or cod_content_type=#{map.cod_class_type}))",[cod_class_type:oldvaluesMap.cod_class_type,cod_class_arc:queryCodClass.cod_class_arc,cod_class_cat:queryCodClass.cod_class_cat]);
		log.info("loggo la mappa dei filtri possibili: "+classFilterAll);
		def delContOld = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_content=#{map.cod_content}",oldvaluesMap);		
		//ciclo il risultato
		for(int q=0;q<classFilterAll.size();q++){
			classFilterAll[q].cod_content=oldvaluesMap.cod_content;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def ContIns = "INSERT INTO AIM_BIM_FILTER_R_CONTENT (cod_bim_filter, cod_content)";
			ContIns+=" VALUES ";
			ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
			def ins_cont = services.queryService.executeQuery(ContIns,classFilterAll[q]);		
		}			
	} 
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		def pcCont = valuesMap.id_content;
		def selectCode = "SELECT cod_content FROM aim_content where id_content="+pcCont;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukCont = result.cod_content;

		//eliminazione dati BIM DATA su trigger aim_content_bim

		//gestisco l'eliminazione delle classi  
		def delInfo = services.queryService.executeDeleteQuery("DELETE FROM AIM_CONTENT_HISTORY WHERE cod_content='"+ukCont+"'",null);
		def delPermCont = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_content='"+ukCont+"'",null);


		// RECUPERO LA CHIAVE DEL RECORD DEL CONTENUTO
		def pk_rec = valuesMap.id_content;
		log.info("chiave del record in cancellazione: " + pk_rec);
		
		// RECUPERO IL CODICE DEL CONTENUTO
		def cod_rec = services.queryService.executeQuery("SELECT cod_content AS cod_rec FROM aim_content WHERE id_content=" + pk_rec, null)[0].cod_rec;
		log.info("codice del record in cancellazione: " + cod_rec);
		
		// RECUPERO IL TIPO DI CONTENUTO
		def cod_rec_type = services.queryService.executeQuery("SELECT cod_class_type AS cod_rec_type FROM aim_content WHERE id_content=" + pk_rec, null)[0].cod_rec_type;
		log.info("codice del tipo record in cancellazione: " + cod_rec_type);	

		// SE IL TIPO E' SCHEDA DIGITALE, RECUPERO LA CLASSE GW
		def class_name=null;
		if (cod_rec_type=='SCH'){
			// RECUPERO LA CLASSE SCH IN CANCELLAZIONE
			class_name = services.queryService.executeQuery("SELECT class_name FROM aim_content WHERE id_content=" + pk_rec, null)[0].class_name;		
			};
		log.info("classe geoweb scheda digitale record in cancellazione: " + class_name);	
	
		
		// RECUPERO IL FLAG DI CARICAMENTO
		def is_uploaded = services.queryService.executeQuery("SELECT is_uploaded FROM aim_content WHERE id_content=" + pk_rec, null)[0].is_uploaded;
		log.info("flag di contenuto caricato in cancellazione: " + is_uploaded);
		
        // AGGIUNGO INFO ALLA MAPPA PER PASSARLO ALL'AFTER DELETE
        valuesMap.cod_rec_delete=cod_rec;
		valuesMap.cod_rec_type_delete=cod_rec_type;	
		valuesMap.is_uploaded_delete=is_uploaded;
		valuesMap.class_name_delete=class_name;
		log.info("mappa in uscita per l'after delete: " + valuesMap);
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
		
		log.info("mappa in ingresso all'after delete: " + valuesMap);
		
       // RECUPERO IL CODICE DEL RECORD CANCELLATO
        def cod_delete = valuesMap.cod_rec_delete;
        log.info("codice del record cancellato: " + cod_delete);
		
		// RECUPERO IL CODICE DEL TIPO DI RECORD CANCELLATO
		def cod_delete_type = valuesMap.cod_rec_type_delete;
        log.info("codice del tipo di record cancellato: " + cod_delete_type);
		
		// RECUPERO IL FLAG DI CONTENUTO CARICATO
		def is_uploaded_delete = valuesMap.is_uploaded_delete;
        log.info("flag di caricamento record cancellato: " + is_uploaded_delete);
		
		// RECUPERO NOME DELLA CLASSE (SCH) IN CANCELLAZIONE
		def class_name_delete = valuesMap.class_name_delete;
        log.info("nome classe gw scheda digitale record cancellato: " + class_name_delete);
		
		// CANCELLO DA AIM_CONTENT_NEW_GAL
		if (cod_delete_type=='GAL' && is_uploaded_delete==1){
			// CANCELLO DA AIM_CONTENT_NEW_GAL
			def pk_del_new_gal = services.queryService.executeQuery("SELECT id_content_new_gal AS pk_del_new_gal FROM aim_content_new_gal WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_new_gal;
			log.info("chiave del record galleria fotografica (appoggio) da cancellare: " + pk_del_new_gal);
			// cancello il record
			services.queryService.executeQuery("DELETE FROM aim_content_new_gal WHERE id_content_new_gal=" + pk_del_new_gal,null);
			};
		

		// CANCELLO DA AIM_CONTENT_NEW_DOC
		if (cod_delete_type=='DOC' && is_uploaded_delete==1){		
			def pk_del_new_doc = services.queryService.executeQuery("SELECT id_content_new_doc AS pk_del_new_doc FROM aim_content_new_doc WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_new_doc;
			log.info("chiave del record documento (appoggio) da cancellare: " + pk_del_new_doc);
			// cancello il record
			services.queryService.executeQuery("DELETE FROM aim_content_new_doc WHERE id_content_new_doc=" + pk_del_new_doc,null);
			};

			
		// CANCELLO DA AIM_CONTENT_SCH E CLASSI DELLE SCHEDE DIGITALI
		if (cod_delete_type=='SCH'){		
			
			// CANCELLO DA AIM_CONTENT_SCH 
			// recupero chiave del record da cancellare
			def pk_del_sch = services.queryService.executeQuery("SELECT id_sch AS pk_del_sch FROM aim_content_sch WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch;
			log.info("chiave del record aim_content_sch da cancellare: " + pk_del_sch);
			// cancello il record
			services.queryService.executeQuery("DELETE FROM aim_content_sch WHERE id_sch=" + pk_del_sch,null);

			// CANCELLO DALLA CLASSE DELLE SCHEDE DIGITALI
			// fascicolo fabbricato - quadro A
			if (class_name_delete=='aim_sch_fasc_fabbricato_qa'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qa WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato A da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qa WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);			
				}
			// fascicolo fabbricato - quadro B
			else if (class_name_delete=='aim_sch_fasc_fabbricato_qb'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qb WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato B da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qb WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);			
				}
			// fascicolo fabbricato - quadro C
			else if (class_name_delete=='aim_sch_fasc_fabbricato_qc'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qc WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato C da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qc WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);						
				}
			// fascicolo fabbricato - quadro D
			else if (class_name_delete=='aim_sch_fasc_fabbricato_qd'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qd WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato D da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qd WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);						
				}
			// fascicolo fabbricato - quadro E
			else if (class_name_delete=='aim_sch_fasc_fabbricato_qe'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qe WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato E da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qe WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);						
				}
			// fascicolo fabbricato - quadro F
			else if (class_name_delete=='aim_sch_fasc_fabbricato_qf'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_fasc_fabbricato AS pk_del_sch_class FROM aim_sch_fasc_fabbricato_qf WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record fascicolo fabbricato F da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_fasc_fabbricato_qf WHERE id_fasc_fabbricato=" + pk_del_sch_class,null);						
				}
			// fascicolo fabbricato - scheda intervento 
			else if (class_name_delete=='aim_sch_scheda_intervento'){
				def pk_del_sch_class = services.queryService.executeQuery("SELECT id_scheda_intervento AS pk_del_sch_class FROM aim_sch_scheda_intervento WHERE cod_content='" + cod_delete + "'", null)[0].pk_del_sch_class;
				log.info("chiave del record scheda intervento da cancellare: " + pk_del_sch_class);			
				// cancello il record
				services.queryService.executeQuery("DELETE FROM aim_sch_scheda_intervento WHERE id_scheda_intervento=" + pk_del_sch_class,null);						
				};
				
			// mettere altre eventuali schede digitali da cancellare

			

			
			};




        return true;
    };

} 