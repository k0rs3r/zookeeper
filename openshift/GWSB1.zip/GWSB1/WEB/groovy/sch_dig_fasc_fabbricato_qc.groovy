public class sch_dig_fasc_fabbricato_qc extends com.geowebframework.transfer.objects.digitaldocument.GwDigitalDocumentConfigImpl {
	
	public Boolean isVisible(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){

		log.error("templateName: "+templateName);
		log.error("sectionName: "+sectionName);
		log.error("entityName: "+entityName);
		log.error("entityStatus: "+entityStatus);
		def isVisible = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qc")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QC_01")||
				sectionName.equals("QC_02")||
				sectionName.equals("QC_03")||
				sectionName.equals("QC_04")||
				sectionName.equals("QC_05")||
				sectionName.equals("QC_06")||
				sectionName.equals("QC_07")||
				sectionName.equals("QC_08")||
				sectionName.equals("QC_08A")||
				sectionName.equals("QC_08B")||
				sectionName.equals("QC_08C")||
				sectionName.equals("QC_08D")||
				sectionName.equals("QC_09")||
				sectionName.equals("QC_09A")||
				sectionName.equals("QC_09B1")||
				sectionName.equals("QC_09B2")||
				sectionName.equals("QC_09B3")||
				sectionName.equals("QC_09C")||
				sectionName.equals("QC_10")||
				sectionName.equals("QC_99")
			)
				{
					isVisible = true;
					log.error("isVisible = true");
				}
			
		}
		log.error("isVisible: "+isVisible);
		return isVisible;
	}
	public Boolean isEditable(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isEditable = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qc")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QC_01")||
				sectionName.equals("QC_02")||
				sectionName.equals("QC_03")||
				sectionName.equals("QC_04")||
				sectionName.equals("QC_05")||
				sectionName.equals("QC_06")||
				sectionName.equals("QC_07")||
				sectionName.equals("QC_08")||
				sectionName.equals("QC_08A")||
				sectionName.equals("QC_08B")||
				sectionName.equals("QC_08C")||
				sectionName.equals("QC_08D")||
				sectionName.equals("QC_09")||
				sectionName.equals("QC_09A")||
				sectionName.equals("QC_09B1")||
				sectionName.equals("QC_09B2")||
				sectionName.equals("QC_09B3")||
				sectionName.equals("QC_09C")||
				sectionName.equals("QC_10")||
				sectionName.equals("QC_99")
			)
				{
					isEditable = true;
				}
			
		}
		return isEditable;
	}
	
	public Boolean isDefaultSelected(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isDefaultSelected = false;
		return isDefaultSelected;
	}

}