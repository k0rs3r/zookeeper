//user:    MPE
//date:    30/01/2020
//ver:     4.4.8
//project: CA_ConnectorControl
//type:    connettor trigger
//class:   varie 
//note:    groovy per richiesta creazione adempimenti (da AIM a MASTER DATA / RISK & COMPLIANCE)
//         sistema di origine: AIM
// 		   database origine = SUPERBONUS
//		   schema origine = cde_dati_gw
//		   tabella/vista origine = v_cnt_aim_content_out

//		   sistema di destinazione = MASTER DATA
//		   database destinazione = SUPERBONUS
//		   schema destinazione = data_gw
//		   tabella destinazione = cnt_aim_content_out


// AVVIO CONNETTORE
log.info("INIZIO ESECUZIONE CONNETTORE cnt_aim_content_out " + new Date());

// CONTROLLO SE CI SONO RECORD NELLA VISTA DI PREDISPOSIZIONE DATI
def count_rec_orig = queryService.executeQuery("SELECT COUNT (1) AS count_rec_orig FROM v_cnt_content_out",null)[0].count_rec_orig;
log.info("numero record nella vista v_cnt_content_out: " + count_rec_orig);

// SE IL CONTEGGIO DEI RECORD NELLA VISTA DI PREDISPOSIZIONE DATI E' PARI A ZERO, INSERISCO EVENTO
if (count_rec_orig==0){
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_content_out';
	ins_event.date_start = new Date();
	ins_event.date_end = new Date();
	ins_event.record_insert = count_rec_orig;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'Non sono presenti contenuti per cui richiedere la creazione del corrispondente adempimento.';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);
	};


// SE CI SONO, PROCEDO
if (count_rec_orig>0){
	def date_start = new Date(); 
	log.info("data e ora di inizio connettore: " + date_start);
	// recupero lista di record da inserire
	def list_record = queryService.executeQuery("SELECT * FROM v_cnt_content_out",null);
	log.info("elenco dei record da inserire: " + list_record);
	// ciclo inserimento
	for (int i=0; i<list_record.size(); i++){
		// POPOLAMENTO TABELLA CONNETTORE
		// definisco query di inserimento nella tabella di appoggio del connettore
		def query_ins = "INSERT INTO data_gw.aim_cnt_content_out (cod_content,cod_building,cod_permission_type,date_record_in) VALUES ('" + list_record[i].cod_content + "','" + list_record[i].cod_building + "','" + list_record[i].cod_permission_type + "',current_timestamp)";
		log.info("query di inserimento record " + i + ": " + query_ins);
		// eseguo query di inserimento nella tabella di appoggio del connettore
		queryService.executeQuery(query_ins ,null);
		// AGGIORNAMENTO RECORD CONTENUTO
		// definisco query di aggiornamento del contenuto (is_send_to_risk)
		def query_upd = "UPDATE aim_content SET is_send_to_risk=1 WHERE cod_content='" + list_record[i].cod_content + "'";
		log.info("query di update is_send_to_risk " + query_upd);
		// eseguo query di aggiornamento del contenuto (is_send_to_risk)
		queryService.executeQuery(query_upd ,null);
		// definisco query per aggiornamento del contenuto (date_send_to_risk)
		query_upd = "UPDATE aim_content SET date_send_to_risk=current_timestamp WHERE cod_content='" + list_record[i].cod_content + "'";
		log.info("query di update is_send_to_risk " + query_upd);	
		// eseguo query di aggiornamento del contenuto (date_send_to_risk)
		queryService.executeQuery(query_upd ,null);
		};
	def num_record_ins = list_record.size();
	log.info("numero di record inseriti: " + num_record_ins);
	
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_content_out';
	ins_event.date_start = date_start
	ins_event.date_end = new Date();
	ins_event.record_insert = num_record_ins;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'E\' stata richiesta la creazione di adempimenti per n. ' +  num_record_ins + ' contenuti.';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);	

	};
	
	
	
	


// FINE CONNETTORE
log.info("FINE ESECUZIONE CONNETTORE cnt_aim_content_out " + new Date());