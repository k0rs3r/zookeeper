//user:    APA
//date:    22/10/2019
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_drawing
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 

/* ATTENZIONE: il groovy estende la classe GwdDrawingTrigger (trigger Java di Geoweb) e non lo standard EventTrigger
*  il trigger Java nell'afterInsert crea le relazioni tra le drawing e drawing set seguendo le impostazioni salvate sulle
*  tabelle gwd_template_map e gwd_r_drawing_type_map
*/
public class GwdDrawingTriggerGroovy extends com.geowebframework.gwPublish.trigger.GwdDrawingTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		//CASO BIM DATA:
		//recupero attraverso le due query il codice dell'edificio e lo salvo sul campo cod_01_cmis per costruire il percorso di salvataggio del
		//DWG su documentale
		if(valuesMap.structure_code!=null){
			def query1 = services.queryService.executeQuery("select project from GWD_BIM_MODEL_STRUCTURE where structure_code=#{map.structure_code}",valuesMap)[0];
			def project = query1.project;
			def query2 = services.queryService.executeQuery("select cod_building from GWD_BIM_PROJECT where project_code=#{map.project}",[project:project])[0];
			valuesMap.put("cod_01_cmis",query2.cod_building);	
		}
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		//creare associazione tra drawing e drawing set e model console
		def structureCode = valuesMap.structure_code;
		def rev = valuesMap.rev;
		def pkDrawing = valuesMap.itemId;
		def fk_layout = valuesMap.fk_layout;
		def dwgName = valuesMap.dwg_name;
		
		//se parte dal bim data i due campi sono popolati
		if(structureCode!=null && rev != null){
			
			//recupero modello federato
			def prjQuery = "select project from gwd_bim_model_structure where structure_code=#{map.structureCode}";
			def map = [:];
			map.structureCode = structureCode;
			def selectProject = services.queryService.executeQuery(prjQuery, map);
			def project = selectProject[0].project;
			
			def codFedModelQuery = "select cod_fed_model from gwd_fed_model where is_active=1 and cod_project=#{map.project}";
			def map1 = [:];
			map1.project = project;
			def selectCodFedModel = services.queryService.executeQuery(codFedModelQuery, map1);
			def codFedModel = selectCodFedModel[0].cod_fed_model;
			
			//recupero il drawing set di default, è quello del bim data
			def defaultDrawingSet = "select pk_drawing_set from gwd_drawing_set where is_default=1 and fk_layout="+fk_layout;
			def selectPkDefaultDrawingSet = services.queryService.executeQuery(defaultDrawingSet, null);
			def pkDefaultDrawingSet = selectPkDefaultDrawingSet[0].pk_drawing_set;
			
			//se rev = 0 => aggiungo record su model_console e r_draw_set_draw
			if(rev==0){
				
				def modelConsole = [:];
				modelConsole.cod_fed_model = codFedModel;
				modelConsole.structure_code = structureCode;
				modelConsole.model_type = '2D';
				modelConsole.id_model = pkDrawing;
				services.classService.insertClassRecord('gwd_model_console',modelConsole);
				
				def rDrawSetDraw = [:];
				rDrawSetDraw.fk_drawing = pkDrawing;
				rDrawSetDraw.fk_drawing_set = pkDefaultDrawingSet;
				services.classService.insertClassRecord('gwd_r_draw_set_draw',rDrawSetDraw);
				
			} else {
				//se rev>0 => recupero record con rev-1
				def oldrev = rev-1;
				def oldDrawingQuery = "select pk_drawing from gwd_drawing where structure_code=#{map.structureCode} and rev="+oldrev;
				def pkOldDrawing = services.queryService.executeQuery(oldDrawingQuery, map);
				def oldPkDrawing = pkOldDrawing[0].pk_drawing;
				
				//aggiorno record su model_console con id nuovo drawing
				def updateModelConsoleQuery = "update gwd_model_console set id_model="+pkDrawing+" where id_model="+oldPkDrawing;
				services.queryService.executeQuery(updateModelConsoleQuery, null);
				
				//update r_draw_set_draw con id nuovo drawing
				def updateRDrawSetDrawQuery = "update gwd_r_draw_set_draw set fk_drawing="+pkDrawing+" where fk_drawing="+oldPkDrawing+" and fk_drawing_set="+pkDefaultDrawingSet;
				services.queryService.executeQuery(updateRDrawSetDrawQuery, null);
			}
			
		} else {
			//temporaneamente il trigger java viene richiamato solo in questo caso, ma da verificare se utilizzabile sempre.
			super.afterInsert(valuesMap);
			def layoutCode = services.queryService.executeQuery("select layout_code from gwd_layout where pk_layout="+fk_layout, null)[0].layout_code;
			def map = [:];
			map.cod_content = layoutCode;
			map.drawing_name = dwgName;
			map.fk_drawing = pkDrawing;
			services.queryService.executeQuery("update aim_content set is_uploaded=1 where cod_content=#{map.cod_content}", map);
			services.queryService.executeQuery("update aim_content_v2d set drawing_name=#{map.drawing_name}, fk_drawing=#{map.fk_drawing} where cod_content=#{map.cod_content}", map);
			
		}
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		
		HashMap<String,Object> allValuesMap = new HashMap<String,Object>();
		allValuesMap.putAll(oldValuesMap);
		allValuesMap.putAll(valuesMap);
		log.info("DRAWING mappa completa del record: "+allValuesMap);
		//CASO MODELLO BIM
		if(allValuesMap.structure_code!=null){
			def res = services.queryService.executeQuery("select cod_fed_model from GWD_MODEL_CONSOLE where id_model=#{map.pk_drawing}", allValuesMap);
			log.info("DRAWING risultato query sulla GWD_MODEL_CONSOLE: "+res);
			if(res!=null && res.size()>0){
				for(int k=0; k<res.size(); k++){
					def res1 = services.queryService.executeQuery("select distinct fk_object from GWD_FED_MODEL where cod_fed_model=#{map.cod_fed_model}", [cod_fed_model : res[k].cod_fed_model]);
					log.info("DRAWING risultato query sulla GWD_FED_MODEL: "+res1);
					allValuesMap.cod_content = res1[0].fk_object;
					services.queryService.executeQuery("update AIM_CONTENT set is_uploaded=1 where cod_content=#{map.cod_content}", allValuesMap);
					services.queryService.executeQuery("update AIM_CONTENT_BIM set modification_author=#{map.check_in_user}, modification_date=#{map.check_in_date}, file_num=file_num+1  where cod_content=#{map.cod_content}", allValuesMap);
				}
			}
		} else {
			//CASO VISTA DI MODELLO
			def md5 = oldValuesMap.md5;
			if(md5!=null && md5!=""){
				def layoutCode = services.queryService.executeQuery("select layout_code from gwd_layout where fk_layout="+allValuesMap.fk_layout, null)[0].layout_code;
				def v2dMap = [:];
				v2dMap.cod_content = layoutCode;
				v2dMap.drawing_name = allValuesMap.dwg_name;
				v2dMap.modification_author = allValuesMap.check_in_user;
				v2dMap.modification_date = allValuesMap.check_in_date;
				services.queryService.executeQuery("update aim_content_v2d set drawing_name=#{map.drawing_name}, modification_author=#{map.modification_author}, modification_date=#{map.modification_date} where cod_content=#{map.cod_content}", v2dMap);
			
			}
		}
		
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	    return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 