//user:    MPE
//date:    30/01/2020
//ver:     4.4.8
//project: CA_ConnectorControl
//type:    connettor trigger
//class:   varie 
//note:    groovy per acquisizione tipologie di adempimento (da MASTER DATA / RISK & COMPLIANCE ad AIM)
//         sistema di origine: MASTER DATA
// 		   database origine = SUPERBONUS
//		   schema origine = data_gw
//		   tabella origine = pem_cnt_permission_type_out

//		   sistema di destinazione = AIM
//		   database destinazione = SUPERBONUS
//		   schema destinazione = cde_dati_gw
//		   tabella destinazione = aim_tab_permission_type


// AVVIO CONNETTORE
log.info("INIZIO ESECUZIONE CONNETTORE cnt_aim_permission_type_in " + new Date());

// CONTROLLO SE CI SONO RECORD NELLA TABELLA DI INTERSCAMBIO DATI
def count_rec_orig = queryService.executeQuery("SELECT COUNT (1) AS count_rec_orig FROM data_gw.pem_cnt_permission_type_out",null)[0].count_rec_orig;
log.info("numero record nella tabella pem_cnt_permission_type_out: " + count_rec_orig);

// SE IL CONTEGGIO DEI RECORD NELLA VISTA DI PREDISPOSIZIONE DATI E' PARI A ZERO, INSERISCO EVENTO
if (count_rec_orig==0){
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_permission_type_in';
	ins_event.date_start = new Date();
	ins_event.date_end = new Date();
	ins_event.record_insert = count_rec_orig;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'Non sono presenti tipologie di adempimento da acquisire.';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);
	};


// SE CI SONO, PROCEDO
if (count_rec_orig>0){
	def date_start = new Date(); 
	log.info("data e ora di inizio connettore: " + date_start);
	// recupero lista di record da inserire
	def list_record = queryService.executeQuery("SELECT * FROM data_gw.pem_cnt_permission_type_out",null);
	log.info("elenco dei record da inserire: " + list_record);
	// definisco query di svuotamento della tabella di destinazione
	def query_del = "DELETE FROM cde_dati_gw.aim_tab_permission_type";
	// eseguo query di svuotamento della tabella del connettore
	queryService.executeQuery(query_del ,null);	
	// ciclo inserimento
	for (int i=0; i<list_record.size(); i++){	
		// POPOLAMENTO TABELLA DESTINAZIONE
		// definisco query di inserimento nella tabella di destinazione
		def query_ins = "INSERT INTO cde_dati_gw.aim_tab_permission_type (id_permission_type,cod_permission_type,name_permission_type) VALUES (" + list_record[i].id_cnt_permission_type_out + ",'" + list_record[i].cod_permission_type + "','" + list_record[i].name_permission_type + "')";		
		log.info("query di inserimento record " + i + ": " + query_ins);
		// eseguo query di inserimento nella tabella di destinazione
		queryService.executeQuery(query_ins ,null);
		};
	def num_record_ins = list_record.size();
	log.info("numero di record inseriti: " + num_record_ins);
	
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_permission_type_in';
	ins_event.date_start = date_start
	ins_event.date_end = new Date();
	ins_event.record_insert = num_record_ins;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'E\' stata acquisita l\'anagrafica delle tipologie di adempimento (n. ' +  num_record_ins + ' record).';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);	

	};
	
	
	
	


// FINE CONNETTORE
log.info("FINE ESECUZIONE CONNETTORE cnt_aim_permission_type_in " + new Date());