import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		String author = valuesMap.get("author");
		String usergroup = valuesMap.get("usergroup");
		log.info("AIM_CONTENT_TRIGGER:loggo l'autore: "+author+usergroup);
		Integer from_revision = valuesMap.get("from_revision");
		Integer single_insert = valuesMap.get("single_insert");
		String cod_building = valuesMap.get("cod_building");
		log.info("AIM_CONTENT_TRIGGER:cod_building: "+cod_building);
		log.info("AIM_CONTENT_TRIGGER:single_insert: "+single_insert);
		def defCodContent = null;
		log.info("AIM_CONTENT_TRIGGER:loggo la mappa dei valori in ingresso x il nuovo contenuto: "+valuesMap);


		if(!usergroup.equals("AIM_BIM")){


			//CONTROLLO CHE L'UTENTE ABBIA I PERMESSI PER L'INSERIMENTO; SONO GLI STESSI DELLA VISUALIZZAZIONE:
			def queryPermission = services.queryService.executeQuery("SELECT DISTINCT username FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='"+usergroup+"') or groups='AIM_CONTENT_VERIFIER'",null)[0];
			log.info("AIM_CONTENT_TRIGGER:queryPermission: "+queryPermission);
			if(queryPermission!=null && queryPermission.size()>0){
				 
				//VALUTO SE L'EDIFICIO SCELTO DALL'UTENTE è CORRETTO
				def queryBuildPerm = services.queryService.executeQuery("SELECT DISTINCT cod_building FROM V_AIM_BUILDING_PERMISSION WHERE cod_building='"+cod_building+"' and (username='"+author+"' and groups='AIM_CONTENT_OWNER') ",null)[0];
				if(queryBuildPerm==null || queryBuildPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente <b>"+author+"</b> non detiene i permessi per creare <br>contenuti relativi all'edificio indicato: <b>"+cod_building+"</b>");
				}
				//VALUTO LA CLASSIFICAZIONE
				//RECUPERO L'ARCHIVIO DALLA CLASSIFICAZIONE (SOTTOCATEGORIA) 
				//def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",[content_class:valuesMap.content_class])[0]; 
				def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class} or cod_class=#{map.content_class_2}",[content_class:valuesMap.content_class,content_class_2:valuesMap.cod_class_subcat])[0]; 
				log.info("AIM_CONTENT_TRIGGER:queryCodClass: " + queryCodClass);
				
				//controllo che i dati di classificazione siano corretti o presenti
				if (queryCodClass==null || queryCodClass.size()==0){
					//gestisco la classificazione errata
					throw new RuntimeException("Attenzione: Classificazione inesistente. <br>Impossibile creare contenuto");
				}
				//else if(valuesMap.content_class==null){
				else if(valuesMap.content_class==null && valuesMap.cod_class_subcat==null){
					//gestisco la classificazione manacante (da csv)
					throw new RuntimeException("Attenzione: Classificazione non specificata. <br>Impossibile creare contenuto");
				}					
				//controllo se la classificazione scelta rientra nei filtri impostati per l'utente
				def queryClassPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='AIM_CONTENT_OWNER') and (cod_class_filter is null or cod_class_filter='"+queryCodClass.cod_class_arc+"' or cod_class_filter='"+queryCodClass.cod_class_cat+"')", null);
				//controllo se la forma scelta rientra nei filtri impostati per l'utente
				def queryFormPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='AIM_CONTENT_OWNER') and (cod_content_type is null or cod_content_type=#{map.cod_class_type})",[cod_class_type:valuesMap.cod_class_type]);			 
				log.info("loggo la query dei permessi sulla classificazione: "+queryClassPerm);
				log.info("loggo la query dei permessi sulla forma: "+queryFormPerm);
				//gestisco la mancanza di permessi per la classificazione e blocco l'inserimento con log di errore
				if(queryClassPerm==null || queryClassPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la classificazione selezionata. <br>Impossibile creare contenuto");					
				}
				
				//VALUTO LA FORMA INDICATA DALL'UTENTE
				//controllo che la forma indicata esista in quelle disponibili
				def queryForm = services.queryService.executeQuery("SELECT cod_class_type FROM AIM_CLASS_TYPE WHERE cod_class_type=#{map.cod_class_type}",[cod_class_type:valuesMap.cod_class_type])[0]; 
				//gestisco la mancanza di permessi per la forma del contenuto e blocco l'inserimento con log di errore
				if(queryFormPerm==null || queryFormPerm.size()==0){
					throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la forma del contenuto selezionata. <br>Impossibile creare contenuto");				
				}else if(queryForm==null || queryForm.size()==0){
					//gestisco la forma errata
					throw new RuntimeException("Attenzione: La Forma indicata è inesistente. <br>Impossibile creare contenuto");	
				}else if (valuesMap.cod_class_type==null){
					//gestisco la forma manacante (da csv)
					throw new RuntimeException("Attenzione: La Forma non è stata inserita. <br>Impossibile creare contenuto");	
				}
				
				//controllo che in caso di scelta di forma del contenuto di tipo scheda digitale la scelta della classe
				//sia vincolata all'inserimento singolo o multiplo; se l'inserimento è singolo per immobile lo blocco
				def querySch = "select count(id_content) as count from aim_content cont left join AIM_BIM_SCH_CONF conf on conf.class_name=cont.class_name";
				querySch += " where cont.cod_building=#{map.cod_building} and  cont.class_name=#{map.class_name}";
				def queryClassIns = services.queryService.executeQuery(querySch,valuesMap)[0];
				//ora controllo che il conteggio dei contenuti di tipo scheda digitale per ogni edificio sia corretto
				if(valuesMap.cod_class_type=='SCH' && queryClassIns.count>0){
					def queryDigDoc =  services.queryService.executeQuery("SELECT descr_class FROM AIM_BIM_SCH_CONF where class_name=#{map.class_name}",valuesMap)[0];
					throw new RuntimeException("Attenzione: Impossibile creare il contenuto scheda digitale indicato.<br>Per l'edificio <b>"+valuesMap.cod_building+"</b> è già presente un contenuto di tipo: <b>"+queryDigDoc.descr_class+"</b>");
				}			
				
				//i permessi sono ok e posso procedere alla creazione
				if((queryClassPerm!=null && queryClassPerm.size()>0) && (queryFormPerm!=null && queryFormPerm.size()>0)){		 
						log.info("AIM_CONTENT_TRIGGER:loggo la queryCodClass: "+queryCodClass);
						valuesMap.put("cod_class_arc",queryCodClass.cod_class_arc);
						valuesMap.put("cod_class_cat",queryCodClass.cod_class_cat);	
						valuesMap.put("cod_class_subcat",queryCodClass.cod_class_subcat);
						valuesMap.put("creation_date",new Date());
					}					
				//gestisco la creazione da revisione
				log.info("loggo il valuesMap.from_revision: "+valuesMap.from_revision);
				log.info("loggo il valore della IF: "+valuesMap.from_revision==1);
				if(valuesMap.from_revision==1){
					Integer rev_content = valuesMap.get("rev_content");
					Integer num_content = valuesMap.get("num_content");
					defCodContent = cod_building +'-'+ StringUtils.leftPad(num_content.toString(), 6, "0") + "-"+StringUtils.leftPad(rev_content.toString(), 2, "0");
					log.info("AIM_CONTENT_TRIGGER:controllo i valori che mi arrivano: "+valuesMap);
					log.info("AIM_CONTENT_TRIGGER:sono arrivato a calcolare il codice della nuova revisione: "+defCodContent);
					valuesMap.put("cod_content", defCodContent);
				}else{
					//CALCOLO IL PROGRESSIVO DEL CODICE DEL CONTENUTO (CODICE EDIFICIO + PROGRESSIVO + REVISIONE)
					def num_cont = services.queryService.executeQuery("SELECT count(id_content) as num_cont FROM aim_content WHERE cod_building='"+cod_building+"'", null)[0].num_cont;
					log.info("AIM_CONTENT_TRIGGER:num_cont: "+num_cont);
					
					if(num_cont==0){
						num_cont=1;
						log.info("AIM_CONTENT_TRIGGER:num_cont lungo: "+StringUtils.leftPad(num_cont.toString(), 6, "0"));
						defCodContent = cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00";
						valuesMap.put("cod_content", defCodContent);
						valuesMap.put("num_content",num_cont);
						valuesMap.put("rev_content",0);
						log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00"));
					}else {
						def max_cont = services.queryService.executeQuery("SELECT max(num_content) max_cont FROM aim_content WHERE cod_building='"+cod_building+"'", null)[0].max_cont;
						max_cont=max_cont++;
						log.info("AIM_CONTENT_TRIGGER:max_cont: "+max_cont++);
						defCodContent = cod_building +'-'+ StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00";
						valuesMap.put("cod_content", defCodContent);
						valuesMap.put("num_content",max_cont);
						valuesMap.put("rev_content",0);
						log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(cod_building+'-'+StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00"));
					}
				}			
			
				Integer num_revision = valuesMap.get("num_revision");
				Integer num_content = valuesMap.get("num_content");

				//recupero il vlore appena inserito
				String cod_class_subcat = valuesMap.get("cod_class_subcat");
				
				//SEZIONE PER IL RECUPERO DELLO STATO DEL CONTENUTO
				//CONTROLLO SE CI SONO DELLE TRACK, IN CASO NEGATIVO NON FACCIO CREARE IL CONTENUTO
				def validQuery = false;
				def queryST = null;
			
				
				//COMMENTO LA SELEZIONE TOTALE DELLE TRACK E LA SOSTITUISCO CON QUELLA DA PERMESSI DELL'UTENTE
				//def num_track = services.queryService.executeQuery("SELECT count(id_track) as num_track FROM AIM_TRACK", null)[0].num_track;
				def num_track = services.queryService.executeQuery("SELECT count(1) as num_track FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='"+usergroup+"') or groups in ('AIM_CONTENT_VERIFIER','AIM_BIM')",null)[0].num_track;
				log.info("AIM_CONTENT_TRIGGER:loggo il numero delle track: "+num_track);
				//if(num_track!=null && num_track>0){
				if(num_track!=null && num_track==0){
					throw new RuntimeException("Attenzione: Non ci sono Track compatibili coi permessi dell'utente. <br>Impossibile creare contenuto");
					//throw new RuntimeException("Attenzione: Non ci sono Track. Impossibile creare contenuto");
				}else{
				//CONTROLLO QUALE STATO DEVE ESSERE SALVATO PER IL CONTENUTO
					//recupero le variabili del contenuto che mi servono per il controllo della track
					def arc = valuesMap.get("cod_class_arc");
					def cat = valuesMap.get("cod_class_cat");
					def type = valuesMap.get("cod_class_type");
					//faccio l'elenco delle track presenti ordinandole per priorità
					//COMMENTO LA SELEZIONE TOTALE DELLE TRACK E LA SOSTITUISCO CON QUELLA DA PERMESSI DELL'UTENTE
					//def queryTrack = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+author+"' and groups='"+usergroup+"') or groups='AIM_CONTENT_VERIFIER' order by priority desc",null);
					def queryTrack = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE username='"+author+"' and groups='"+usergroup+"' order by priority desc",null);
					log.info("AIM_CONTENT_TRIGGER:loggo la lista di track ordinate per priorità: "+queryTrack);
					
					if(queryTrack!=null && queryTrack.size()>0){
						def k = 0;
						while(!validQuery && k<queryTrack.size()){
							log.info("AIM_CONTENT_TRIGGER:loggo la track kappesima: "+queryTrack[k]);
							def contType = services.queryService.executeQuery("select * from AIM_BIM_FILTER where cod_bim_filter='"+queryTrack[k].cod_bim_filter+"' and (cod_content_type='"+type+"' or cod_content_type is null)",null)[0];
							log.info("AIM_CONTENT_TRIGGER:loggo  tipo da track massima priorita: "+contType);				
							def contClass = services.queryService.executeQuery("select * from AIM_BIM_FILTER where cod_bim_filter='"+queryTrack[k].cod_bim_filter+"' and (cod_class_filter='"+queryTrack[k].cod_class_filter+"' or cod_class_filter is null)",null)[0];						
							log.info("AIM_CONTENT_TRIGGER:loggo contClass: "+contClass);						

							//vado a mettere la track corretta
							if((contType!=null && contType.size()>0)&&(contClass!=null && contClass.size()>0)){
								def chkTrack = services.queryService.executeQuery("select cod_track,min(ord_track_status) as min_status from AIM_TRACK_STATUS where cod_track='"+queryTrack[k].cod_track+"' group by cod_track",null)[0]; 
								if(chkTrack!=null){
									def cod_status = null;
									def Track = services.queryService.executeQuery("select uk_track_status,cod_status from AIM_TRACK_STATUS where cod_track='"+chkTrack.cod_track+"' and ord_track_status="+chkTrack.min_status,null)[0];
									def Area = 	services.queryService.executeQuery("select area from AIM_TRACK_STATUS_TEMPLATE where cod_status=#{map.cod_status}",[cod_status:Track.cod_status])[0];
									log.info("AIM_CONTENT_TRIGGER:stato prescelto per essere il primo!: "+Track.uk_track_status);
									log.info("AIM_CONTENT_TRIGGER:AREA!: "+Area);
									valuesMap.put("status_approval", Track.uk_track_status);
									valuesMap.put("content_area", Area.area);
									queryST = Track.uk_track_status;
									validQuery = true;
								}else{
									throw new RuntimeException("Attenzione: Non ci sono Stati o Azioni nella Track. <br>Impossibile creare contenuto");	
								}
							}
							k++;
						}
						if(queryST==null){
							throw new RuntimeException("Attenzione: Non sono presenti track valide per la creazione del contenuto.<br>Impossibile creare nuovo contenuto");
						}
					}
				}
			}else{
				throw new RuntimeException("Attenzione: L'utente non dispone dei permessi di creazione di un nuovo contenuto");
			}
		}else if(usergroup.equals("AIM_BIM")){
			//CASO DI POPOLAMENTO MASSIVO DEI CONTENUTI DI TIPO DOCUMENTO/SCH DA PARTE DEL BIM MANAGER		

			//definisco variabili per il controllo delle track e dello stato del contenuto
			def validQuery = false;
			def queryST = null;
			def cod_class_type = valuesMap.get("cod_class_type");
			//controllo se esiste codice immobile
			def queryBUI = services.queryService.executeQuery("select cod_building from GWD_BUILDING where cod_building=#{map.cod_building}",valuesMap);
			if(queryBUI.size()==0 || queryBUI[0].cod_building==null){
				throw new RuntimeException("Attenzione: Codice Immobile inesistente. Impossibile creare contenuto");	
			}
			//controllo se esiste la classificazione	
			def queryCLASS = services.queryService.executeQuery("select * from V_AIM_CLASSIFICATION where cod_class_subcat=#{map.cod_class_subcat}",[cod_class_subcat:valuesMap.content_class]);
			if(queryCLASS==null || queryCLASS.size()==0){
				throw new RuntimeException("Attenzione: Classificazione Inesistente. <br>Impossibile creare contenuto");	
			}
			//POPOLO I CAMPI DELLA CLASSIFICAZIONE
			valuesMap.put("cod_class_arc",queryCLASS[0].cod_class_arc);
			valuesMap.put("cod_class_cat",queryCLASS[0].cod_class_cat);
			valuesMap.put("cod_class_subcat",queryCLASS[0].cod_class_subcat);
			//CALCOLO IL PROGRESSIVO DEL CODICE DEL CONTENUTO (CODICE EDIFICIO + PROGRESSIVO + REVISIONE)
			
			//gestisco la creazione da revisione
			log.info("loggo il valuesMap.from_revision: "+valuesMap.from_revision);
			log.info("loggo il valore della IF: "+valuesMap.from_revision==1);
			if(valuesMap.from_revision==1){
				Integer rev_content = valuesMap.get("rev_content");
				Integer num_content = valuesMap.get("num_content");
				defCodContent = cod_building +'-'+ StringUtils.leftPad(num_content.toString(), 6, "0") + "-"+StringUtils.leftPad(rev_content.toString(), 2, "0");
				log.info("AIM_CONTENT_TRIGGER:controllo i valori che mi arrivano: "+valuesMap);
				log.info("AIM_CONTENT_TRIGGER:sono arrivato a calcolare il codice della nuova revisione: "+defCodContent);
				valuesMap.put("cod_content", defCodContent);
			}else{						
				def num_cont = services.queryService.executeQuery("SELECT count(id_content) as num_cont FROM aim_content WHERE cod_building=#{map.cod_building}",valuesMap)[0].num_cont;
				log.info("AIM_CONTENT_TRIGGER:num_cont: "+num_cont);
				
				if(num_cont==0){
					num_cont=1;
					log.info("AIM_CONTENT_TRIGGER:num_cont lungo: "+StringUtils.leftPad(num_cont.toString(), 6, "0"));
					defCodContent = valuesMap.cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00";
					valuesMap.put("cod_content", defCodContent);
					valuesMap.put("num_content",num_cont);
					valuesMap.put("rev_content",0);
					log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(valuesMap.cod_building +'-'+ StringUtils.leftPad(num_cont.toString(), 6, "0") + "-00"));
				}else {
					def max_cont = services.queryService.executeQuery("SELECT max(num_content) max_cont FROM aim_content WHERE cod_building=#{map.cod_building}",valuesMap)[0].max_cont;
					max_cont=max_cont++;
					log.info("AIM_CONTENT_TRIGGER:max_cont: "+max_cont++);
					defCodContent = valuesMap.cod_building +'-'+ StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00";
					valuesMap.put("cod_content", defCodContent);
					valuesMap.put("num_content",max_cont);
					valuesMap.put("rev_content",0);
					log.info("AIM_CONTENT_TRIGGER:cod_content codifica: "+(valuesMap.cod_building+'-'+StringUtils.leftPad(max_cont.toString(), 6, "0") + "-00"));
				}
			}
			//POPOLO LA DATA DI CREAZIONE
			valuesMap.put("creation_date",new Date());			
		
		
			//associo la track e il codice stato al contenuto
			//CONTROLLO TUTTE LE TRACK

			def queryTRACKBIM = "select cod_track, priority from AIM_TRACK where cod_bim_filter in "+
					"(select cod_bim_filter from AIM_BIM_FILTER where cod_content_type=#{map.cod_class_type} or cod_content_type is null) order by priority desc";
			def exeQueryTRACKBIM = services.queryService.executeQuery(queryTRACKBIM, [cod_class_type: cod_class_type]);
			
			if (exeQueryTRACKBIM!=null && exeQueryTRACKBIM.size()>0){
				def chkTrack = services.queryService.executeQuery("select cod_track,min(ord_track_status) as min_status from AIM_TRACK_STATUS where cod_track='"+exeQueryTRACKBIM[0].cod_track+"' group by cod_track",null)[0]; 				
				if(chkTrack!=null){
					def track = services.queryService.executeQuery("select uk_track_status,cod_status from AIM_TRACK_STATUS where cod_track='"+chkTrack.cod_track+"' and ord_track_status="+chkTrack.min_status,null)[0];
					valuesMap.put("status_approval", track.uk_track_status);
					queryST = track.uk_track_status;
				}else{
					throw new RuntimeException("Attenzione: Non ci sono Stati o Azioni nella Track. <br>Impossibile creare contenuto");	
				}				
			}else{
				throw new RuntimeException("Attenzione: Non ci sono Track associate al contenuto. <br>Impossibile crearlo");	
			}
		}
			
		log.info("AIM_CONTENT_TRIGGER:loggo valuesMap fine inserimento: "+valuesMap);
			
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		log.info("loggo la mappa dei valori in ingresso per l'after insert: "+valuesMap);
		def status_approval = valuesMap.get("status_approval");
		Integer from_revision = valuesMap.get("from_revision");
		def cod_content = valuesMap.get("cod_content");
		def num_content = valuesMap.get("num_content");
		def author = valuesMap.get("author");
		def codClassType = valuesMap.get("cod_class_type");
		def contentDescr = valuesMap.get("descr_content");
		def buildingCode = valuesMap.get("cod_building");
		def cod_class_subcat = valuesMap.get("cod_class_subcat");
		def creationDate = new Date();
		def tenantCode = valuesMap.get("tenant_code");
		def classif = valuesMap.get("content_class");
		
		log.info("AIM_CONTENT_TRIGGER:loggo la mappa di valori aftre insert: "+valuesMap);
		if (classif==null){
			// se il content_class è nullo lo forzo con il valore della sottocategoria (da database)
			def query_upd = services.queryService.executeQuery("UPDATE aim_content set content_class ='" + cod_class_subcat + "' where id_content=" + valuesMap.id,null)[0];
			log.info("query di forzatura: " + query_upd);						
		};

		
		
		//recupero la track e il filtro dallo stato del contenuto
		def queryFil1 = services.queryService.executeQuery("select cod_track from AIM_TRACK_STATUS where uk_track_status='"+status_approval+"'",null)[0];
		def queryFil2 = services.queryService.executeQuery("select cod_bim_filter from AIM_TRACK where cod_track='"+queryFil1.cod_track+"'",null)[0];
		log.info("AIM_CONTENT_TRIGGER:loggo il cod_bim_filter: "+queryFil2.cod_bim_filter);	


		// definisco l'oggetto per l'inserimento: vado ad inserire il contenuto nella lista di quelli visibili (da permesso);
		def classFilterAll = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER WHERE  ((cod_class_filter=#{map.cod_class_arc} or cod_class_filter=#{map.cod_class_cat} or cod_class_filter is null) and  (cod_content_type is null or cod_content_type=#{map.cod_class_type}))",valuesMap);
		//ciclo il risultato
		for(int q=0;q<classFilterAll.size();q++){
			classFilterAll[q].cod_content=valuesMap.cod_content;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def ContIns = "INSERT INTO AIM_BIM_FILTER_R_CONTENT (cod_bim_filter, cod_content)";
			ContIns+=" VALUES ";
			ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
			def ins_cont = services.queryService.executeQuery(ContIns,classFilterAll[q]);		
		}
		
	
		// TRIGGER CHE POPOLA LA CLASSE DI RELAZIONE DATA LA FORMA DEL CONTENUTO
		def contentTypeHM = [:];
		contentTypeHM.cod_content = cod_content;
		contentTypeHM.tenant_code = tenantCode;
		if(codClassType.equals('DOC')){
			contentTypeHM.file_path = buildingCode + "/" + "DOC/" + cod_content;
			def insertDoc = "INSERT INTO AIM_CONTENT_DOC (cod_content, file_path, tenant_code) VALUES (#{map.cod_content},#{map.file_path},#{map.tenant_code})";
			def ins = services.queryService.executeQuery(insertDoc,contentTypeHM);	
		}else if(codClassType.equals('SCH')){
			//creo record su sch e controllo se c'è il legame con documento digitale generato da connettore
			def className = valuesMap.get("class_name");
			Class gwClass = services.gwm_classService.selectByClassName(new Class(className));
			contentTypeHM.fk_sch_class = gwClass.getGwid();
			log.info("loggo classe contenuto digitale: "+className);
			def schClassesResult = services.queryService.executeQuery("select configuration_type from aim_bim_sch_conf where class_name=#{map.class_name}", [class_name: className])[0];
 		    if(schClassesResult.configuration_type==2){
				def isDigDocExist = services.queryService.executeQuery("select count(1) as is_exist, upload_date from "+className+" where cod_building=#{map.cod_building} group by upload_date", [cod_building: buildingCode]);
                 log.info("loggo risulatato query isDigDocExist "+isDigDocExist);		 
				 if(isDigDocExist.size()>0 && isDigDocExist[0].is_exist>0){
                    log.info("digital document exist for sch "+className);
					def map = [cod_building: buildingCode, cod_content: cod_content];
                    services.queryService.executeQuery("update "+className+" set cod_content=#{map.cod_content} where cod_building=#{map.cod_building}", map);
                    services.queryService.executeQuery("update aim_content set is_uploaded=1 where cod_content=#{map.cod_content}",map);
                	contentTypeHM.creation_date = isDigDocExist[0].upload_date;
					def insertSch = "INSERT INTO AIM_CONTENT_SCH (cod_content, fk_sch_class, sch_code_column, sch_code, sch_layout, creation_date, tenant_code) "+
					" VALUES (#{map.cod_content},#{map.fk_sch_class},'cod_content', #{map.cod_content}, 'default_sch', #{map.creation_date}, #{map.tenant_code})";
					def ins = services.queryService.executeQuery(insertSch,contentTypeHM);	
				} else {
					def insertSch = "INSERT INTO AIM_CONTENT_SCH (cod_content, fk_sch_class, tenant_code) VALUES (#{map.cod_content},#{map.fk_sch_class},#{map.tenant_code})";
					def ins = services.queryService.executeQuery(insertSch,contentTypeHM);	
				}
            } else {
				def insertSch = "INSERT INTO AIM_CONTENT_SCH (cod_content, fk_sch_class, tenant_code) VALUES (#{map.cod_content},#{map.fk_sch_class},#{map.tenant_code})";
				def ins = services.queryService.executeQuery(insertSch,contentTypeHM);	
			}

		} else if (codClassType.equals('BIM')){

			contentTypeHM.bim_data_project = cod_content;
			contentTypeHM.author = author;
			contentTypeHM.creation_date = creationDate;
			def insertBIM = "INSERT INTO AIM_CONTENT_BIM (cod_content, bim_data_project, tenant_code, author, creation_date) VALUES (#{map.cod_content}, #{map.bim_data_project}, #{map.tenant_code}, #{map.author}, #{map.creation_date})";
			def ins = services.queryService.executeQuery(insertBIM,contentTypeHM);
			//calcolo il codice contenuto senza la revisione
			def cod_content_short = buildingCode +'-'+ StringUtils.leftPad(num_content.toString(), 6, "0");
			//se non viene da revisione popolo il record sulla gwd_bim_project altrimenti lo ignoro
			if(from_revision==null){
				def bimProject = [:];
				bimProject.project_code = cod_content_short;
				bimProject.project_description = contentDescr;
				bimProject.cod_building = buildingCode;
				bimProject.tenant_code = tenantCode;
				services.classService.insertClassRecord('gwd_bim_project',bimProject);
				//creo il layout per i modelli 3D, esiste un solo layout per tutte le revisioni di un contenuto (compreso il contenuto stesso)
				def layout = [:];
				layout.layout_code = cod_content_short;
				layout.layout_label = contentDescr;
				layout.layout_type = '3D';
				layout.tenant_code = tenantCode;
				services.classService.insertClassRecord('gwd_layout',layout);
				
				def modelSet = [:];
				modelSet.model_set_code = cod_content+'_FEDMOD';
				modelSet.model_set_label = "Default Model Set per "+cod_content;
				modelSet.layout_code = cod_content_short;
				modelSet.is_default = 1;
				modelSet.gwm_scene_name = "bimData";
				services.classService.insertClassRecord('gwd_model_set',modelSet);
																																  
			} else {
				//caso nuova revisione: il modello federato che era attivo viene disattivato
				services.queryService.executeQuery("update gwd_fed_model set is_active=0 where cod_project=#{map.cod_project} and is_active=1", [cod_project: cod_content_short]);
			}
			//ogni volta che viene creato un contenuto di tipo bim model deve essere creato un modello federato attivo
			def fedModel = [:];
			fedModel.cod_fed_model = cod_content+'_FEDMOD';
			fedModel.name_fed_model = 'Modello federato per '+cod_content;
			fedModel.cod_project = cod_content_short;
			fedModel.fk_object = cod_content;
			fedModel.is_active = 1;
			fedModel.tenant_code = tenantCode;
			services.classService.insertClassRecord('gwd_fed_model',fedModel);
			
		} else if(codClassType.equals('V2D')){
			contentTypeHM.author = author;
			contentTypeHM.creation_date = creationDate;
			contentTypeHM.file_path = buildingCode + "/V2D/" + cod_content;
			def insertV2D = "INSERT INTO AIM_CONTENT_V2D (cod_content, tenant_code, author, creation_date, file_path) VALUES (#{map.cod_content}, #{map.tenant_code}, #{map.author}, #{map.creation_date}, #{map.file_path})";
			def ins = services.queryService.executeQuery(insertV2D, contentTypeHM);
			
			def layout = [:];
			layout.layout_code = cod_content;
			layout.layout_label = contentDescr;
			layout.layout_type = '2D';
			layout.tenant_code = tenantCode;
			layout.template_code = "v2d_template";
			layout.cod_layout_folder = buildingCode;
			services.classService.insertClassRecord('gwd_layout',layout);
		} else if (codClassType.equals('GAL')){
			contentTypeHM.author = author;
			contentTypeHM.creation_date = creationDate;
			contentTypeHM.file_path = buildingCode + "/GAL/" + cod_content;
			def insertGAL = "INSERT INTO AIM_CONTENT_GAL (cod_content, tenant_code, file_path) VALUES (#{map.cod_content}, #{map.tenant_code}, #{map.file_path})";
			def ins = services.queryService.executeQuery(insertGAL, contentTypeHM);
			
		}
		
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		//predispongo i controlli nel caso di modifica della classificazione del contenuto
		def content_class = valuesMap.content_class;
		def cod_class_type = oldvaluesMap.cod_class_type;
		log.info("loggo la mappa dei valori modificati: "+valuesMap);
		log.info("loggo la mappa dei valori immutati: "+oldvaluesMap);
		if(content_class!=null){
			if(cod_class_type!='SCH'){			
				//recupero le variabili in sessione	dal groovy di seguito:
				SessionObject sessionObject = services.gse.runScript("getSessionObject.groovy");
				log.info("loggo il sessionObject: "+sessionObject);
				if(sessionObject!=null){
					//recupero le variabili per la gestione della modifica della classificazione
					String user = sessionObject.getUser();
					log.info("loggo l'utente in sessione: "+user);				
				//recupero archivio e categoria dalla nuova classificazione scelta
					def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",[content_class:valuesMap.content_class])[0]; 
					log.info("loggo la mappa della classificazione modificata: "+queryCodClass);
				//controllo se la classificazione scelta rientra nei filtri impostati per l'utente
					def queryClassPerm = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER_USER WHERE (username='"+user+"' and groups='AIM_CONTENT_OWNER') and (cod_class_filter is null or cod_class_filter='"+queryCodClass.cod_class_arc+"' or cod_class_filter='"+queryCodClass.cod_class_cat+"')", null);		
					log.info("loggo la mappa dei permessi della classificazione modificata: "+queryClassPerm);
					if(queryClassPerm==null || queryClassPerm.size()==0){
						throw new RuntimeException("Attenzione: L'utente non dispone dei permessi necessari<br> per la classificazione selezionata. <br>Impossibile modificare il contenuto");					
					}else{
						valuesMap.put("cod_class_arc",queryCodClass.cod_class_arc);
						valuesMap.put("cod_class_cat",queryCodClass.cod_class_cat);	
						valuesMap.put("cod_class_subcat",queryCodClass.cod_class_subcat);				
					}
				}
			}else{
				throw new RuntimeException("Attenzione: La forma del contenuto non consente di modificare<br> la classificazione.<br>La modifica riguarda i soli contenuti di forma <br>DOCUMENTO o MODELLO BIM");									
			}			
		}					
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	//recupero in caso di modifica della classificazione i parametri per rimappare la tabella materializzata dei permessi per contenuto
	def content_class = valuesMap.content_class;
	if (content_class!=null){
		//recupero archivio e categoria dalla nuova classificazione scelta
		def queryCodClass = services.queryService.executeQuery("SELECT cod_class_subcat, cod_class_cat,cod_class_arc FROM V_AIM_CLASSIFICATION WHERE cod_class=#{map.content_class}",valuesMap)[0]; 	
		// controllo in quanti filtri ricade la nuova classificazione;
		def classFilterAll = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER WHERE  ((cod_class_filter=#{map.cod_class_arc} or cod_class_filter=#{map.cod_class_cat} or cod_class_filter is null) and  (cod_content_type is null or cod_content_type=#{map.cod_class_type}))",[cod_class_type:oldvaluesMap.cod_class_type,cod_class_arc:queryCodClass.cod_class_arc,cod_class_cat:queryCodClass.cod_class_cat]);
		log.info("loggo la mappa dei filtri possibili: "+classFilterAll);
		def delContOld = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_content=#{map.cod_content}",oldvaluesMap);		
		//ciclo il risultato
		for(int q=0;q<classFilterAll.size();q++){
			classFilterAll[q].cod_content=oldvaluesMap.cod_content;	
			//predispongo l'inserimento dei record nella tabella CDE_DELIVEARBLE_REVISON
			def ContIns = "INSERT INTO AIM_BIM_FILTER_R_CONTENT (cod_bim_filter, cod_content)";
			ContIns+=" VALUES ";
			ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
			def ins_cont = services.queryService.executeQuery(ContIns,classFilterAll[q]);		
		}			
	} 
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	
		def pcCont = valuesMap.id_content;
		def selectCode = "SELECT cod_content FROM aim_content where id_content="+pcCont;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukCont = result.cod_content;

		//eliminazione dati BIM DATA su trigger aim_content_bim

		//gestisco l'eliminazione delle classi  
		def delInfo = services.queryService.executeDeleteQuery("DELETE FROM AIM_CONTENT_HISTORY WHERE cod_content='"+ukCont+"'",null);
		def delSchTer = services.queryService.executeDeleteQuery("DELETE FROM AIM_SCH_CONS_TERRAIN WHERE cod_content='"+ukCont+"'",null);
		def delSchBui = services.queryService.executeDeleteQuery("DELETE FROM AIM_SCH_CONSISTENCY WHERE cod_content='"+ukCont+"'",null);
		def UpdSchPerm = services.queryService.executeUpdateQuery("UPDATE AIM_SCH_PERMISSION_BUILD set cod_content=null WHERE cod_content='"+ukCont+"'",null);
		def UpdSchSpa = services.queryService.executeUpdateQuery("UPDATE AIM_SCH_SPACE set cod_content=null WHERE cod_content='"+ukCont+"'",null);
		def UpdSchDocfa = services.queryService.executeUpdateQuery("UPDATE AIM_SCH_CONS_UI set cod_content=null WHERE cod_content='"+ukCont+"'",null);
		def delPermCont = services.queryService.executeDeleteQuery("DELETE FROM AIM_BIM_FILTER_R_CONTENT WHERE cod_content='"+ukCont+"'",null);
	
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 