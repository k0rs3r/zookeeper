//user:    APA
//date:    22/10/2019
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_system_type_r_model_type
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		log info("loggo la mappa in ingresso before Insert: "+valuesMap);
		
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();
		valuesMapAll.putAll(oldvaluesMap);
		valuesMapAll.putAll(valuesMap);
		log.info("loggo la mappa in ingresso valuesMap: "+valuesMap);
		log.info("loggo la mappa in ingresso oldvaluesMap: "+oldvaluesMap);
		log.info("loggo la mappa in ingresso valuesMapAll: "+valuesMapAll);
		//recupero le variabili in ingresso per l'UPDATE
		def cod_system_type = valuesMapAll.cod_system_type;
		def bim_model_type = valuesMapAll.bim_model_type;
		def drawing_type = valuesMapAll.drawing_type;
		//conto se il record è già presente		
		def countQuery = services.queryService.executeQuery("SELECT pk_bim_system FROM gwd_bim_system WHERE cod_system_type='"+cod_system_type+"'", null)[0]; 
		//se non è presente procedo all'inserimento
		if(countQuery==null || countQuery.size()==0){
			log.info("è vuoto");
			def ins_bim_sys = [:];
			ins_bim_sys.cod_system_type = cod_system_type;
			ins_bim_sys.drawing_type = drawing_type;
			ins_bim_sys.bim_model_type = bim_model_type;			
			def contRsys = "INSERT INTO gwd_bim_system (cod_system_type,drawing_type,bim_model_type)";
			contRsys+=" VALUES ";
			contRsys+="(#{map.cod_system_type},#{map.drawing_type},#{map.bim_model_type})";
			def insert = services.queryService.executeQuery(contRsys,ins_bim_sys);
		}
		//se è presente procedo all'update in ogni caso
		if(countQuery!=null && countQuery.size()>0){
			log.info("è pieno");
			def query_updDraw = services.queryService.executeQuery("UPDATE gwd_bim_system set drawing_type='"+drawing_type+"' WHERE cod_system_type='"+cod_system_type+"'",null);
			def query_updBim = services.queryService.executeQuery("UPDATE gwd_bim_system set bim_model_type='"+bim_model_type+"' WHERE cod_system_type='"+cod_system_type+"'",null);							
		}

		
		return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	    return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 