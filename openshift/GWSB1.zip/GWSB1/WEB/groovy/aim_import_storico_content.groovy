import com.geowebframework.dataservice.model.GwHeaderClassInfo;
import org.apache.commons.lang.StringUtils;
import com.geowebframework.dataservice.service.GwImportUtilService;
import com.geowebframework.dataservice.service.GwClassListService;
import java.lang.RuntimeException;
import org.apache.commons.lang.StringUtils;
import com.geowebframework.dataservice.ConfigurationProperties;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.FileNameMap;
import java.net.URLConnection;
import com.geowebframework.dataservice.ConfigurationProperties;
import java.util.zip.ZipInputStream;
import java.io.File;

import org.apache.commons.io.IOUtils;

public class ImportHandlerExt extends com.geowebframework.dataservice.service.ImportHandler  {
	
	public HashMap<String, Object> importResponse;
	public Integer contatore=null;
	public boolean beforeImport(){
		
				
		return true;
	};
	
	/**
	 * Function for crud operations of class data in file row
	 *
	 *
	 * @param  headerClasses 		(required) 	Processed header classes by {@link #handleClassHeaders(String[], String, String, String)}
	 * @param  row 					(required)  row 
	 * @param  mainClassName 		(required) 	Main class name
	 * @param  mainRecordParent 	(optional) 	Parent record of main class, null if optional
	 * @param  mainAdditionalMap 	(optional) 	Additional info for main class, null if optional
	 * @param  importType 			(required)  Information concerning main class crud operations
	 * @param  locale 				(optional)	locale
	 * @param  codColumnsSplitted 	(optional)	Column codes for selectClassRecordByCodeList filters
	 * @param  projectName 			(required)  Project Name
	 * @return      a List<String> representing keys of created/updated data
	 *
	 */
	public boolean handle(
			HashMap<String, GwHeaderClassInfo> headerClasses, 
			Map<String, String> row,  //riga csv
			String mainClassName,
			HashMap<String, Object> mainRecordParent,
			HashMap<String, Object> mainAdditionalMap,
			Integer importType,
			Locale locale,
			String[] codColumnsSplitted,
			String projectName
		) throws Exception {
			def itemId=null;
			def idContent=null;
			/*try{*/
			def content_class=row.content_class;
			log.debug("descr Sottocategoria:"+content_class);
			log.debug("descrNome Contenuto:"+row.descr_content);
			log.debug("COD BUILDING:"+row.cod_building);
			row.cod_class_type="DOC";
			if(row.cod_building==null){
				log.debug("Attenzione letto codice immobile nullo");
				throw new RuntimeException("Attenzione letto codice immobile nullo");
			}
			log.debug("Recupero la sottocategoria");
			HashMap<String, Object> objRecordSubcategory = services.classService.selectClassRecordByCode("aim_class_subcategory", content_class, "name_class_subcat");
			if(objRecordSubcategory==null || !objRecordSubcategory.cod_class_subcat){
				
				objRecordSubcategory = services.classService.selectClassRecordByCode("aim_class_subcategory", content_class, "cod_class_subcat");
			}
			if(objRecordSubcategory!=null && objRecordSubcategory.cod_class_subcat){
				log.debug("Sottocategoria Recuperata"+objRecordSubcategory.cod_class_subcat);
				def pathFile=row.percorso_file;
				log.debug("PATH FILE DA CARICARE "+pathFile);
				
					
					
				//RECUPERO LO ZIP DA DENTRO LA TABELLA
				def className="aim_content_zip";
				def attributeColumnName="name_file_zip";
				log.debug("RIGA CARICATA"+row);
				HashMap<String, Object> zipRec=services.classService.selectClassRecord("aim_content_zip", mainAdditionalMap.itemId);
				log.debug("Leggo il file corrente dentro lo zip "+(zipRec!=null?"ok":"ko"));
				
				log.debug("Recupero l attributo");
				HashMap<String,Object> documentMap = services.gwDocumentDataService.getDocumentMapByItemIdAndAttributeColumnName(className,mainAdditionalMap.itemId,attributeColumnName);
				documentMap.data = IOUtils.toByteArray(documentMap.is);
				InputStream  inputStream=new ByteArrayInputStream(documentMap.data);
				def zipfile=new ZipInputStream(inputStream);
				
				log.debug("Recupero il file da mettere sul gestore documentale");
				//RECUPERO IL FILE DA METTERE SU ALFRESCO
				def MscGenericFunction = services.gse.getInstanceByScriptName("cdeaim_GenericFunction.groovy");
				MscGenericFunction.init(services);
				HashMap<String,Object> infoFileCaricare=MscGenericFunction.getGenericFileIntoZip(zipfile,pathFile);
				//log.debug("BYTEARRAYFILECARICARE"+infoFileCaricare.is);
				log.debug("LENGTHFILECARICARE"+infoFileCaricare.length);
				log.debug("NAMEFILECARICARE"+infoFileCaricare.nameFile);
				log.debug("MIMETYPEFILECARICARE"+infoFileCaricare.mimeType);
				//InputStream input = new ByteArrayInputStream(byteArrayFileDaCaricare);
				def cod_class_subcat=objRecordSubcategory.cod_class_subcat;
				
				
				if(infoFileCaricare.is!=null && infoFileCaricare.is!=null){
					log.debug("file trovato");
					String filename = infoFileCaricare.nameFile;
					log.debug("nome file trovato:"+filename);
					//VERIFICO CHE IL FILE NON SIA DA VERSIONARE
					def updateRec=false;
					log.debug("verifico se ci sono i dati nella tabella AIM_CONTENT per il path del gestore documentale :");
					def resultDocImmobile=services.queryService.executeQuery("SELECT COUNT(*) contDoc FROM AIM_CONTENT CONT LEFT JOIN  AIM_CONTENT_DOC DOC ON DOC.cod_content=CONT.cod_content WHERE DESCR_CONTENT=#{map.descr_content} and FILE_NAME=#{map.file_name} and cod_building=#{map.cod_building} and CONT.cod_class_subcat=#{map.cod_class_subcat} and id_doc is not null",[descr_content:row.descr_content,file_name:filename,cod_building:row.cod_building,cod_class_subcat:cod_class_subcat]);
					
					if(resultDocImmobile!=null && resultDocImmobile[0]!=null && resultDocImmobile[0].contDoc>0){
						log.debug("dati trovati");
						log.debug("recupero i dati");
						//RECUPERO GIA IL RECORD PRESENTE SU AIM_CONTENT PER LO STESSO FILE E SOTTOCATEGORIA ALFRESCO SI PREOCCUPERA DI VERSIONARE
						def getItemIdImmobile=services.queryService.executeQuery("SELECT CONT.id_content,CONT.cod_content  FROM AIM_CONTENT CONT LEFT JOIN  AIM_CONTENT_DOC DOC ON DOC.cod_content=CONT.cod_content WHERE DESCR_CONTENT=#{map.descr_content} and FILE_NAME=#{map.file_name} and cod_building=#{map.cod_building} and CONT.cod_class_subcat=#{map.cod_class_subcat} and id_doc is not null",[descr_content:row.descr_content,file_name:filename,cod_building:row.cod_building,cod_class_subcat:cod_class_subcat]);
						log.debug("dati trovati");
						idContent=Integer.toString(getItemIdImmobile[0].id_content);
						log.debug("idContent"+idContent);
						//AGGIORNO AIM_CONTENT CON LA NUOVA DATA DI CARICAMENTO
						log.debug("AGGIORNO AIM_CONTENT CON LA NUOVA DATA DI CARICAMENTO");
						def resUpd=services.queryService.executeQuery("UPDATE AIM_CONTENT SET UPLOAD_DATE=CURRENT_TIMESTAMP WHERE ID_CONTENT="+getItemIdImmobile[0].id_content,null);
						updateRec=true;
						log.debug("AGGIORNATO IL CONTENUTO CORRETTAMENTE:"+getItemIdImmobile[0].cod_content+" CHIAVE:"+idContent);
						((GwImportUtilService) services.get("gwImportUtilService")).fileImportUpdateCount++;
					}else{
							
						//INSERISCO SU AIM_CONTENT
						row.put("content_class",cod_class_subcat);
						row.put("classificazione_contenuto",cod_class_subcat);
						log.debug("INSERISCO SU AIM_CONTENT");
						itemId=((GwImportUtilService) services.get("gwImportUtilService")).doHeaderClassesCrudOperations(
						headerClasses, 
						row,
						mainClassName,
						mainRecordParent,
						mainAdditionalMap,
						importType,
						locale,
						codColumnsSplitted,
						projectName);
						idContent=itemId[0];
						log.debug("INSERITO IL CONTENUTO CORRETTAMENTE ID_RECORD "+itemId);
					}
				
					if(idContent!=null){
							log.debug("RECUPERO IL RECORD INSERITO ");
							HashMap<String, Object> recordContent=services.classService.selectClassRecord("aim_content", idContent);
							
							
							log.debug("COD_CONTENT: "+recordContent.cod_content);
							log.debug("RECUPERO I DATI SU AIM_CONTENT_DOC ");
							def result=services.queryService.executeQuery("SELECT FILE_PATH,ID_DOC FROM AIM_CONTENT_DOC WHERE COD_CONTENT=#{map.cod_content}",[cod_content:recordContent.cod_content]);
							if(result!=null && result[0]!=null && result[0].file_path!=null){
								log.debug("DATI TROVATI SU AIM_CONTENT_DOC");
								
								String cmisBasePath = ConfigurationProperties.getInstance().getProperty("cmisBasePath");
								log.debug("cmisBasePath RECUPERATO "+cmisBasePath);
								//commento il vecchio percorso del file documento
								//def filePath = result[0].file_path.trim();
								//aggiungo la cartella AIM per la costruzione del percorso del file path
								def filePath = "AIM/"+result[0].file_path.trim();
								
								
								def completePath = cmisBasePath.trim();
								if(!completePath.endsWith("/") && !cmisBasePath.equals("/")) completePath += "/";
								completePath += filePath.trim().startsWith("/") ? filePath.trim().subString(1) : filePath;
								
								//if (services.gwCmisService.getFolderByPath(completePath)==null){
								if (services.gwCmisService.getFolderByPath("/"+filePath)==null){
									log.debug("CREO CARTELLA SUL GESTORE DOCUMENTALE"+filePath);
									
									if(cmisBasePath.trim().endsWith("/") && !cmisBasePath.equals("/")) cmisBasePath = cmisBasePath.trim().substring(0, cmisBasePath.lastIndexOf("/"));
									
									filePath = filePath.startsWith("/") ? filePath : "/"+filePath;
									
									def Folder=services.gwCmisService.createFoldersByCompletePath(cmisBasePath, filePath);
									if(Folder!=null)log.debug("CARTELLA CREATA CORRETTAMENTE");
								}
									
								Long lenght = infoFileCaricare.length;
								InputStream input = infoFileCaricare.is;
								String mimetype = infoFileCaricare.mimeType;
								log.debug("PREPARO I DATI DOC PER IL CARICAMENTO "+filename+mimetype+lenght);
									
								try{
										log.debug("LANCIO ISTRUZIONE PER CREARE IL DOC SUL GESTORE DOCUMENTALE");
										def DocumentAlfresco=services.gwCmisService.createDocument(completePath, filename, filename, input, lenght, mimetype);
										if(DocumentAlfresco!=null){
										log.debug("DOCUMENTO CREATO CORRETTAMENTE");
											//aggiorno aim_content e aim_content_doc
											log.debug("DOCUMENTO CREATA CORRETTAMENTE");
											def mapUpd=[:];
											mapUpd.id_content=Integer.valueOf(idContent);
											mapUpd.is_uploaded=1;
											mapUpd.upload_date=new Date();
											log.debug("AGGIORNO IL RECORD SU AIM_CONTENT");
											services.classService.updateClassRecord("aim_content",mapUpd);
											log.debug("CONTENUTO AGGIORNATO CORRETTAMENTE");
											
											def mapUpdDoc=[:];
											mapUpdDoc.id_doc=result[0].id_doc;
											if(updateRec){
												mapUpdDoc.modification_date=new Date();
											}else{
												mapUpdDoc.creation_date=new Date();
											}
											mapUpdDoc.author=recordContent.author;
											mapUpdDoc.file_name=filename;
											log.debug("AGGIORNO IL RECORD SU aim_content_doc");
											services.classService.updateClassRecord("aim_content_doc",mapUpdDoc);
											log.debug("DOC CONTENUTO AGGIORNATO CORRETTAMENTE");
										}else{
											((GwImportUtilService) services.get("gwImportUtilService")).fileImportInsertCount--;
											log.debug("ECCEZIONE GESTORE DOCUMENTALE");
											try{
												log.debug("CALCELLO IL RECORD SU AIM CONTENT");
												services.classService.deleteClassRecord("aim_content",idContent);
												def resultDelAimContent=services.queryService.executeQuery("delete FROM AIM_CONTENT_DOC WHERE COD_CONTENT=#{map.cod_content}",[cod_content:recordContent.cod_content]);
											}catch(Exception ex){
												log.error(ex.getMessage(),ex);
											}
											throw new RuntimeException("Non è stato possibile caricare il contenuto!");
										}
									}catch(Exception e){
										((GwImportUtilService) services.get("gwImportUtilService")).fileImportInsertCount--;
										log.error(e.getMessage(),e);
										log.debug("ECCEZIONE CARICAMENTO DOCUMENTO"+e.getMessage());
										try{
											log.debug("CALCELLO IL RECORD SU AIM CONTENT");
											services.classService.deleteClassRecord("aim_content",idContent);
											def resultDelAimContent=services.queryService.executeQuery("delete FROM AIM_CONTENT_DOC WHERE COD_CONTENT=#{map.cod_content}",[cod_content:recordContent.cod_content]);
										}catch(Exception ex){
											log.error(ex.getMessage(),ex);
										}
										throw new RuntimeException("Non è stato possibile caricare il contenuto!");
									}
							
							}
						}
					
					
					
						
						
					
				}else{
					log.debug("Non esiste il file al path indicato nello zip");
					throw new RuntimeException("Non esiste il file al path indicato nello zip");
				}
				
				return (idContent!=null);
				
			}else{
				def messageErr="Sottocategoria non Presente!";
				throw new RuntimeException(messageErr);
				return false;
			}
		/*}catch(Exception e){
			log.error(e.getMessage(),e);
			throw new RuntimeException(e.getMessage());
		}*/	
			
			
			
			//List<String> keyList = new ArrayList<String>();
			//return keyList;
			/*}catch(Exception e){
				log.error(e.getMessage(),e);
				((GwImportUtilService) services.get("gwImportUtilService")).fileImportInsertCount--;
				def messageErr=e.getMessage();
				//throw new RuntimeException(messageErr!=null?messageErr:"Attenzione controllare il file di log");
				return false;
			}*/
		}
	
	public boolean afterImport(HashMap<String, Object> additionalMap){
		importResponse=additionalMap.get("response");
		/*importResponse.get("headers")[0].put("width","auto");
		importResponse.get("headers")[1].put("width","auto");
		importResponse.get("headers")[2].put("width","auto");
		importResponse.get("headers")[3].put("width","auto");*/
		log.debug("ERRORI TROVATI:"+importResponse.rowsWithErrors);
		//CANCELLO I DATI NELLA TABELLA DI APPOGGIO
	    def record_conta_obj =services.queryService.executeQuery("DELETE FROM AIM_CONTENT_ZIP",null);
		return true;
	};
	
}