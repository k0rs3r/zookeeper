//user:    APA
//date:    22/10/2019
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_system_type
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
	//recupero variabile del codice
	def cod_system_type = valuesMap.cod_system_type;
	def num_sys_type = services.queryService.executeQuery("SELECT pk_system_type_r_model_type FROM gwd_system_type_r_model_type WHERE cod_system_type='"+cod_system_type+"'", null); 
	if(num_sys_type!=null && num_sys_type.size()>0){	
		throw new RuntimeException("record già presente");	
	}else{	
		def ins_rsys = [:];
		ins_rsys.cod_system_type = cod_system_type;							
		def contRsys = "INSERT INTO gwd_system_type_r_model_type (cod_system_type)";
		contRsys+=" VALUES ";
		contRsys+="(#{map.cod_system_type})";
		def insert = services.queryService.executeQuery(contRsys,ins_rsys);	
	}		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
		return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
	def pkSys = valuesMap.id_system_type;
	def selectCode = "SELECT cod_system_type FROM gwd_system_type where id_system_type="+pkSys;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukSys = result.cod_system_type;
	def delrSys = services.queryService.executeDeleteQuery("DELETE FROM gwd_system_type_r_model_type WHERE cod_system_type='"+ukSys+"'",null);
	def delrBimSys = services.queryService.executeDeleteQuery("DELETE FROM gwd_bim_system WHERE cod_system_type='"+ukSys+"'",null);		
	    return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 