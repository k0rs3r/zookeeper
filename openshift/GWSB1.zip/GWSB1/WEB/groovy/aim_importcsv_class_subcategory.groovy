import com.geowebframework.dataservice.model.GwHeaderClassInfo;
import org.apache.commons.lang.StringUtils;
import com.geowebframework.dataservice.service.GwImportUtilService;
import com.geowebframework.dataservice.service.GwClassListService;
import java.lang.RuntimeException;
import org.apache.commons.lang.StringUtils;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImportHandlerExt extends com.geowebframework.dataservice.service.ImportHandler  {
	
	
	public boolean beforeImport(){
		
				
		return true;
	};
	
	/**
	 * Function for crud operations of class data in file row
	 *
	 *
	 * @param  headerClasses 		(required) 	Processed header classes by {@link #handleClassHeaders(String[], String, String, String)}
	 * @param  row 					(required)  row 
	 * @param  mainClassName 		(required) 	Main class name
	 * @param  mainRecordParent 	(optional) 	Parent record of main class, null if optional
	 * @param  mainAdditionalMap 	(optional) 	Additional info for main class, null if optional
	 * @param  importType 			(required)  Information concerning main class crud operations
	 * @param  locale 				(optional)	locale
	 * @param  codColumnsSplitted 	(optional)	Column codes for selectClassRecordByCodeList filters
	 * @param  projectName 			(required)  Project Name
	 * @return      a List<String> representing keys of created/updated data
	 *
	 */
	public boolean handle(
			HashMap<String, GwHeaderClassInfo> headerClasses, 
			Map<String, String> row,  //riga csv
			String mainClassName,
			HashMap<String, Object> mainRecordParent,
			HashMap<String, Object> mainAdditionalMap,
			Integer importType,
			Locale locale,
			String[] codColumnsSplitted,
			String projectName
		) throws Exception {
			
			
			
			log.info("<BR>\n row caricate"+row);
			log.info("ARCHIVIO:"+row.cod_class_arc);
			log.info("CATEGORIA:"+row.cod_class_cat);
			log.info("SOTTOCATEGORIA:"+row.cod_class_subcat);
			
			
			// VERIFICO ESISTENZA ARCHIVIO
			// recupero il codice archivio dal nome archivio presente nel file CSV
			HashMap<String, Object> objRecordArchivio = services.classService.selectClassRecordByCode("aim_class_archive", row.cod_class_arc, "name_class_arc");;
			// istanzio la variabile del codice archivio
			def cod_class_arc=null;
			// se esiste un codice archivio per il nome presente nel file CSV
			if(objRecordArchivio!=null && objRecordArchivio.cod_class_arc){
				// assegno alla variabile del codice archivio il valore recuperato in base al nome
				cod_class_arc=objRecordArchivio.cod_class_arc;
			}else{
				// se non esiste un codice archivio per il nome presente nel file CSV visualizzo un messaggio di alert
				def messageErr="L\'archivio " + row.cod_class_arc + " e\' inesistente.";
				throw new RuntimeException(messageErr);
				return false;
				};
			
			
			// VERIFICO ESISTENZA DELLA CATEGORIA, SE ESISTE VADO AVANTI CON LA SOTTOCATEGORIA, SE NON ESISTE INSERISCO LA CATEGORIA
			// recupero se esiste il codice della categoria, in base a codice archivio e nome categoria	
			HashMap<String, Object> objRecordCategory =services.queryService.executeQuery("select * from aim_class_category where name_class_cat=#{map.name_class_cat} and cod_class_arc=#{map.cod_class_arc}",[name_class_cat:row.cod_class_cat,cod_class_arc:cod_class_arc]);
			// istanzio la variabile del codice e del progressivo della categoria
			def cod_class_cat=null;
			def prog = null;
			// se il codice categoria esiste, allora assegno alla variabile il codice esistente
			if(objRecordCategory!=null && objRecordCategory.cod_class_cat){
				cod_class_cat=objRecordCategory.cod_class_cat;
			// se il codice della categoria non esiste, recupero il massimo valore del progressivo della categoria per archivio
			}else{
				// conto i numero di categorie per archivio
				def queryCountCateg = "SELECT COUNT(1) as num_rec FROM aim_class_category WHERE cod_class_arc=#{map.cod_class_arc}";
				def CountCateg = services.queryService.executeQuery(queryCountCateg,[cod_class_arc:cod_class_arc])[0].num_rec;
				log.info("numero di categorie per archivio : " + CountCateg);
				// se il conteggio è pari a zero, assegno al progressivo il valore 1
				if (CountCateg==0){prog = 1}
				// se il conteggio è maggiore di zero, assegno al progressivo il valore max prog + 1
				else if (CountCateg>0){
					def queryMaxCateg = "SELECT MAX (prog_cat) as max_prog FROM aim_class_category WHERE cod_class_arc=#{map.cod_class_arc}";
					def MaxCateg = services.queryService.executeQuery(queryMaxCateg,[cod_class_arc:cod_class_arc])[0].max_prog;
					log.info("valore massimo del progressivo di categoria per archivio: " + MaxCateg);
					prog = MaxCateg + 1;
					};
				log.info("valore da assegnare al progressivo della categoria: " + StringUtils.leftPad(prog.toString(),2,"0"));
				// calcolo il codice della categoria
				def cod_class_cat_calc = cod_class_arc + "." + StringUtils.leftPad(prog.toString(),2,"0");
				log.info("codice della categoria: " + cod_class_cat_calc);
				// definisco oggetto per inserimento
				def insertMapCat=[:];
				insertMapCat.name_class_cat=row.cod_class_cat;
				insertMapCat.cod_class_arc=cod_class_arc;
				insertMapCat.cod_class_cat=cod_class_cat_calc;
				insertMapCat.prog_cat = prog;
				log.info("mappa di inserimento categoria "+insertMapCat);	
				// inserisco della classe delle categorie
				def itemId=services.classService.insertClassRecord('aim_class_category',insertMapCat);
				HashMap<String, Object> catNew=services.classService.selectClassRecord("aim_class_category", itemId);
				cod_class_cat=catNew.cod_class_cat;
				
			};	// chiusura creazione categoria se non esistente
			
			
			// VERIFICO ESISTENZA DELLA SOTTOCATEGORIA, SE ESISTE BLOCCO, SE NON ESISTE INSERISCO LA SOTTOCATEGORIA
			// recupero se esiste il codice della sottocategoria, in base a codice archivio e nome sottocategoria	
			def queryCheckSottocateg=" select cod_class_subcat FROM aim_class_subcategory where cod_class_cat=#{map.cod_class_cat} and name_class_subcat=#{map.cod_class_subcat}";
			def objSottocateg =services.queryService.executeQuery(queryCheckSottocateg,[cod_class_cat:cod_class_cat,cod_class_subcat:row.cod_class_subcat]);
			
			// se il nome della sottocategoria esiste, allora blocco
			if(objSottocateg!=null && objSottocateg.cod_class_subcat){
				def messageErr="La sottocategoria " + row.cod_class_subcat + " e\' gia\' presente.";
				throw new RuntimeException(messageErr);
				return false;
			// se il nome della sottocategoria non esiste, allora la inserisco
			}else{
				//istanzio la variabile del codice e del progressivo della sottocategoria
				def cod_subcateg = null;
				def prog_sc = null;
				// conto i numero di sottocategorie per archivio
				def queryCountSubCateg = "SELECT COUNT(1) as num_rec FROM aim_class_subcategory WHERE cod_class_cat=#{map.cod_class_cat}";
				def CountSubCateg = services.queryService.executeQuery(queryCountSubCateg,[cod_class_cat:cod_class_cat])[0].num_rec;
				log.info("numero di sottocategorie per categoria : " + CountSubCateg);				
				// se il conteggio è pari a zero, assegno al progressivo il valore 1
				if (CountSubCateg==0){prog_sc = 1}
				// se il conteggio è maggiore di zero, assegno al progressivo il valore max prog + 1
				else if (CountSubCateg>0){
					def queryMaxSubCateg = "SELECT MAX (prog_subcat) as max_prog FROM aim_class_subcategory WHERE cod_class_cat=#{map.cod_class_cat}";
					def MaxSubCateg = services.queryService.executeQuery(queryMaxSubCateg,[cod_class_cat:cod_class_cat])[0].max_prog;
					log.info("valore massimo del progressivo di sottocategoria per categoria: " + queryMaxSubCateg);
					prog_sc = MaxSubCateg + 1;					
					};
				log.info("valore da assegnare al progressivo della sottocategoria: " + prog_sc);
				def cod_class_subcat_calc = cod_class_cat + "." + StringUtils.leftPad(prog_sc.toString(),2,"0");
				log.info("codice della sottocategoria: " + cod_class_subcat_calc);				

				//inserisco le sottocategorie con il metodo di import CSV
				row.cod_class_cat=cod_class_cat;
				row.name_class_subcat=row.cod_class_subcat;
				row.cod_class_subcat=cod_class_subcat_calc;
				row.prog_subcat=prog_sc;
				return (((GwImportUtilService) services.get("gwImportUtilService")).doHeaderClassesCrudOperations(
				headerClasses, 
				row,
				mainClassName,
				mainRecordParent,
				mainAdditionalMap,
				importType,
				locale,
				codColumnsSplitted,
				projectName)!=null);				

			}; // chiusura inserimento sottocategoria
			
		};
	
	public boolean afterImport(HashMap<String, Object> additionalMap){
		
		return true;
	};
	
}