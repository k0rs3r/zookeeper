//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_build_classification_trigger
//note:    il groovy effettua le seguenti operazioni
//         a) blocco cancellazione in caso di oggetti collegati (immobili)
//         b) controllo univocit� nome in inserimento e modifica
//         c) controllo univocit� codice in iserimento e modifica


import org.apache.commons.lang.StringUtils;

public class aim_build_classification_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// CONTROLLO UNIVOCITA' DEL CODICE
		
		// recupero codice della classificazione dell'immobile
		def cod_classification = valuesMap.get("cod_classification");
		log.info("codice della classificazione: " + cod_classification);

		// conto il numero di fascicoli con lo stesso codice
		def num_cod = services.queryService.executeQuery("SELECT count(1) AS num_cod FROM aim_build_classification WHERE UPPER(cod_classification)=UPPER('" + cod_classification + "')",null)[0].num_cod;
		log.info("numero record: " + num_cod);

		// se il conteggio � maggiore di zero, allora blocco inserimento
		if (num_cod>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='La classificazione immobile non puo\' essere inserita.<br>';			
			def warning_check ='In archivio e\' gia\' presente una classificazione immobile con codice <br><b>' + cod_classification + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
			};


		// CONTROLLO UNIVOCITA' DEL NOME
		
		// recupero nome della classificazione dell'immobile
		def descr_classification = valuesMap.get("descr_classification");
		log.info("nome classificazione: " + descr_classification);

		// conto il numero di fascicoli con lo stesso nome
		def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_build_classification WHERE UPPER(descr_classification)=UPPER('" + descr_classification + "')",null)[0].num_name;
		log.info("numero record: " + num_name);

		// se il conteggio � maggiore di zero, allora blocco inserimento
		if (num_name>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='La classificazione immobile non puo\' essere inserita.<br>';			
			def warning_check ='In archivio e\' gia\' presente una classificazione immobile con nome <br><b>' + descr_classification + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
			};

		return true;
	};
 


 
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {	

		// CONTROLLO MODIFICA DEL CODICE CON ALTRO GIA' ESISTENTE
		
		// verifico se utente ha modificato il codice della classificazione
		if (valuesMap.cod_classification!=null){
			
			def new_cod = valuesMap.cod_classification;
			log.info("nuovo codice assegnato alla classificazione: " + new_cod);
			
			// conto il numero di classificazioni con lo stesso codice
			def num_cod = services.queryService.executeQuery("SELECT count(1) AS num_cod FROM aim_build_classification WHERE cod_classification='" + new_cod + "'",null)[0].num_cod;
			log.info("numero record: " + num_cod);

			// se il conteggio � maggiore di zero, allora blocco modifica
			if (num_cod>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il codice della classificazione immobile non puo\' essere modificato.<br>';			
				def warning_check ='In archivio e\' gia\' presente una classificazione con codice <b>' + new_cod + '</b>.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};


		// CONTROLLO MODIFICA DEL CODICE CON OGGETTI ASSOCIATI (IMMOBILI)
		
		// verifico se utente ha modificato il codice della classificazione
		if (valuesMap.cod_classification!=null){
			
			log.info("nuovo codice classificazione: " + valuesMap.cod_classification);
			
			def old_cod = oldvaluesMap.cod_classification;
			log.info("codice corrente (in modifica) della classificazione: " + old_cod);
			
			// conto il numero di immobili con il codice corrente
			def num_bui = services.queryService.executeQuery("SELECT count(1) AS num_bui FROM gwd_building WHERE cod_building_classification='" + old_cod + "'",null)[0].num_bui;
			log.info("numero record: " + num_bui);

			// se il conteggio � maggiore di zero, allora blocco modifica
			if (num_bui>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il codice della classificazione immobile non puo\' essere modificato.<br>';			
				def warning_check ='In archivio soon presenti n. <b>' + num_bui + ' immobili </b> associati al codice di <br>classificazione in modifica.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};




		// CONTROLLO MODIFICA DEL NOME CON ALTRO GIA' ESISTENTE
		
		// verifico se utente ha modificato il nome della classificazione
		if (valuesMap.descr_classification!=null){
			
			def new_name = valuesMap.descr_classification;
			log.info("nuovo nome assegnato alla classificazione: " + new_name);
			
			// conto il numero di classificazioni con lo stesso nome
			def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_build_classification WHERE UPPER(descr_classification)=UPPER('" + new_name + "')",null)[0].num_name;
			log.info("numero record: " + num_name);

			// se il conteggio � maggiore di zero, allora blocco inserimento
			if (num_name>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il nome della classificazione immobile non puo\' essere modificata.<br>';			
				def warning_check ='In archivio e\' gia\' presente una classificazione con nome <br><b>' + new_name + '</b>.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			};

	
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		
		// RECUPERO IDENTIFICATIVI OGGETTO IN CANCELLAZIONE

		// recupero la chiave del record
		Integer id = valuesMap.id_classification;
		log.info("chiave del record in cancellazione: " + id);
		
		// recupero il valore del codice in cancellazione
		String cod_rec_del = services.queryService.executeQuery("SELECT cod_classification AS cod_rec_del from aim_build_classification where id_classification=" + id,null)[0].cod_rec_del;			
		log.info("codice del record in cancellazione: " + cod_rec_del);


		// CONTROLLO OGGETTI ASSOCIATI AL CODICE IN CANCELLAZIONE (MMOBILI)
		
		// conto il numero di oggetti caratterizzati dal vecchio valore del codice (immobili)
		Integer count_object_del = services.queryService.executeQuery("SELECT count(1) AS count_object_del FROM gwd_building where cod_building_classification='" + cod_rec_del + "'",null)[0].count_object_del;
		log.info("numero di oggetti associato al vecchio codice  " + cod_rec_del + ": " + count_object_del);
		
		// se il conteggio � maggiore di zero allora blocco la modifica e visualizzo un messaggio di errore
		if (count_object_del>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='La classificazione immobile non puo\' essere eliminata.<br>';			
			def warning_check ='Sono presenti n. <b>' + count_object_del + ' immobili </b> associati alla classificazione immobile.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);		
		};		
		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  