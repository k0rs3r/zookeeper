//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_content_change_status
//note:    il groovy effettua le seguenti operazioni
//         a) aggiorno contenuto
//         b) salvataggio su classe storico contenuto



/*
import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument; 
import org.springframework.context.i18n.LocaleContextHolder;
*/


import org.apache.commons.lang.StringUtils;

public class aim_content_change_status_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		// RECUPERO INFORMAZIONI VALORIZZATE DA UTENTE
		
		// recupero codice del contenuto
		def cod_content = valuesMap.get("cod_content");
		log.info("codice del contenuto di origine: " + cod_content);
		
		// recupero stato finale
		def cod_track_status_end = valuesMap.get("cod_track_status_end");
		log.info("codice dello stato finale: " + cod_track_status_end);
		
		// recupero tutte le info del contenuto
		def query_cont = services.queryService.executeQuery("select * from AIM_CONTENT where cod_content='"+ cod_content +"'",null)[0];
		log.info("dati del contenuto: "+ query_cont);

		// recupero il tipo di azione relativa alla track e allo stato finale 
		def action = services.queryService.executeQuery("SELECT * FROM aim_track_status_r_action WHERE cod_track_status='"+ query_cont.status_approval+"' and cod_track_status_end='" + cod_track_status_end + "'",null)[0];
		log.info("tipo di azione: " + action.cod_action_type);
	
		if(action!=null && action.size()>0){
			//INIZIO A VALUTARE I CAMBI STATO SULLA BASE DELLE TIPOLOGIE DI AZIONE SPECIFICATE
			log.info("AIM_CHANGE_STATUS:LOG action "+action);
			//comincio a recuperare l'area dallo stato finale definito nella track
			def queryArea1 = services.queryService.executeQuery("SELECT cod_status FROM AIM_TRACK_STATUS WHERE uk_track_status='"+action.cod_track_status_end+"'",null)[0];
			def queryArea2 = services.queryService.executeQuery("SELECT area FROM AIM_TRACK_STATUS_TEMPLATE WHERE cod_status='"+queryArea1.cod_status+"'",null)[0];
			log.info("AIM_CHANGE_STATUS:queryArea1: "+queryArea1);
			log.info("AIM_CHANGE_STATUS:queryArea2: "+queryArea2);
			log.info("AIM_CHANGE_STATUS:action.cod_track_status_end: "+action.cod_track_status_end);
			//COMINCIO A VALUTARE LE TIPOLOGIE DI AZIONI
			//ora gestisco le azioni di tipo REVISIONE
			if(action.cod_action_type!=null && (action.cod_action_type=='REV' || action.cod_action_type=='CON')){
								
			def MscGenericFunction = services.gse.getInstanceByScriptName("aim_RevisionGenericFunction.groovy");
			MscGenericFunction.init(services);
			MscGenericFunction.creaRevisione(query_cont,queryArea2.area);					
			
									
				
				//blocco il contenuto revisionato impostanto il parametro a 1
				def rec_upd_rev = [:];
				if(action.cod_action_type=='REV') {
					rec_upd_rev.id_content=query_cont.id_content;
					rec_upd_rev.is_blocked = 1;
					rec_upd_rev.status_approval=action.cod_track_status_end;
					services.classService.updateClassRecord('aim_content',rec_upd_rev);
				}					
			}else{
				def rec_upd = [:];
				// aggiorno la classe degli contenuti
				log.info("AIM_CHANGE_STATUS:loggo l'ID: "+query_cont.id_content);
				log.info("AIM_CHANGE_STATUS:loggo il codice: "+query_cont.cod_content);
				rec_upd.id_content=query_cont.id_content;
				rec_upd.status_approval=action.cod_track_status_end;
				rec_upd.cod_action_type=action.cod_action_type;
				rec_upd.role_action=action.role_action;
				rec_upd.content_area=queryArea2.area;
				rec_upd.cod_content=query_cont.cod_content;
				//modifico il campo che determina l'annullamento
				if(action.cod_action_type!=null && action.cod_action_type=='ANN'){
					rec_upd.is_invalid = 1;				
				}
				if(action.cod_action_type!=null && action.cod_action_type=='APP'){
					rec_upd.is_approved = 1;				
				}	
				log.info("mappa di aggiornamento del contenuto: " + rec_upd);
				services.classService.updateClassRecord('aim_content',rec_upd);
			}
			//predispongo il popolamento della classe che tiene traccia dei cambi stato
			def rec_info = [:];
			rec_info.cod_content = valuesMap.cod_content;
			rec_info.username = valuesMap.get("username");
			rec_info.date_process = new Date();
			rec_info.action_type = action.cod_action_type;
			rec_info.cod_track = valuesMap.get("cod_track");
			rec_info.note_process = valuesMap.get("note_change_status");
			rec_info.name_action = action.name_action;
			log.info("mappa di inserimento su classe storico: " + rec_info);
			// aggiorno la classe dei cambi stato dell'elaborato
			services.classService.insertClassRecord('aim_content_history',rec_info); 					
		}else{
			throw new RuntimeException("Non ci sono azioni associate allo stato corrente.<br>Impossibile proseguire!");					
		};


		return true;
	};


	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		return true;
	};
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		return true;
	};	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
		return true;
	};
	
}


