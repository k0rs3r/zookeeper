//user:    APA
//date:    22/01/2020
//ver:     4.4.0
//project: bimdata
//type:    event trigger (TRIGGER DI CLASSE)
//class:   gwd_bim_model
//note:    

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import org.springframework.context.i18n.LocaleContextHolder; 


public class GwdBimModelTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		//recupero attraverso le due query il codice dell'edificio e lo salvo sul campo cod_01_cmis per costruire il percorso di salvataggio del
		//DWG su documentale
		def query1 = services.queryService.executeQuery("select project from GWD_BIM_MODEL_STRUCTURE where structure_code=#{map.structure_code}",valuesMap)[0];
		def project = query1.project;
		def query2 = services.queryService.executeQuery("select cod_building from GWD_BIM_PROJECT where project_code=#{map.project}",[project:project])[0];
		valuesMap.put("cod_01_cmis",query2.cod_building);	
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		
		//creare associazione tra bim model e model set / model console
		def structureCode = valuesMap.structure_code;
		def rev = valuesMap.rev;
		def pkBimModel = valuesMap.itemId;
		def layoutCode = valuesMap.layout_code;
		
		//se parte dal bim data i due campi sono popolati
		if(structureCode!=null && rev != null){
			
			//recupero modello federato
			def prjQuery = "select project from gwd_bim_model_structure where structure_code=#{map.structureCode}";
			def map = [:];
			map.structureCode = structureCode;
			def selectProject = services.queryService.executeQuery(prjQuery, map);
			def project = selectProject[0].project;
			
			def codFedModelQuery = "select cod_fed_model from gwd_fed_model where is_active=1 and cod_project=#{map.project}";
			def map1 = [:];
			map1.project = project;
			def selectCodFedModel = services.queryService.executeQuery(codFedModelQuery, map1);
			def codFedModel = selectCodFedModel[0].cod_fed_model;
			
			//recupero il model set di default, è quello del bim data
			def defaultModelSet = "select pk_model_set from gwd_model_set where is_default=1 and layout_code=#{map.layoutCode}";
			def selectPkDefaultModelSet = services.queryService.executeQuery(defaultModelSet, [layoutCode: layoutCode]);
			def pkDefaultModelSet = selectPkDefaultModelSet[0].pk_model_set;
			
			//se rev = 0 => aggiungo record su model_console e r_mod_set_bim
			if(rev==0){
				
				def modelConsole = [:];
				modelConsole.cod_fed_model = codFedModel;
				modelConsole.structure_code = structureCode;
				modelConsole.model_type = '3D';
				modelConsole.id_model = pkBimModel;
				services.classService.insertClassRecord('gwd_model_console',modelConsole);
				
				def rModSetBim = [:];
				rModSetBim.fk_bim_model = pkBimModel;
				rModSetBim.fk_model_set = pkDefaultModelSet;
				rModSetBim.default_visible = 0;
				services.classService.insertClassRecord('gwd_r_mod_set_bim',rModSetBim);
				
			} else {
				//se rev>0 => recupero record con rev-1
				def oldrev = rev-1;
				def oldModelQuery = "select pk_bim_model from gwd_bim_model where structure_code=#{map.structureCode} and rev="+oldrev;
				def pkOldModelRes = services.queryService.executeQuery(oldModelQuery, map);
				def oldPkModel = pkOldModelRes[0].pk_bim_model;
				
				//aggiorno record su model_console con id nuovo bim model
				def updateModelConsoleQuery = "update gwd_model_console set id_model="+pkBimModel+" where id_model="+oldPkModel;
				services.queryService.executeQuery(updateModelConsoleQuery, null);
				
				//update r_mod_set_bim con id nuovo bim model
				def updateRModSetBimQuery = "update gwd_r_mod_set_bim set fk_bim_model="+pkBimModel+" where fk_bim_model="+oldPkModel+" and fk_model_set="+pkDefaultModelSet;
				services.queryService.executeQuery(updateRModSetBimQuery, null);
			}
			
		}
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
		
		HashMap<String,Object> allValuesMap = new HashMap<String,Object>();
		allValuesMap.putAll(oldValuesMap);
		allValuesMap.putAll(valuesMap);
		log.info("BIM MODEL 3D: mappa completa "+allValuesMap);
		if(allValuesMap.structure_code!=null){
			def res = services.queryService.executeQuery("select cod_fed_model from GWD_MODEL_CONSOLE where id_model=#{map.pk_bim_model}", allValuesMap);
			log.info("BIM MODEL 3D: risultato query sulla GWD_MODEL_CONSOLE: "+res);
			if(res!=null && res.size()>0){
				for(int k=0; k<res.size(); k++){
					def res1 = services.queryService.executeQuery("select distinct fk_object from GWD_FED_MODEL where cod_fed_model=#{map.cod_fed_model}", [cod_fed_model : res[k].cod_fed_model]);
					log.info("BIM MODEL 3D: risultato query sulla GWD_FED_MODEL: "+res1);
					allValuesMap.cod_content = res1[0].fk_object;
					services.queryService.executeQuery("update AIM_CONTENT set is_uploaded=1 where cod_content=#{map.cod_content}", allValuesMap);
					services.queryService.executeQuery("update AIM_CONTENT_BIM set modification_author=#{map.check_in_user}, modification_date=#{map.check_in_date}, file_num=file_num+1 where cod_content=#{map.cod_content}", allValuesMap);
				}
			}
		}
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
	    return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 