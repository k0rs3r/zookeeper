//user:    MPE
//date:    30/01/2020
//ver:     4.4.8
//project: CA_ConnectorControl
//type:    connettor trigger
//class:   varie 
//note:    groovy per acquisizione stato degli adempimenti (da MASTER DATA / RISK & COMPLIANCE ad AIM)
//         sistema di origine: MASTER DATA
// 		   database origine = SUPERBONUS
//		   schema origine = data_gw
//		   tabella origine = pem_cnt_permission_status_out

//		   sistema di destinazione = AIM
//		   database destinazione = SUPERBONUS
//		   schema destinazione = cde_dati_gw
//		   tabella destinazione = aim_content


// AVVIO CONNETTORE
log.info("INIZIO ESECUZIONE CONNETTORE cnt_aim_permission_status_in " + new Date());

// CONTROLLO SE CI SONO RECORD NELLA TABELLA DI INTERSCAMBIO DATI
def count_rec_orig = queryService.executeQuery("SELECT COUNT (1) AS count_rec_orig FROM data_gw.pem_cnt_permission_status_out",null)[0].count_rec_orig;
log.info("numero record nella tabella pem_cnt_permission_status_out: " + count_rec_orig);

// SE IL CONTEGGIO DEI RECORD NELLA VISTA DI PREDISPOSIZIONE DATI E' PARI A ZERO, INSERISCO EVENTO
if (count_rec_orig==0){
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_permission_status_in';
	ins_event.date_start = new Date();
	ins_event.date_end = new Date();
	ins_event.record_insert = count_rec_orig;
	ins_event.record_update = 0;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'Non sono presenti aggiornamenti dello stato degli adempimenti da acquisire.';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);
	};


// SE CI SONO, PROCEDO
if (count_rec_orig>0){
	def date_start = new Date(); 
	log.info("data e ora di inizio connettore: " + date_start);
	// recupero lista di record da inserire
	def list_record = queryService.executeQuery("SELECT * FROM data_gw.pem_cnt_permission_status_out",null);
	log.info("elenco dei record di aggiornamento: " + list_record);
	// ciclo inserimento
	for (int i=0; i<list_record.size(); i++){	
		// AGGIORNAMENTO TABELLA DESTINAZIONE
		
		// definisco query di aggiornamento nella tabella di destinazione (stato validità)
		def query_upd_status = "UPDATE cde_dati_gw.aim_content set cod_permission_status='" + list_record[i].cod_permission_status + "' WHERE cod_content='" + list_record[i].cod_permission + "'";		
		log.info("query di inserimento record " + i + ": " + query_upd_status);
		// eseguo query di inserimento nella tabella di destinazione (stato validità)
		queryService.executeQuery(query_upd_status ,null);
		
		// definisco query di aggiornamento nella tabella di destinazione (pratica in corso)
		def query_upd_dossier = "UPDATE cde_dati_gw.aim_content set is_dossier_cur=" + list_record[i].is_dossier_cur + " WHERE cod_content='" + list_record[i].cod_permission + "'";		
		log.info("query di inserimento record " + i + ": " + query_upd_dossier);
		// eseguo query di inserimento nella tabella di destinazione (pratica in corso)
		queryService.executeQuery(query_upd_dossier ,null);		
	
		};
	def num_record_upd = list_record.size();
	log.info("numero di record aggiornati: " + num_record_upd);
	
	// definisco oggetto di inserimento evento
	def ins_event = [:];
	ins_event.name_connector = 'cnt_aim_permission_status_in';
	ins_event.date_start = date_start
	ins_event.date_end = new Date();
	ins_event.record_insert = 0;
	ins_event.record_update = num_record_upd;
	ins_event.record_delete = 0;
	ins_event.cod_event_status = 'CLO';
	ins_event.notes = 'E\' stata aggiornata l\'anagrafica dei contenuti con lo stato dei corrispondenti adempimenti (n. ' +  num_record_upd + ' record).';
	log.info("mappa di inserimento evento: " + ins_event);
	// inserisco evento
	classService.insertClassRecord("cnt_connector_event",ins_event);	

	};
	
	
	
	


// FINE CONNETTORE
log.info("FINE ESECUZIONE CONNETTORE cnt_aim_permission_status_in " + new Date());