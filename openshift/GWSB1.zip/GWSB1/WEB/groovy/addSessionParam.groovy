sessionObject.addSessionParameter("session_label", ""); 
return  sessionObject; 