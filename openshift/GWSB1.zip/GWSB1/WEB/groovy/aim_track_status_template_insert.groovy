//user:    MPE 
//date:    27/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_track_status_template
//note:    calcolo codice univoco, assegnazione valore di default ad AREA


import org.apache.commons.lang.StringUtils;


public class aim_track_status_template extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// CONTROLLO UNIVOCITA DEL NOME DELLO STATO
		
		// recupero nome dello stato
		def name_status = valuesMap.get("name_status");
		log.info("nome assegnato allo stato: " + name_status);

		// conto il numero di stati con il nome inserito da utente
		def count_name = services.queryService.executeQuery("SELECT COUNT (1) AS count_name FROM aim_track_status_template WHERE UPPER(name_status) =UPPER ('" + name_status + "')", null)[0].count_name;
		log.info("numero di record per nome: " + count_name);
		
		// se il conteggio è maggiore di zero, blocco inserimento e visualizzo messaggio
		if (count_name>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Lo stato approvativo non puo\' essere inserita.<br>';			
			def warning_check ='In archivio e\' gia\' presente uno stato con nome <b>' + name_status + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
		}
		
		// se il conteggio è pari a zero, procedo
		
		else if (count_name==0){

			// ASSEGNO VALORE DI DEFAULT ALL'AREA
			def area = 'CHECK';
			
			// CALCOLO IL CODICE DELLO STATO
			
			// conto il numero di record per area
			def count_area = services.queryService.executeQuery("SELECT COUNT (1) AS count_area FROM aim_track_status_template WHERE area = '" + area + "'", null)[0].count_area;
			log.info("numero di record per area: " + count_area);
			
			// istanzio variabile del progressivo e del codice
			def prog = null;
			def cod = null;
			
			// se il conteggio è pari a zero ,assegno al progressivo il valore 1
			if (count_area==0){prog=1}
			
			// se il conteggio è maggiore di zero, assegno al progressivo max prog + 1
			else if (count_area>0){
				def max_area = services.queryService.executeQuery("SELECT MAX (prog_status) AS max_area FROM aim_track_status_template WHERE area='" + area + "'", null)[0].max_area;
				log.info("valore massimo del progressivo per area: " + max_area);
				prog = max_area + 1;
				};
			log.info("valore da assegnare al progressivo: " + prog);
			
			// calcolo il codice (area + progressivo)
			cod = area + StringUtils.leftPad(prog.toString(), 2, "0");
			log.info("valore da assegnare al codice: " + cod);
			
			// valorizzo area, codice, progressivo
			valuesMap.put("area",area);
			valuesMap.put("prog_status",prog);
			valuesMap.put("cod_status",cod);			
			
		};

	
		return true;
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
			
		
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		
		// CONTROLLO, IN CASO DI MODIFICA DEL NOME, LA DUPLICAZIONE
		
		// recupero il nuovo nome inserito dall'utente
		def name_status = valuesMap.get("name_status");
		log.info("nome dello stato: " + name_status);
		
		// se il nome non è nullo, ovvero è stato variato, conto numero di nomi uguali
		if (name_status!=null){
			def count_name = services.queryService.executeQuery("SELECT COUNT (1) AS count_name FROM aim_track_status_template WHERE UPPER(name_status) =UPPER ('" + name_status + "')", null)[0].count_name;
			log.info("numero di record per nome: " + count_name);		
			
			// se il conteggio è maggiore di zero, blocco modifica
			if (count_name>0){
			// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Lo stato approvativo non puo\' essere modificato.<br>';			
				def warning_check ='In archivio e\' gia\' presente uno stato con nome <b>' + name_status + '</b>.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);				
				
				};
			};
		
        return true;
	};
   
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
			
		
        return true;
    };
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		//  CONTROLLO CHE LO STATO NON SIA UTILIZZATO IN UNA TRACK
		
		// recupero la chiave del record
		def pk_rec = valuesMap.id_status_template;
		log.info("chiave del record: " + pk_rec);
		
		// recupero il codice univoco del record
		def cod_rec = services.queryService.executeQuery("SELECT cod_status AS cod_rec FROM aim_track_status_template WHERE id_status_template=" + pk_rec,null)[0].cod_rec;
		log.info("codice univoco del record: " + cod_rec);
		
		// conto il numero di track che utilizzano lo stato
		def count_track = services.queryService.executeQuery("SELECT COUNT (1) AS count_track FROM aim_track_status WHERE cod_status = '" + cod_rec + "'",null)[0].count_track;
		log.info("numero di track utilizzatrici: " + count_track);
		
		// se il conteggio è maggiore di zero, blocco cancellazione e visualizzo messaggio
		if (count_track>0){
			// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Lo stato approvativo non puo\' essere eliminato.<br>';			
				def warning_check ='Lo stato e\' associato a delle track approvative.';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
			};

        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 