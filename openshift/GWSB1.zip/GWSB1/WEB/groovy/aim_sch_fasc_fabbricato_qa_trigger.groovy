//user:    MPE 
//date:    08/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    class groovy
//class:   aim_sch_fasc_fabbricato_qa
//note: 	AGGIORNAMENTO STATO DI COMPILAZIONE CONTENUTO COLLEGATO


public class aim_sch_fasc_fabbricato_qa_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

	//GENERO MAPPA TOTALE
	def AllMap = [:] ;
	AllMap.putAll(oldvaluesMap);
	AllMap.putAll(valuesMap);
		
	// recupero codice contenuto
	def cod_content = AllMap.get("cod_content");
	log.info("codice del contenuto: " + cod_content);	
	
	// recupero valore del flag di compilazione
	def is_sch_complete = AllMap.get("is_sch_complete");
	log.info("flag di contenuto completato: " + is_sch_complete);	
	
	// se il flag di compilazione è passato da 0 a 1, allora dichiaro il contenuto completato
	if (valuesMap.is_sch_complete!=null && valuesMap.is_sch_complete==1){		
		// eseguo query di aggiornamento
		services.queryService.executeQuery("UPDATE aim_content SET is_sch_complete=1 WHERE cod_content='" + cod_content + "'",null);	
		};

	// valorizzo la data di ultima modifica con la data corrente
	valuesMap.put("upload_date",new Date());	
		
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 