import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;



public class aim_content_new_doc_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){	
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){

	// RECUPERO INFORMAZIONI UTILI
	
	// recupero codice contenuto inserito
	def cod_content = valuesMap.get("cod_content");
	log.info("codice del contenuto inserito: " + cod_content);

	// recupero chiave contenuto inserito
	def id_content = valuesMap.get("id_content");
	log.info("chiave del contenuto inserito: " + id_content);
	
	// recupero cod_class_type
	def cod_class_type = valuesMap.get("cod_class_type");
	log.info("codice della forma del contenuto inserito: " + cod_class_type);

	// recupero author
	def author = valuesMap.get("author");
	log.info("autore del contenuto inserito: " + author);
	
	// recupero data di creazione
	def creation_date = valuesMap.get("creation_date");
	log.info("data di creazione del contenuto inserito: " + creation_date);	
	
	// recupero codice immobile per contenuto inserito
	def cod_building = valuesMap.get("cod_building");
	log.info("codice immobile del contenuto inserito: " + cod_building);	
	
	
	
	// POPOLAMENTO DELLA TABELLA AIM_CONTENT_DOC	
	// se il contenuto è di tipo galleria fotografica
	if (cod_class_type=='DOC'){
		// definisco oggetto di inserimento
		def ins_gal = [:];
		ins_gal.cod_content = cod_content;
		ins_gal.author = author;
		ins_gal.creation_date = creation_date;
		ins_gal.file_path = cod_building + "/DOC/" + cod_content; 
		log.info("mappa di inserimento su tabella AIM_CONTENT_DOC: " + ins_gal);
		services.classService.insertClassRecord("aim_content_doc", ins_gal);
		};
	


	// AGGIORNAMENTO TABELLA AIM_CONTENT (is_uploaded = 1)
	
	// definisco oggetto per aggiornamento aim_content_gal
	def upd_cont = [:];
	upd_cont.id_content = id_content;
	upd_cont.is_uploaded = 1;
	log.info("mappa di aggiornamento aim_content: " + upd_cont);
	services.classService.updateClassRecord("aim_content", upd_cont);




	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){			
        return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
        return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 