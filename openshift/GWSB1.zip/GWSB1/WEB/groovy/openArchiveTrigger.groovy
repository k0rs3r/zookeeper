//user:    MPE 
//date:    08/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    action groovy
//class:   aim_building
//note: 	VERIFICA PER L'IMMOBILE IL TIPO DI FASCICOLO ASSOCIATO
//          SE IL TIPO FASCICOLO NON ESISTE, VISUALIZZA MESSAGGIO ALL'UTENTE
//          SE IL TIPO FASCICOLO ESISTE, RECUPERA I CONTENUTI MINIMI PREVISTI E LI CREA SE NON PRESENTI


import com.geowebframework.transfer.model.metadataservice.Class;

log.info("APERTURA FASCICOLO IMMOBILE - START : " + parameterMap.cod_building);

// RECUPERO I PARAMETRI PASSATI DALL'AZIONE CHE RICHIAMA IL GROOVY
def cod_building = parameterMap.cod_building;
def cod_folder_type = parameterMap.cod_folder_type;
def author = parameterMap.author;
log.info("codice immobile del fascicolo: " + cod_building);
log.info("codice tipo fascicolo: " + cod_folder_type);
log.info("utente in sessione: " + author);


// CASO A - TIPO FASCICOLO NON VALORIZZATO (visualizzo messaggio)

if (cod_folder_type==null){
	log.info("sono nel caso di tipo fascicolo non valorizzato");
	// configuro il messaggio di alert	
	def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
	def warning_info ='Il fascicolo dell\'immobile non puo\' essere visualizzato.<br>';			
	def warning_check ='Per l\'immobile ' + cod_building + ' non e\' presente il tipo fascicolo di riferimento.';			
	def warning_message = warning_title + warning_info + warning_check;
	throw new RuntimeException(warning_message);	
	}

// CASO B - TIPO FASCICOLO VALORIZZATO (recupero contenuti previsti e se necessario li creo)

else if (cod_folder_type!=null){
	log.info("sono nel caso di tipo fascicolo valorizzato con " + cod_folder_type);

	// recupero il nome del tipo di fascicolo
	def name_folder_type = services.queryService.executeQuery("SELECT name_folder_type FROM aim_folder_type WHERE cod_folder_type = '" + cod_folder_type + "'",null)[0].name_folder_type;
	log.info("nome del tipo di fascicolo: " + name_folder_type);

	// conto il numero di contenuti previsti per il tipo di fascicolo
	def num_content = services.queryService.executeQuery("SELECT COUNT(1) AS num_content FROM aim_folder_type_content WHERE cod_folder_type = '" + cod_folder_type + "'",null)[0].num_content;
	log.info("numero di contenuti previsti per il fascicolo: " + num_content);
	
	// se il conteggio è pari a zero, visualizzo un messaggio
	if (num_content==0){
		log.info("sono nel caso di fascicolo senza contenuti previsti");
		// configuro il messaggio di alert	
		def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
		def warning_info ='Il fascicolo dell\'immobile non puo\' essere visualizzato.<br>';			
		def warning_check ='Per il tipo fascicolo <b><i>' + name_folder_type + '</i></b> non sono stati definiti i contenuti minimi.';			
		def warning_message = warning_title + warning_info + warning_check;
		throw new RuntimeException(warning_message);				
		}
	
	// se il conteggio è maggiore di zero, recupero la lista dei contenuti minimi associati al tipo fascicolo
	
	else if (num_content>0){
		// recupero la lista dei contenuti previsti dal fascicolo e non ancora creati
		def list_content = services.queryService.executeQuery("SELECT B.cod_building,B.cod_folder_type,C.cod_class_subcat,SUB.cod_class_cat,CAT.cod_class_arc,C.title_content,C.cod_class_type,C.cod_track,C.class_name_sch,COALESCE(cont.num_rec,0) as num_rec,C.is_mandatory,C.cod_permission_type,C.is_risk FROM gwd_building B LEFT JOIN aim_folder_type_content C ON C.cod_folder_type=B.cod_folder_type LEFT JOIN aim_class_subcategory SUB ON SUB.cod_class_subcat=C.cod_class_subcat LEFT JOIN aim_class_category CAT ON CAT.cod_class_cat=SUB.cod_class_cat LEFT JOIN (SELECT cod_building,cod_class_subcat,cod_class_type,cod_class_arc,cod_class_cat, descr_content,count(1) as num_rec FROM aim_content GROUP BY cod_building,cod_class_subcat,cod_class_type,cod_class_arc,cod_class_cat,descr_content) cont on cont.cod_building=b.cod_building and cont.cod_class_subcat=c.cod_class_subcat and cont.cod_class_type=c.cod_class_type and cont.descr_content=c.title_content WHERE COALESCE(cont.num_rec,0)=0 AND B.cod_building='" + cod_building + "'",null)
		log.info("elenco dei contenuti da creare: " + list_content);
		
		// se la lista non è vuota, ciclo inserimento
		if (list_content!=null && list_content.size()>0){
			for(int i=0; i<list_content.size(); i++){
				
				// recupero lo stato di approvazione (1° valore di stato della track)
				log.info("codice track : " +  list_content[i].cod_track);
				
				// istanzio variabile dello stato approvativo
				def status_approval = null;
				
				// se il codice track non è nullo
				if (list_content[i].cod_track!=null){
					def rec_status_app = services.queryService.executeQuery("SELECT cod_track,ord_track_status,uk_track_status FROM aim_track_status WHERE cod_track='" + list_content[i].cod_track + "' ORDER BY cod_track,ord_track_status",null)[0];
					log.info("record dello stato approvativo di interesse: " + rec_status_app);
					status_approval = rec_status_app.uk_track_status;
					};
				log.info("valore dello stato approvativo da assegnare: " + status_approval);			
				
				// definisco oggetto per inserimento contenuto
				def contentMap = [:];
				contentMap.author = author;
				//contentMap.usergroup = 'AIM_BIM';	// utilizzo il gruppo AIM_BIM per evitare i controlli sui permessi ed eventuale blocco della creazione dei contenuti
				contentMap.from_revision = 0;
				contentMap.single_insert = 0;
				contentMap.cod_building = list_content[i].cod_building;
				contentMap.class_name = list_content[i].class_name;
				contentMap.cod_class_type = list_content[i].cod_class_type;
				contentMap.content_class = list_content[i].cod_class_subcat;
				contentMap.cod_class_arc = list_content[i].cod_class_arc;
				contentMap.cod_class_cat = list_content[i].cod_class_cat;
				contentMap.descr_content = list_content[i].title_content;
				contentMap.class_name = list_content[i].class_name_sch;
				def is_uploaded = null;
				if (list_content[i].class_name_sch!=null) {is_uploaded=1} 
				else if (list_content[i].class_name_sch==null) {is_uploaded=0} ;
				contentMap.is_uploaded = is_uploaded;
				contentMap.status_approval = status_approval;
				contentMap.is_sch_complete = 0;
				contentMap.is_mandatory = list_content[i].is_mandatory;
				contentMap.is_risk = list_content[i].is_risk;
				contentMap.cod_permission_type = list_content[i].cod_permission_type;
				contentMap.send_to_risk = 0;
				contentMap.is_send_to_risk = 0;
				log.info("mappa di inserimento contenuto: " + contentMap);
				services.classService.insertClassRecord('aim_content', contentMap);
								
				};						
			};		
		}; // fine if di contenuti presenti per tipo fascicolo	
	}; // fine if fascicolo esistente
	
	
	

log.info("APERTURA FASCICOLO IMMOBILE - END : " + parameterMap.cod_building);

