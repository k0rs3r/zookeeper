import org.apache.commons.io.IOUtils;
import org.apache.commons.io.FilenameUtils;
import com.geowebframework.dataservice.GwLocaleService;
import org.apache.commons.io.FileUtils;
import com.geowebframework.dataservice.ConfigurationProperties;
import org.springframework.web.multipart.MultipartFile;
import com.geowebframework.dataservice.service.GwClassListService;
import java.net.URL;
import org.springframework.mock.web.MockMultipartFile;
import com.geowebframework.dataservice.ConfigurationProperties;
import java.util.zip.ZipInputStream;
import java.io.File;






HashMap<String, Object> services = new HashMap<String, Object>();
services.put("classService",classService);
services.put("queryService",queryService);
services.put("gse",gse);

def map = [:];
def itemId= parameterMap.itemId;
def activeUser= parameterMap.activeUser;
def projectName=parameterMap.projectName;
def usergroup=parameterMap.usergroup;
def className="aim_content_zip";
def attributeColumnName="name_file_zip";
	try{
			//RECUPERO LO ZIP DA DENTRO LA TABELLA
			HashMap<String, Object> zipRec=services.classService.selectClassRecord("aim_content_zip", itemId);
			HashMap<String,Object> documentMap = gwDocumentDataService.getDocumentMapByItemIdAndAttributeColumnName(className,itemId,attributeColumnName);
			documentMap.data = IOUtils.toByteArray(documentMap.is);
			//log.debug("zipRec"+documentMap);
			log.debug(documentMap!=null?"Letto il documento zip nella tabella di appoggio":"Non e stato possibile leggere il documento zip nella tabella di appoggio");
			InputStream  inputStream=new ByteArrayInputStream(documentMap.data);
			def zipfile=new ZipInputStream(inputStream);
			//String path=ConfigurationProperties.getInstance().getProperty("geowebfolder")+"/ZIP_FOLDER";
			//def dir = new File(path);
			
			log.debug("Cerco il csv nello zip");
			//RECUPERO IL CSV DENTRO
			def MscGenericFunction = services.gse.getInstanceByScriptName("cdeaim_GenericFunction.groovy");
			MscGenericFunction.init(services);
			byte[] byteArrayFileCsv=MscGenericFunction.getCsvFileIntoZip(zipfile);
			log.debug(byteArrayFileCsv!=null?"Trovato il csv nello zip":"Non trovato il csv nello zip");

			log.debug("BYTEARRAYCSV LOG"+byteArrayFileCsv!=null);
			log.debug("Preparo i parametri per l importazione");
			//FACCIO L IMPORTAZIONE CLASSICA DEL CSV CONFIGURANDO TUTTE LE COSE NECESSARIE PASSANDOGLI ITEMID DEL RECORD NELLA TABELLA ZIP
			def additionalMap=new HashMap<String, Object>();
			additionalMap.put("author",activeUser);
			additionalMap.put("usergroup",usergroup);
			additionalMap.put("itemId",itemId);
			//additionalMap.put("zipfile",zipfile);
			
			def columnHeadersMap=new HashMap<String, Object>();
			columnHeadersMap.put("nome_contenuto","descr_content");
			columnHeadersMap.put("immobile","cod_building");
			columnHeadersMap.put("note","content_note");
			columnHeadersMap.put("classificazione_contenuto","content_class");
			columnHeadersMap.put("forma_contenuto","cod_class_type");
			columnHeadersMap.put("percorso_file","percorso_file");
			
			
			HashMap<String, Object> props =new HashMap<String, Object>();
			props.put("importType",0);//accodamento dei records
			props.put("codColumn","cod_content");
			props.put("additionalMap",additionalMap);
			props.put("columnHeadersMap",columnHeadersMap);
			props.put("scriptName","aim_import_storico_content.groovy");
		

			def gwClassName="aim_content";
			Locale locale = GwLocaleService.getInstance().getLocale();
		
			log.debug("Preparo il csv da spedire");
			MultipartFile multipartFile = new MockMultipartFile("file","csvTemp.csv", "application/vnd.ms-excel", byteArrayFileCsv);
			//log.debug("multipartFile "+multipartFile);
			log.debug("gwClassName "+gwClassName);
			log.debug("projectName "+projectName);
			log.debug("props "+props);
			log.debug("locale "+locale);
			log.debug("gwCsvService "+gwCsvService);
			HashMap<String, Object> importResponse =null;
			log.debug("INIZIO IMPORTAZIONE");
			log.debug("Inizio importazione");
			importResponse = gwCsvService.importCSV(multipartFile, gwClassName, projectName, props, locale);
			log.debug("Fine importazione");
			//log.debug("importResponse"+importResponse);
			
			//CANCELLO I DATI NELLA TABELLA DI APPOGGIO
			//def record_conta_obj =services.queryService.executeQuery("DELETE FROM AIM_CONTENT_ZIP",null);
			
			map.importResponse=importResponse;
			//CANCELLO LA DIRECTORY DI APPOGGIO
			//dir.delete();
			map.message="Operazione Completata con Successo";
			map.success = true;
			if(importResponse==null){
				map.message="Attenzione è stata generata un eccezione lato server importResponse nullo";
				map.success = false;
			}
			log.debug("importResponse"+importResponse);
			
	}catch(Exception e){
		log.error(e.getMessage(),e);
		map.message="Attenzione è stata generata un eccezione lato server:"+e.getMessage();
		log.error(e.getMessage()!=null?e.getMessage():"Attenzione è stata generata un eccezione lato server"+e.getMessage());
		map.success = false;
	}
return map;