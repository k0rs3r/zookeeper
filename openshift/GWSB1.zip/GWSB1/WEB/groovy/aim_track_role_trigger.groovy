//user:    MPE 
//date:    27/11/2020
//ver:     4.4.7
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_track_role
//note:    calcolo codice univoco, assegnazione valore di default ad AREA


import org.apache.commons.lang.StringUtils;
//import org.springframework.context.i18n.LocaleContextHolder;

public class aim_track_role extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// ASSEGNO VALORE DI DEFAULT ALL'AREA
		def area = 'CHECK';
		
		// istanzio variabile del progressivo e del codice
		def prog = null;
		def cod = null;	
		
		// conto il numero di record per area
		def count_area = services.queryService.executeQuery("SELECT COUNT (1) AS count_area FROM aim_track_role WHERE area = '" + area + "'", null)[0].count_area;
		log.info("numero di record per area: " + count_area); 
		
		// se il conteggio è pari a zero ,assegno al progressivo il valore 1
		if (count_area==0){prog=1}		
		
		// se il conteggio è maggiore di zero, assegno al progressivo max prog + 1
		else if (count_area>0){
			def max_area = services.queryService.executeQuery("SELECT MAX (prog_track_role) AS max_area FROM aim_track_role WHERE area='" + area + "'", null)[0].max_area;
			log.info("valore massimo del progressivo per area: " + max_area);
			prog = max_area + 1;
			};
		log.info("valore da assegnare al progressivo: " + prog);
		
		// calcolo il codice (area + progressivo)
		cod = area + "RA" + StringUtils.leftPad(prog.toString(), 2, "0");
		log.info("valore da assegnare al codice: " + cod);
		
		// valorizzo area, codice, progressivo
		valuesMap.put("area",area);
		valuesMap.put("prog_track_role",prog);
		valuesMap.put("cod_track_role",cod);			

		 return true;
    };
    

    public boolean afterInsert(HashMap<String,Object> valuesMap){
			
        return true;
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		String cod_track_role = valuesMap.get("cod_track_role");
		//controllo che non vengano associati stesso utente e stesso gruppo più di una volta
		def query = services.queryService.executeQuery("SELECT id_track_role FROM AIM_TRACK_ROLE WHERE cod_track_role=#{map.cod_track_role}", valuesMap);
		if(query!=null && query.size()>0){
			throw new RuntimeException("Attenzione: Codice Ruolo già in uso!");
		}

        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
			
        return true;
		
    };
    
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		//predispongo l'eliminazione dei valori della classe dei ruoli
		def pkRole = valuesMap.id_track_role;
		def selectCode = "SELECT cod_track_role FROM AIM_TRACK_ROLE where id_track_role="+pkRole;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukRole = result.cod_track_role;
		//controllo se ci sono elementi associati, in caso blocco la cancellazione
		def num_action = services.queryService.executeQuery("select count(id_track_status_action) as num_action from AIM_TRACK_STATUS_R_ACTION where role_action=#{map.cod_track_role}",[cod_track_role:ukRole]);
		log.info("loggo la query per bloccare la cancellazione: "+num_action);
		if(num_action!=null && num_action[0]!=null && num_action[0].num_action!=null && num_action[0].num_action>0){
			log.info("sono entrato nel blocco");
			throw new Exception("Attenzione: Non è possibile cancellare il ruolo!<br> Risulta associato ad una o più azioni delle track");
		}else{
			def del = services.queryService.executeDeleteQuery("DELETE FROM AIM_TRACK_USER_ROLE WHERE cod_track_role='"+ukRole+"'",null);	
		}
	
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
				
        return true;
    };

} 