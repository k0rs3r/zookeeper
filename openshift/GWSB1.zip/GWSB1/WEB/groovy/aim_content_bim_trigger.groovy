import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;



public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		//il modello bim viene cancellato solo nel caso in cui il contenuto non sia associato a nessuno modello grafico (gestito da ACL)
		def pkBimContent = valuesMap.id_bim;
		def selectCode = "SELECT cod_content FROM aim_content_bim where id_bim="+pkBimContent;
		def result = services.queryService.executeQuery(selectCode, null)[0];
		def ukCont = result.cod_content;
		
		def selectShortCode = services.queryService.executeQuery("SELECT cod_project FROM GWD_FED_MODEL where fk_object=#{map.ukCont}", [ukCont : ukCont]);
		if(selectShortCode!=null && selectShortCode.size()>0){
			def cod_project = selectShortCode[0].cod_project;
			//cancellazione modello federato associato al contenuto bim cancellato
			def delFedMod = services.queryService.executeDeleteQuery("DELETE FROM GWD_FED_MODEL WHERE fk_object=#{map.ukCont}", [ukCont : ukCont]);
			
			//se il bim project è associato soltanto al contenuto cancellato => cancello le strutture di modello del progetto
			def numContent = services.queryService.executeQuery("SELECT count(id_fed_model) as num_content FROM gwd_fed_model where cod_project=#{map.cod_project}", [cod_project : cod_project])[0].num_content;
			if(numContent==0){
				services.queryService.executeDeleteQuery("DELETE FROM gwd_bim_project WHERE project_code=#{map.cod_project}", [cod_project : cod_project]);
				def selectStructureCodeList = services.queryService.executeQuery("SELECT structure_code FROM gwd_bim_model_structure where project=#{map.cod_project}", [cod_project : cod_project]);
				if(selectStructureCodeList!=null && selectStructureCodeList.size()>0){
					def structure_code = null;
					def level_code = null;
					for(int j=0; j<selectStructureCodeList.size(); j++){
						structure_code = selectStructureCodeList[j].structure_code;
						services.queryService.executeDeleteQuery("DELETE FROM gwd_drawing WHERE structure_code=#{map.structure_code}", [structure_code : structure_code]);
						services.queryService.executeDeleteQuery("DELETE FROM gwd_bim_model WHERE structure_code=#{map.structure_code}", [structure_code : structure_code]);
						services.queryService.executeDeleteQuery("DELETE FROM gwd_layout WHERE layout_code=#{map.structure_code}", [structure_code : structure_code]);
						def selectBimLevelCodeList = services.queryService.executeQuery("SELECT level_order FROM gwd_bim_level where cod_project=#{map.cod_project}", [cod_project : cod_project]);
						if(selectBimLevelCodeList!=null && selectBimLevelCodeList.size()>0){
							def concatStructureCode = null;
							for(int i=0; i<selectBimLevelCodeList.size(); i++){
								level_code = selectBimLevelCodeList[i].level_order;
								concatStructureCode = structure_code +"_"+level_code;
								services.queryService.executeDeleteQuery("DELETE FROM gwd_layout WHERE layout_code=#{map.concatStructureCode}", [concatStructureCode : concatStructureCode]);
							}
							services.queryService.executeDeleteQuery("DELETE FROM gwd_bim_level WHERE cod_project=#{map.cod_project}", [cod_project : cod_project]);
						}
					}
				}
			}
		}
		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 