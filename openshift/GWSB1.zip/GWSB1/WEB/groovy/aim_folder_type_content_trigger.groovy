//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_folder_type_content
//note:    il groovy effettua le seguenti operazioni
//         a) calcolo del codice del contenuto previsto (codice fascicolo + codice classificazione contenuto + progressivo)

import org.apache.commons.lang.StringUtils;

public class aim_folder_type_content_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// CALCOLO IL CODICE DEL CONTENUTO PREVISTO
		
		// recupero codice tipo fascicolo
		def cod_folder_type = valuesMap.get("cod_folder_type");
		log.info("codice del tipo fascicolo: " + cod_folder_type);
		
		// recupero codice classificazione contenuto
		def cod_class_subcat = valuesMap.get("cod_class_subcat");
		log.info("codice classificazione contenuto: " + cod_class_subcat);
		
		// conto il numero di record per tipo fascicolo e classificazione contenuto
		def num_rec = services.queryService.executeQuery("SELECT count(1) AS num_rec FROM aim_folder_type_content WHERE cod_folder_type='" + cod_folder_type + "' AND cod_class_subcat='" + cod_class_subcat + "'",null)[0].num_rec;
		log.info("numero di record: " + num_rec);

		// istanzio variabili codice e progressivo del contenuto
		def cod_rec = null;
		def prog_rec = null;

		// se il conteggio � pari a zero, allora assegno al progressivo valore 1
		
		if (num_rec==0){prog_rec=1}
	
		// se il conteggio � maggiore di zero, allora assegno al progressivo valore max prog + 1
		else if (num_rec>0){	
		
			// recupero max valore del progressivo
			def max_prog = services.queryService.executeQuery("SELECT MAX(prog_folder_type_content) AS max_prog FROM aim_folder_type_content WHERE cod_folder_type='" + cod_folder_type + "' AND cod_class_subcat='" + cod_class_subcat + "'",null)[0].max_prog;
			log.info("valore max del progressivo del record: " + max_prog);

			// calcolo nuovo progressivo
			prog_rec = max_prog + 1;
		};
		
		log.info("valore da assegnare al progressivo: " + prog_rec);

		// calcolo il codice del tipo di contenuto previsto
		cod_rec = cod_folder_type + "_" + cod_class_subcat + "-" + StringUtils.leftPad(prog_rec.toString(), 2, "0");;
		log.info("codice del contenuto: " + cod_rec);		
		
		// assegno il valore al codice del tipo di contenuto previsto
		valuesMap.put("cod_folder_type_content",cod_rec);					

		// assegno il valore al progressivo del tipo di contenuto previsto
		valuesMap.put("prog_folder_type_content",prog_rec);			


		return true;
	};
 


 
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {			
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  