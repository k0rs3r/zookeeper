//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_folder_action_cur
//note:    il groovy effettua le seguenti operazioni
//         a) cambio stato del fabbricato in IN ESECUZIONE
//         b) blocca attivazione se siamo oltre il numero massimo di immobili attivi previsti dal fascicolo


import org.apache.commons.lang.StringUtils;

public class aim_folder_action_clo_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// RECUPERO IL NUMERO DI RISORSE PREVISTE DALLA LICENZA
		String num_res = services.queryService.executeQuery("SELECT param_value as num_res FROM aim_product_setting WHERE param_name='NumeroRisorse' AND status='Y'",null)[0].num_res;
		log.info("numero risorse licenza: " + num_res);
		
		// VERIFICO SE POSSO EFFETTUARE IL CAMBIO STATO 
		String num_active = services.queryService.executeQuery("SELECT COUNT(1) as num_active FROM gwd_building WHERE cod_folder_status='CUR'",null)[0].num_active;
		log.info("numero immobili attivi: " + num_active);
		
		num_active = '100';
		
		// SE IL NUMERO DI IMMOBILI ATTIVI E' UGUALE A QUELLO MASSIMO, BLOCCO CAMBIO STATO E VISUALIZZO ALERT
		if (num_active==num_res){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Non e\' possibile procedere con l\'attivazione del fascicolo dell\'immobile.<br>';			
			def warning_check ='E\' stato raggiunto il numero massimo di <b>' + num_res + '</b> fascicoli <b> In Esecuzione</b><br> previsti dalla licenza d\'uso.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
		};
		
	
		// recupero le note inserite dall'utente
		def note_user = valuesMap.get("note");
		log.info("note utente: " + note_user);
		
		def cod_building=valuesMap.get("cod_building");
		log.info("cod_building: " + cod_building);
		
		// definisco variabile note totali
		def note_tot = null;
		
		// se le note dell'utente sono nulle, registro solo il cambio stato
		if (note_user!=null) {
			note_tot = "Cambio stato immobile " + cod_building + " - Stato IN ESECUZIONE (" +  note_user + ")";
			}
		// se le note dell'utente non sono nulle registro cambio stato + note utente
		else if (note_user==null){
			note_tot = "Cambio stato immobile " + cod_building + " - Stato IN ESECUZIONE";
			};
		log.info("note totali: " + note_tot);	

		valuesMap.put("note",note_tot);		
		
		
		
		return true;
	};
  
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
	
		// recupero codice immobile
		def cod_building=valuesMap.get("cod_building");
		log.info("cod_building: " + cod_building);
		
		// recupero chiave dell'immobile
		def pk_rec = services.queryService.executeQuery("SELECT id_building as pk_rec FROM gwd_building WHERE cod_building='" + cod_building + "'",null)[0].pk_rec;
		log.info("chiave del record: " + pk_rec);
		
		// definisco oggetto di aggiornamento immobile
		def upd_rec = [:];
		upd_rec.id_building=pk_rec;
		upd_rec.cod_folder_status='CUR';
		log.info("mappa dei valori: " + upd_rec);
		
		// aggiorno record
		services.classService.updateClassRecord("aim_building",upd_rec);
		
		

		
	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {			
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  