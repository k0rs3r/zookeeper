
import org.apache.commons.lang.StringUtils;
import groovy.time.TimeCategory
import com.geowebframework.calendar.objects.Selection;
import com.geowebframework.calendar.objects.SelectionList;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;

public class StatusTrackInsertGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
	

	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		//CALCOLO IL CODICE UNIVOCO DELLO STATO
		// recupero i valori dei codici di interesse
		def cod_status = valuesMap.cod_status;		
		def cod_track = valuesMap.cod_track;
		def ord_track_status = valuesMap.ord_track_status;		
		// valorizzo il codice completo
		valuesMap.put("uk_track_status",cod_track + cod_status);
		def temp = services.queryService.executeQuery("SELECT * FROM AIM_TRACK_STATUS_TEMPLATE where cod_status='"+cod_status+"'", null)[0];
		valuesMap.put("icon_file",temp.icon_file); 
		valuesMap.put("icon_ctype",temp.icon_ctype);
		valuesMap.put("icon_name",temp.icon_name);
		
		//CONTROLLO CHE LO STATO DELLA TRACK NON VENGA INSERITO IN CASO di TRACK a PRIORITà 99
		def queryTrack = services.queryService.executeQuery("SELECT priority FROM AIM_TRACK where cod_track=#{map.cod_track}",valuesMap)[0];
		log.info("loggo la priorita"+queryTrack.priority);
		if(queryTrack.priority==99){
			throw new RuntimeException("Impossibile aggiungere un nuovo stato.<br>Track riferita ad un contenuto non verificabile");
		}
			
		//CONTROLLO CHE L'ORDINE NON VENGA RIPETUTO PIù VOLTE
		def num_ord = services.queryService.executeQuery("SELECT count(id_track_status) as num_ord FROM AIM_TRACK_STATUS where cod_track='"+cod_track+"' and ord_track_status="+ord_track_status, null)[0].num_ord;
		log.info("loggo quanti ordini ci sono: "+num_ord);
		if(num_ord!=null && num_ord>0){
			throw new RuntimeException("Numero Ordine già in uso, impostare numero differente.");
		}		

		def is_cloned = valuesMap.get("is_cloned");
		if(is_cloned==0){
			//controllo che non venga inserito più volte lo stesso progressivo
			def ord_status = services.queryService.executeQuery("SELECT count(id_track_status) as ord_status FROM AIM_TRACK_STATUS WHERE cod_track='"+cod_track+"' and ord_track_status="+ord_track_status, null)[0].ord_status;
			if(ord_status!=null && ord_status>0){
				throw new RuntimeException("Il progressivo dello stato è già in uso. Digitare un numero differente!");
			};
			//COMMENTO IL CONTROLLO DEL CAMPO PRIMO STATO PERCHè ROBERTO HA DETTO CHE FORSE NON SERVE
			//controllo che lo stato iniziale sia univoco
			/*
			def firstStatus = services.queryService.executeQuery("SELECT count(id_track_status) as firstStatus FROM AIM_TRACK_STATUS WHERE cod_track='"+cod_track+"' and is_first_status="+is_first_status, null)[0].firstStatus;
			log.info("loggo in insert il firststatus: "+(uk_track_status+firstStatus));
			if(firstStatus!=null && firstStatus>0){
				throw new RuntimeException("Stato iniziale già impostato!");
			};
			*/
		}
		return true;
	};
	
	public boolean afterInsert(HashMap<String,Object> valuesMap){			
		return true;
	};
	
	public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){

		//recupero le variabili che mi servono
		def cod_track = oldValuesMap.get("cod_track");
		def ord_track_status = valuesMap.get("ord_track_status");
		def is_first_status = valuesMap.get("is_first_status");

		//controllo che non venga inserito più volte lo stesso progressivo
		def ord_status = services.queryService.executeQuery("SELECT count(id_track_status) as ord_status FROM AIM_TRACK_STATUS WHERE cod_track='"+cod_track+"' and ord_track_status="+ord_track_status, null)[0].ord_status;
		log.info("numero ord_status: "+ord_status);
		if(ord_status!=null && ord_status>0){
			throw new RuntimeException("Il progressivo dello stato è già in uso. Digitare un numero differente!");
		};
		//COMMENTO IL CONTROLLO DEL CAMPO PRIMO STATO PERCHè ROBERTO HA DETTO CHE FORSE NON SERVE
		/*
		if(is_first_status!=null && is_first_status==1){
			//controllo che lo stato iniziale sia univoco
			def firstStatus = services.queryService.executeQuery("SELECT count(id_track_status) as firstStatus FROM AIM_TRACK_STATUS WHERE cod_track='"+cod_track+"' and is_first_status=1", null)[0].firstStatus;
			log.info("numero firstStatus: "+firstStatus);
			if(firstStatus!=null && firstStatus>0){
				throw new RuntimeException("Stato iniziale già impostato!");
			};
		}
		*/
		
		return true;
	};
	
	public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldValuesMap){
	
		return true;
	};
	
	public boolean beforeDelete(HashMap<String,Object> valuesMap){
	//predispongo l'eliminazione dei valori della classe delle azioni
	def pkStatus = valuesMap.id_track_status;
	def selectCode = "SELECT uk_track_status FROM aim_track_status where id_track_status="+pkStatus;
	def result = services.queryService.executeQuery(selectCode, null)[0];
	def ukStatus = result.uk_track_status;
	log.info("loggo il codice dello status che sto cancellando: "+ukStatus);
	//controllo se ci sono dei contenuti associati alla categoria in sessione
	def numContent = services.queryService.executeQuery("SELECT count(id_content) as numContent FROM aim_content WHERE status_approval='"+ukStatus+"'", null)[0].numContent;
	if(numContent>0){
		throw new RuntimeException("ATTENZIONE: Impossibile eliminare questo STATO.<br>Sono presenti contenuti ad esso associati");	
	}
	def del = services.queryService.executeDeleteQuery("DELETE FROM AIM_TRACK_STATUS_R_ACTION WHERE cod_track_status='"+ukStatus+"'",null);
		
		return true;
	};
	
	public boolean afterDelete(HashMap<String,Object> valuesMap){
		return true;
	};
	
}
