
//project: AIM
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_content
//note:    inserire descrizione completa

import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.metadataservice.GwmMnemonicCode;
import com.geowebframework.transfer.model.metadataservice.McPart;
import com.geowebframework.transfer.model.metadataservice.MnemonicCode;
import com.geowebframework.transfer.objects.session.SessionObject;
import com.geowebframework.dataservice.ConfigurationProperties;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import java.nio.file.Files;
import com.google.common.io.ByteStreams;
import java.io.InputStream;

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		String basePath = ConfigurationProperties.getInstance().getProperty("basePath");
		byte[] byteArray = null;
		def fileName="sch_face.png";
		def contentType="image/png";
		try{
			String downloadUrl = ConfigurationProperties.getInstance().getString("basePath")+"images/"+fileName;
			URL fileURL = new URL(downloadUrl);
			InputStream  is = fileURL.openStream();
			byte[] bytes = ByteStreams.toByteArray(is);
			HashMap<String,Object> documentMap =[:];
			documentMap.data=bytes;
			documentMap.contentType=contentType;
			documentMap.name=fileName;
			valuesMap.put("face_name", documentMap);
		}catch(Exception e){
			log.error("ATTENZIONE NON E' STATO POSSIBILE RECUPERARE LA FOTO NEI CONTENUTI STATICI:"+"images/"+fileName);
		}		
	return true;	
	};
    
	public boolean afterInsert(HashMap<String,Object> valuesMap){
	
	
	return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
	
    return true;
	};
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		SessionObject sessionObject = services.gse.runScript("getSessionObject.groovy");
		def user = null;
		log.info("loggo il sessionObject: "+sessionObject);
		if(sessionObject!=null){
			//recupero le variabili per la gestione della modifica della classificazione
			user = sessionObject.getUser();
		}
		def now = new Date();
		def querySchCont1 = services.queryService.executeQuery("UPDATE AIM_CONTENT_SCH set modification_date=#{map.now} WHERE cod_content=#{map.cod_content}",[now:now,cod_content:oldvaluesMap.cod_content]);
		def querySchCont2 = services.queryService.executeQuery("UPDATE AIM_CONTENT_SCH set modification_author=#{map.user} WHERE cod_content=#{map.cod_content}",[user:user,cod_content:oldvaluesMap.cod_content]);
    return true;
    };
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){

		return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

} 