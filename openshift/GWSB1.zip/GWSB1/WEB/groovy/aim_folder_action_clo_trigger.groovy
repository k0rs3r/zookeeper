//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_folder_action_clo
//note:    il groovy effettua le seguenti operazioni
//         a) cambio stato del fabbricato in archiviato


import org.apache.commons.lang.StringUtils;

public class aim_folder_action_clo_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		// recupero le note inserite dall'utente
		def note_user = valuesMap.get("note");
		log.info("note utente: " + note_user);
		
		def cod_building=valuesMap.get("cod_building");
		log.info("cod_building: " + cod_building);
		
		// definisco variabile note totali
		def note_tot = null;
		
		// se le note dell'utente sono nulle, registro solo il cambio stato
		if (note_user!=null) {
			note_tot = "Cambio stato immobile " + cod_building + " - Stato ARCHIVIATO (" +  note_user + ")";
			}
		// se le note dell'utente non sono nulle registro cambio stato + note utente
		else if (note_user==null){
			note_tot = "Cambio stato immobile " + cod_building + " - Stato ARCHIVIATO";
			};
		log.info("note totali: " + note_tot);	

		valuesMap.put("note",note_tot);		
		
		
		
		return true;
	};
  
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
	
		// recupero codice immobile
		def cod_building=valuesMap.get("cod_building");
		log.info("cod_building: " + cod_building);
		
		// recupero chiave dell'immobile
		def pk_rec = services.queryService.executeQuery("SELECT id_building as pk_rec FROM gwd_building WHERE cod_building='" + cod_building + "'",null)[0].pk_rec;
		log.info("chiave del record: " + pk_rec);
		
		// definisco oggetto di aggiornamento immobile
		def upd_rec = [:];
		upd_rec.id_building=pk_rec;
		upd_rec.cod_folder_status='CLO';
		log.info("mappa dei valori: " + upd_rec);
		
		// aggiorno record
		services.classService.updateClassRecord("aim_building",upd_rec);
		
		

		
	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {			
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  