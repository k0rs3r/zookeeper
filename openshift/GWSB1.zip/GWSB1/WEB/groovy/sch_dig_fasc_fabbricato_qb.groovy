public class sch_dig_fasc_fabbricato_qb extends com.geowebframework.transfer.objects.digitaldocument.GwDigitalDocumentConfigImpl {
	
	public Boolean isVisible(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){

		log.error("templateName: "+templateName);
		log.error("sectionName: "+sectionName);
		log.error("entityName: "+entityName);
		log.error("entityStatus: "+entityStatus);
		def isVisible = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qb")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QB_01")||
				sectionName.equals("QB_99")
			)
				{
					isVisible = true;
					log.error("isVisible = true");
				}
			
		}
		log.error("isVisible: "+isVisible);
		return isVisible;
	}
	public Boolean isEditable(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isEditable = false;
		if(templateName.equals("sch_dig_fasc_fabbricato_qb")){
			
			if (
				sectionName.equals("Header")||
				sectionName.equals("QB_01")||
				sectionName.equals("QB_99")
			)
				{
					isEditable = true;
				}
			
		}
		return isEditable;
	}
	
	public Boolean isDefaultSelected(
		String ddocName,
		String templateName,
		String sectionName,
		String entityId,
		String entityName,
		String entityStatus,
		String gwUser,
		String gwGroup,
		Map<String, Object> gwActiveScopesMap
	){
		def isDefaultSelected = false;
		return isDefaultSelected;
	}

}