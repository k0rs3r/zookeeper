//user:    MPE
//date:    27/10/2020
//ver:     4.4.4
//project: AIM - SUPERBONUS
//type:    event trigger (TRIGGER DI CLASSE)
//class:   aim_folder_type
//note:    il groovy effettua le seguenti operazioni
//         a) calcolo del codice del tipo fascicolo
//         b) blocco cancellazione in caso di oggetti collegati (contenuti e classificazioni)
//         c) controllo univocit� nome in inserimento e modifica


import org.apache.commons.lang.StringUtils;

public class aim_folder_type_trigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
	public boolean beforeInsert(HashMap<String,Object> valuesMap){

		// CONTROLLO UNIVOCITA' DEL NOME
		
		// recupero nome del fascicolo
		def name_folder_type = valuesMap.get("name_folder_type");
		log.info("nome del fascicolo: " + name_folder_type);

		// conto il numero di fascicoli con lo stesso nome
		def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_folder_type WHERE UPPER(name_folder_type)=UPPER('" + name_folder_type + "')",null)[0].num_name;
		log.info("numero record: " + num_name);

		// se il conteggio � maggiore di zero, allora blocco inserimento
		if (num_name>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Il tipo fascicolo non puo\' essere inserito.<br>';			
			def warning_check ='In archivio e\' gia\' presente una tipologia di fascicolo con denominazione <br><b>' + name_folder_type + '</b>';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);			
		}


		// SE IL NOME E' UNIVOCO, CALCOLO IL CODICE DEL FASCICOLO (TF_00n)
		
		else if (num_name==0){
			// istanzio la variabile del progressivo
			def prog = null;
			
			// conto il numero di record nella tabella 
			def num_rec = services.queryService.executeQuery("SELECT count(1) AS num_rec FROM aim_folder_type",null)[0].num_rec;
			log.info("numero record: " + num_rec);
			
			// se il numero di record � pari a zero, allora assegno al progressivo il valore 1
			if (num_rec==0){prog=1}
			
			// se il numero dei record � maggiore di zero, allora recupero il valore massimo e assegno al progressibo il valore massimo + 1
			else if (num_rec>0){
				// recupero il max
				def max_prog = services.queryService.executeQuery("SELECT MAX(prog_folder_type) AS max_prog FROM aim_folder_type",null)[0].max_prog;
				log.info("numero record: " + max_prog);
				// valorizzo il progressivo
				prog = max_prog + 1;
				};
			
			log.info("valore del progressivo: " + prog);
			
			// calcolo il codice del tipo di fascicolo
			def cod_foldertype = "TF_" + StringUtils.leftPad(prog.toString(), 3, "0");
			log.info("codice del tipo di fascicolo: " + cod_foldertype);		
			
			// assegno il valore al codice del tipo di fascicolo
			valuesMap.put("cod_folder_type",cod_foldertype);		

			// assegno il valore al progressivo del tipo di fascicolo
			valuesMap.put("prog_folder_type",prog);	
		};
		
		return true;
	};
 


 
	public boolean afterInsert(HashMap<String,Object> valuesMap){	
		return true;		
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap) {	

		// CONTROLLO MODIFICA DEL NOME CON ALTRO GIA' ESISTENTE
		
		// verifico se utente ha modificato il nome del tipo di fascicolo
		if (valuesMap.name_folder_type!=null){
			
			def new_name = valuesMap.name_folder_type;
			log.info("nuovo nome assegnato al tipo di fascicolo: " + new_name);
			
			// conto il numero di fascicoli con lo stesso nome
			def num_name = services.queryService.executeQuery("SELECT count(1) AS num_name FROM aim_folder_type WHERE UPPER(name_folder_type)=UPPER('" + new_name + "')",null)[0].num_name;
			log.info("numero record: " + num_name);

			// se il conteggio � maggiore di zero, allora blocco inserimento
			if (num_name>0){
				// configuro il messaggio di alert	
				def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
				def warning_info ='Il nome del tipo fascicolo non puo\' essere modificato.<br>';			
				def warning_check ='In archivio e\' gia\' presente una tipologia di fascicolo con denominazione <br><b>' + new_name + '</b>';			
				def warning_message = warning_title + warning_info + warning_check;
				throw new RuntimeException(warning_message);			
				};		
			
			};

	
       return true;
	};

    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){	
	    return true;
	};
 
 
    public boolean beforeDelete(HashMap<String,Object> valuesMap){
		
		
		// RECUPERO IDENTIFICATIVI OGGETTO IN CANCELLAZIONE

		// recupero la chiave del record
		Integer id = valuesMap.id_folder_type;
		log.info("chiave del record in cancellazione: " + id);
		
		// recupero il valore del codice in cancellazione
		String cod_rec_del = services.queryService.executeQuery("SELECT cod_folder_type AS cod_rec_del from aim_folder_type where id_folder_type=" + id,null)[0].cod_rec_del;			
		log.info("codice del record in cancellazione: " + cod_rec_del);


		// CONTROLLO OGGETTI ASSOCIATI AL CODICE IN CANCELLAZIONE (CONTENUTI PREVISTI E CLASSIFICAZIONI IMMOBILI)
		
		// conto il numero di oggetti caratterizzati dal vecchio valore del codice (contenuti)
		Integer count_object_del = services.queryService.executeQuery("SELECT count(1) AS count_object_del FROM aim_folder_type_content where cod_folder_type='" + cod_rec_del + "'",null)[0].count_object_del;
		log.info("numero di oggetti associato al vecchio codice  " + cod_rec_del + ": " + count_object_del);

		// conto il numero di oggetti caratterizzati dal vecchio valore del codice (classificazioni immobili)
		Integer count_object_del2 = services.queryService.executeQuery("SELECT count(1) AS count_object_del2 FROM aim_folder_type_r_build_class where cod_folder_type='" + cod_rec_del + "'",null)[0].count_object_del2;
		log.info("numero di oggetti associato al vecchio codice  " + cod_rec_del + ": " + count_object_del2);
		
		// se il conteggio � maggiore di zero allora blocco la modifica e visualizzo un messaggio di errore
		if (count_object_del>0 || count_object_del2>0){
			// configuro il messaggio di alert	
			def warning_title ='<b><i>ATTENZIONE</b></i><br>';			
			def warning_info ='Il tipo fascicolo non puo\' essere eliminato.<br>';			
			def warning_check ='Sono presenti contenuti previsti e/o classificazioni immobili associate.<br>Per poter eliminare il fascicolo, cancellare i contenuti previsti e/o <br>dissociare le classificazioni immobili associate.';			
			def warning_message = warning_title + warning_info + warning_check;
			throw new RuntimeException(warning_message);		
		};		
		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
        return true;
    };

}  