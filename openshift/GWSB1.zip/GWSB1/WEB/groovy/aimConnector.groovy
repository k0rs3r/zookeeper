import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.HashMap;

import org.apache.poi.util.IOUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.Rendition;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.chemistry.opencmis.commons.impl.MimeTypes;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConnectionException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisRuntimeException;

import com.geowebframework.utils.GwUtils;
import com.geowebframework.transfer.objects.webclient.GwCmisDocument;
import com.geowebframework.dataservice.service.GwClassListService;
import com.geowebframework.dataservice.service.widget.GwCmisService;
import com.geowebframework.transfer.model.metadataservice.Attribute;
import com.geowebframework.transfer.model.metadataservice.Class;
import com.geowebframework.transfer.model.widget.Attachments;
import com.geowebframework.transfer.objects.exception.GwUnbuildableDollarGraphsExpressionException;
import com.geowebframework.metadataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.JsonServerResponse;

import com.google.common.io.Files;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;



class aimConnector {

    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger("com.geowebframework.groovy");
	private String spRootFolderName = "AIM/";
    
	def services;
	void init(s) {
		 services=s;
	}

    public HashMap<String, String> insertBimStructure(String codPimProject) throws Exception {
		//gestisco le strutture di modello per il bim data -> inserisco solo strutture con tutti i livelli (team/system/level) popolati
		//per ogni livello della struttura devo controllare che non esista già il codice nel db dell'AIM, se già esiste non posso inserirlo
		//////////sentire ABA
		def teams = services.queryService.executeQuery("select distinct cod_pim_team, name_pim_team from DATA_GW.GWC_CNT_PIM_MOD_STRUCTURE where cod_pim_project=#{map.codPimProject}", [codPimProject : codPimProject]);
		for(HashMap<String, Object> team : teams){
			def isTeamExist = services.queryService.executeQuery("select id_team_type from cde_dati_gw.gwd_team_type where cod_team_type=#{map.cod_team_type}", [cod_team_type : team.cod_pim_team]);
			if(isTeamExist==null || isTeamExist.isEmpty()){
				services.queryService.executeQuery("insert into cde_dati_gw.gwd_team_type (cod_team_type, name_team_type) values (#{map.cod_pim_team}, #{map.name_pim_team})", team);
			}
		}

		def systems = services.queryService.executeQuery("select distinct cod_pim_team, cod_pim_system, name_pim_system from DATA_GW.GWC_CNT_PIM_MOD_STRUCTURE where cod_pim_project=#{map.codPimProject} and cod_pim_system is not null", [codPimProject : codPimProject]);
		for(HashMap<String, Object> system : systems){
			def isSystemExist = services.queryService.executeQuery("select id_system_type from cde_dati_gw.gwd_system_type where cod_team_type=#{map.cod_team_type} and cod_system_type=#{map.cod_system_type}", [cod_team_type : system.cod_pim_team, cod_system_type: system.cod_pim_system]);
			if(isSystemExist==null || isSystemExist.isEmpty()){
				services.queryService.executeQuery("insert into cde_dati_gw.gwd_system_type (cod_team_type, cod_system_type, name_system_type) values (#{map.cod_pim_team}, #{map.cod_pim_system}, #{map.name_pim_system})", system);
				//gwd_bim_system non gestita
			}
		}

		//i livelli sono unici per progetti, quindi se il progetto viene creato adesso, posso essere sicuro che il livello non esista
		def levels = services.queryService.executeQuery("INSERT INTO cde_dati_gw.gwd_bim_level (name_level, level_order, cod_project, cod_level) SELECT " +
					"CONCAT(row_number() OVER (PARTITION BY cod_pim_project ORDER BY RIGHT(cod_pim_level, 2)), ' - ', name_pim_level) as name_level, row_number() OVER (PARTITION BY cod_pim_project ORDER BY RIGHT(cod_pim_level, 2)), cod_pim_project, cod_pim_level " +
					"FROM DATA_GW.GWC_CNT_PIM_MOD_STRUCTURE GROUP BY cod_pim_project, cod_pim_level, name_pim_level HAVING cod_pim_project=#{map.codPimProject} and cod_pim_level is not null", [codPimProject : codPimProject]);

		//recupero tutti i dati delle strutture di modello
		//inserisco record sulla gwd_bim_model_structure
		//aggiungo alla mappa la corrispondenza tra codice struttura cde e codice struttura bim data
		def datasToGenerateStructure = services.queryService.executeQuery("select s.cod_pim_team, s.cod_pim_system, s.cod_pim_level, l.level_order from DATA_GW.GWC_CNT_PIM_MOD_STRUCTURE s "+
				"inner join CDE_DATI_GW.gwd_bim_level l on l.cod_level=s.cod_pim_level and l.cod_project=s.cod_pim_project where s.cod_pim_project=#{map.codPimProject} and s.cod_pim_level is not null and s.cod_format_document is not null", [codPimProject : codPimProject]);
		
		HashMap<String, String> stucturesHM = new HashMap<String, String>();
		String structureQuery = "INSERT INTO CDE_DATI_GW.GWD_BIM_MODEL_STRUCTURE (structure_code, project, team, system, level) values (#{map.aimStructure}, #{map.project}, #{map.team}, #{map.system}, #{map.aimLevel})";
		
		for(HashMap<String, Object> datas : datasToGenerateStructure){
			String team = datas.cod_pim_team;
			String system = datas.cod_pim_system;
			String cdeLevel = datas.cod_pim_level;
			Integer aimLevel = datas.level_order;
			String cdeStructure = codPimProject + "_" + team + "_" + system + "_" + cdeLevel;
			String aimStructure = codPimProject + "_" + team + "_" + system + "_" + aimLevel;
			services.queryService.executeQuery(structureQuery, [project: codPimProject, team: team, system: system, aimLevel: aimLevel, aimStructure: aimStructure]);
			stucturesHM.put(cdeStructure, aimStructure);
		}

		return stucturesHM;
    }

	public void insertPimDeliverableAndAttachment(String codPimProject, String codBuilding) throws Exception {
		String cmisBasePath = ConfigurationProperties.getInstance().getString("cmisBasePath");
		
		//recupero i record legati al codPimProject
		//non posso tenere tutti i byte[] in memoria in contemporanea
		def idDelList = services.queryService.executeQuery("select id_pim_deliverable from DATA_GW.GWC_CNT_PIM_DELIVERABLE where cod_01_project=#{map.codPimProject}", [codPimProject : codPimProject]);
		
		for(HashMap<String, Object> idDeliverable : idDelList){
			def deliverable = services.queryService.executeQuery("select * from DATA_GW.GWC_CNT_PIM_DELIVERABLE where id_pim_deliverable=#{map.id_pim_deliverable}", idDeliverable)[0];
			deliverable.put("cod_building", codBuilding);
			deliverable.put("cod_expectation", codPimProject);

			if(deliverable.cmis_deliverable_name!=null && deliverable.md5!=null ){
				//gestisco il widget cmis document
				String cmisAttributeName = "file_name";
				String fileNameWithExtension = deliverable.cmis_deliverable_name;
				String fileName = fileNameWithExtension.substring(0, fileNameWithExtension.lastIndexOf("."));
				
				byte[] file = deliverable.cmis_deliverable_file;
				File tempFile = File.createTempFile("temp", ".cmis", null);

				FileItem fileItem = new DiskFileItem(cmisAttributeName, null, false, fileNameWithExtension, 100000000, tempFile);
				OutputStream fos = fileItem.getOutputStream();
				ByteArrayInputStream bis = new ByteArrayInputStream(file);
				byte[] BYTEBUFF = new byte[4096];
				
				int len;
				while ((len = bis.read(BYTEBUFF)) > 0) {
					fos.write(BYTEBUFF, 0, len);
				}	
				fos.close();

				MultipartFile multipartFile = new CommonsMultipartFile(fileItem);
				deliverable.file_name = multipartFile;		
			}
	
			deliverable.remove("cmis_deliverable_file");

			if (deliverable.cmis_deliverable_path.startsWith("/")) deliverable.cmis_deliverable_path = deliverable.cmis_deliverable_path.substring(1);
			if (deliverable.cmis_deliverable_path.endsWith("/")) deliverable.cmis_deliverable_path = deliverable.cmis_deliverable_path.substring(0, deliverable.cmis_deliverable_path.length()-1);

			services.classService.insertClassRecord("aim_sch_exp_deliverable", deliverable);
			
			//CONTROLLO SE SONO PRESENTI ALLEGATI
			def idAttachList = services.queryService.executeQuery("select id_pim_del_attachment FROM DATA_GW.GWC_CNT_PIM_DEL_ATTACHMENT where cod_deliverable_full=#{map.cod_deliverable_full}", [cod_deliverable_full : deliverable.cod_deliverable_full]);

			// ELIMINO ALLEGATI
			String attachmentsPath = cmisBasePath + spRootFolderName + deliverable.cod_building + "/PIM/" + deliverable.cmis_deliverable_path + "/Allegati/";
			Folder attachmentsFolder = services.gwCmisService.getFolderByPath(attachmentsPath);
			if (attachmentsFolder != null) services.gwCmisService.deleteFolderTreeByPath(attachmentsPath, true); 		

			//gli allegati devono essere salvati solo nel cmis, senza passare per il db
			for(HashMap<String, Object> idAttach: idAttachList){
				def attachment = services.queryService.executeQuery("select * from DATA_GW.GWC_CNT_PIM_DEL_ATTACHMENT where id_pim_del_attachment=#{map.id_pim_del_attachment}", idAttach)[0];
				
				if (attachment.attachment_path.startsWith("/")) attachment.attachment_path = attachment.attachment_path.substring(1);
			
				Folder attachmentFolder = services.gwCmisService.createFoldersByCompletePath(cmisBasePath + spRootFolderName + deliverable.cod_building + "/PIM/", attachment.attachment_path);		
				String fileName = attachment.attachment_name;
				byte[] file = attachment.attachment_file;
				String mimeType = MimeTypes.getMIMEType(fileName);

				// utilizzo api gw per creare documento su sharepoint
				// NOTA: il parametro cmisEnableCache deve essere settato a false nel configuration.properties per il corretto funzionamento
				services.gwCmisService.createDocument(attachmentFolder.getPath(), fileName, new ByteArrayInputStream(file), file.length, mimeType, null);
			}
		}
	}

	public void insert2DModel(String codPimProject, HashMap<String, String> stucturesHM) throws Exception {
		//gestire un record alla volta a causa del campo contenente sdf
		def id2DModelList = services.queryService.executeQuery("select id_pim_2d_model from DATA_GW.GWC_CNT_PIM_2D_MODEL where cod_pim_project=#{map.codPimProject}", [codPimProject : codPimProject]);
		
		for(HashMap<String, Object> id2DModel : id2DModelList){
			//i record passati all'aim sono tutti drawing sicuramente caricati ed appartengono ad un 
			//modello federato as built, quindi i campi sono tutti popolati
			def model2D = services.queryService.executeQuery("select * from DATA_GW.GWC_CNT_PIM_2D_MODEL where id_pim_2d_model=#{map.id_pim_2d_model}", id2DModel)[0];
			
			//record su gwd_layout, gestire sdf e libero memoria
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.GWD_LAYOUT (layout_code, layout_label, layout_type, SDF) values (#{map.layout_code}, #{map.layout_label}, '2D', #{map.sdf_file})", model2D);
			model2D.remove("sdf_file");
		
			def pkLayout = services.queryService.executeQuery("select pk_layout from CDE_DATI_GW.GWD_LAYOUT where layout_code=#{map.layout_code}", model2D)[0].pk_layout;			
			model2D.fk_layout = pkLayout;
			
			//record su gwd_drawing_set
			model2D.map = "floorPlan";
			model2D.is_default = 1;
			def pkDrawingSet = Integer.parseInt(services.classService.insertClassRecord('gwd_drawing_set', model2D));
			
			//record su gwd_drawing, gestire campo geom_envelope: string -> geometry
			model2D.new_structure_code = stucturesHM.get(model2D.cod_mod_structure);
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.GWD_DRAWING (dwg_name, check_in_user, check_in_date, md5, comments, geom_envelope, file_size, fk_layout, structure_code, rev) " +
					"values (#{map.name_drawing}, #{map.drawing_user}, #{map.drawing_date_checkin}, #{map.drawing_md5}, #{map.drawing_description}, " +
					"geometry::STGeomFromText(#{map.drawing_geom_envelope}, 0), #{map.drawing_file_size}, #{map.fk_layout}, #{map.new_structure_code}, 1)", model2D);
			
			def pkDrawing = services.queryService.executeQuery("select pk_drawing from CDE_DATI_GW.GWD_DRAWING where dwg_name=#{map.name_drawing}", model2D)[0].pk_drawing;
			
			//record su gwd_r_draw_set_draw
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.gwd_r_draw_set_draw (fk_drawing, fk_drawing_set) values (#{map.pkDrawing}, #{map.pkDrawingSet})", [pkDrawing : pkDrawing, pkDrawingSet : pkDrawingSet]);

			//record su gwd_model_console
			model2D.id_model = pkDrawing;
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.gwd_model_console (id_model, model_type, structure_code, cod_fed_model) values (#{map.id_model}, '2D', #{map.new_structure_code}, #{map.cod_fed_model})", model2D);
		}
	}

	public void insert3DModel(String codPimProject, HashMap<String, String> stucturesHM) throws Exception {
		def map = [codPimProject : codPimProject];
		//gwd_layout: unico per progetto. non serve recuperare id
		services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.GWD_LAYOUT (layout_code, layout_label, layout_type) select distinct layout_code, layout_label, '3D' from DATA_GW.GWC_CNT_PIM_3D_MODEL where cod_pim_project=#{map.codPimProject}", map);
		
		//gwd_model_set: unico per progetto. serve recuperare id
		services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.GWD_MODEL_SET (model_set_code, model_set_label, layout_code, is_default, gwm_scene_name) select distinct model_set_code, model_set_label, layout_code, 1, 'BimData' from DATA_GW.GWC_CNT_PIM_3D_MODEL where cod_pim_project=#{map.codPimProject}", map);
		def pkModelSet = services.queryService.executeQuery("select pk_model_set from CDE_DATI_GW.GWD_MODEL_SET ms left join DATA_GW.GWC_CNT_PIM_3D_MODEL mo on ms.model_set_code = mo.model_set_code where mo.cod_pim_project=#{map.codPimProject}", map)[0].pk_model_set;
		
		//gestire un record alla volta a causa delle tabelle di relazione basate sugli id e structure code diverso da quello passato da connettore
		def model3DList = services.queryService.executeQuery("select * from DATA_GW.GWC_CNT_PIM_3D_MODEL where cod_pim_project=#{map.codPimProject}", map);
		for(HashMap<String, Object> model3D : model3DList){
			//i record passati all'aim sono tutti drawing sicuramente caricati ed appartengono ad un 
			//modello federato as built, quindi i campi sono tutti popolati
			
			//record su gwd_bim_model
			model3D.new_structure_code = stucturesHM.get(model3D.cod_mod_structure);

			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.GWD_BIM_MODEL (name, check_in_user, check_in_date, md5, comments, json_obj, file_size, layout_code, structure_code, type, rev) "+
					"values (#{map.name_model}, #{map.model_user}, #{map.model_date_checkin}, #{map.model_md5}, #{map.model_comments}, "+
					"#{map.model_json_obj}, #{map.model_file_size}, #{map.layout_code}, #{map.new_structure_code}, #{map.cod_document_format}, 1)", model3D);
			
			def pkBimModel = services.queryService.executeQuery("select pk_Bim_model from CDE_DATI_GW.GWD_bim_model where name=#{map.name_model}", model3D)[0].pk_bim_model;
			
			//record su gwd_r_mod_set_bim
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.gwd_r_mod_set_bim (fk_bim_model, fk_model_set, default_visible) values (#{map.pkBimModel}, #{map.pkModelSet}, 0)", [pkBimModel : pkBimModel, pkModelSet : pkModelSet]);
			
			//record su gwd_model_console
			model3D.id_model = pkBimModel;
			services.queryService.executeQuery("INSERT INTO CDE_DATI_GW.gwd_model_console (id_model, model_type, structure_code, cod_fed_model) values (#{map.id_model}, '3D', #{map.new_structure_code}, #{map.cod_fed_model})", model3D);
		}
	}

	public void insertPtsFile(String codPimProject) throws Exception {		
		//tabella pts contiene lo zip con i file da importare su mongodb
		def map = [codPimProject : codPimProject];
		def ptsFileNameList = services.queryService.executeQuery("select distinct cod_deliverable_full from DATA_GW.GWC_CNT_PIM_DELIVERABLE " +
			"where cod_01_project=#{map.codPimProject} and deliverable_type='mod' and cod_format_document = 'pts'", map);

		for(HashMap<String, Object> ptsFileName : ptsFileNameList) {		
			//ogni record ha nome bim model e file zippato su varbinary
			String schema = "DATA_GW";
			String className = "GWC_CNT_PIM_PTS_FILE";
			String fileColumnName = "pts_file";
			String nameColumnName = "name_bim_model";
			String bimModelName = ptsFileName.cod_deliverable_full;
			def response = services.mongoDataTransmissionService.importPTSFromSql(schema, className, fileColumnName, nameColumnName, bimModelName);

			if(!response.isSuccess()) throw new Exception(response.getDescription());		
		}
	}

	public void insertIfcFile(String codPimProject) throws Exception {
		//tabella pts contiene lo zip con i file da importare su mongodb
		def map = [codPimProject : codPimProject];
		def fileIfcNameList = services.queryService.executeQuery("select distinct cod_deliverable_full from DATA_GW.GWC_CNT_PIM_DELIVERABLE " +
			"where cod_01_project=#{map.codPimProject} and deliverable_type='mod' and cod_format_document = 'ifc'", map);
		
		for(HashMap<String, Object> bimModelName : fileIfcNameList) {			
			//recupero pk bim model  e layout code (prefisso collezioni su mongodb) dal nome
			def bimModelRes = services.queryService.executeQuery("select pk_bim_model, layout_code from CDE_DATI_GW.GWD_BIM_MODEL where name=#{map.cod_deliverable_full}", bimModelName)[0];

			if (bimModelRes != null) {
				String pkBimModel = bimModelRes.pk_bim_model;
				String layoutCode = bimModelRes.layout_code;

				//il layout è stato creato in questa procedura => le collezione su MongoDB non esistono
				//creo gli indici per le nuove collezioni
				services.umMongoDBService.createAllMongoIndex(layoutCode);
				
				//recupero tutti gli id dei record sulla tabella GWC_CNT_PIM_MONGO_COLLECTION associati a mongo db
				def idPimMongoCollectionList = services.queryService.executeQuery("select id_pim_mongo_collection from DATA_GW.GWC_CNT_PIM_MONGO_COLLECTION where name_bim_model=#{map.cod_deliverable_full}", bimModelName);
				for(HashMap<String, Object> idPimMongoCollection : idPimMongoCollectionList){
					//per ogni id della lista recupero tutto il record
					def ifcRecord = services.queryService.executeQuery("select * from DATA_GW.GWC_CNT_PIM_MONGO_COLLECTION where id_pim_mongo_collection=#{map.id_pim_mongo_collection}", idPimMongoCollection)[0];

					//utilizzo il metodo GW per salvare su MongoDB i file contenuti nel record
					def response = services.mongoDataTransmissionService.importIntoMongoCollection(layoutCode, pkBimModel, ifcRecord);
					
					if(!response.isSuccess()) throw new Exception(response.getDescription());
				}	
			}	
		}
	}
}
