//user:    MPE
//date:    03/01/2021
//ver:     4.4.x
//project: AIM - SUPERBONUS
//type:    function trigger
//class:   -
//note:    groovy richiamato da aim_content_change_status_trigger.groovy per la gestione delle revisioni
//         modificato rispetto all'originale AIM per lo spostamento della gestione della track approvativa (dal filtro al contenuto)
//         modificato rispetto all'originale AIM per il popolamento della tabella delle forme delle schede digitali


import org.apache.commons.lang.StringUtils;
import java.nio.charset.StandardCharsets;
import com.geowebframework.dataservice.CaseInsensitiveHashMap;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import oracle.sql.BLOB;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import com.geowebframework.dataservice.ConfigurationProperties;
import com.geowebframework.transfer.objects.webclient.GwBeanDocument; 
import org.springframework.context.i18n.LocaleContextHolder;

// nel groovy chiamante, indicare class e nome del groovy corrente

class aim_RevisionGenericFunction {
	
	// definizione per consentire il salvataggio dei log
    private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger("com.geowebframework.groovy");
    
	// definizione per poter effettuare il richiamo del groovy corrente da altro groovy
	def services;
	void init(s) {
		 services=s;
	}
	 
	// RevisionData --> valori provenienti dal contenuto di origine/settati di default
	// Area --> area di competenza

	public Boolean creaRevisione (HashMap<String,Object> RevisionData, String Area)
	{

		//FISSO IL CODICE DEL CONTENUTO DI ORIGINE
		def cod_content_orig = RevisionData.cod_content;
		log.info("codice del contenuto di origine: " + cod_content_orig);

		// DEFINISCO I DATI PER IL POPOLAMENTO DEL CONTENUTO REVISIONATO

		// loggo i dati del contenuto di origine
		log.info("dati contenuto di origine: " + RevisionData);
		log.info("area del contenuto di origine: " + Area);
		// RevisionData.single_insert = 1; DA CAPIRE XCHE' ERA MESSO A 1, DI DEFAULT SONO 0
		// assegno i valori di default al contenuto revisionato
		RevisionData.from_revision = 1;
		RevisionData.is_sch_complete = 0;
		RevisionData.send_to_risk = 0;
		RevisionData.is_send_to_risk = 0;
		RevisionData.content_area = Area;
		// se il contenuto è una scheda digitale, is_uploaded = 1, in caso contrario is_uploaded = 0
		if (RevisionData.cod_class_type=='SCH'){RevisionData.is_uploaded = 1}
		else if (RevisionData.cod_class_type!='SCH'){RevisionData.is_uploaded = 0};
		// incremento il numero della revisione
		RevisionData.rev_content = RevisionData.rev_content + 1;	
		// data di creazione del contenuto revisionato
		RevisionData.creation_date = new Date();
		// calcolo il codice del contenuto revisionato (modificato il numero della revisione)
		RevisionData.cod_content = RevisionData.cod_building +'-'+ StringUtils.leftPad(RevisionData.num_content.toString(), 6, "0") + "-"+StringUtils.leftPad(RevisionData.rev_content.toString(), 2, "0");
		log.info("dati contenuto revisionato: "+RevisionData);
		// aggiungo alla mappa della revisione il codice di origine
		RevisionData.cod_content_orig = cod_content_orig;
		log.info("codice contenuto di origine: " + RevisionData.cod_content_orig);




		// RECUPERO LO STATO APPROVATIVO DA ASSEGNARE ALLA REVISIONE
		
		// definisco classificazione del contenuto
		def cod_class_subcat=RevisionData.cod_class_subcat;
		log.info("codice della classificazione del contenuto: " + cod_class_subcat);
		//recupero codice della track approvativa per la classificazione del contenuto
		def cod_track = services.queryService.executeQuery("SELECT cod_track FROM aim_folder_type_content WHERE cod_class_subcat='" + cod_class_subcat + "'",null)[0].cod_track;
		log.info("codice track: " + cod_track);
		// recupero il codice del primo stato approvativo della track
		def rec_status_app = services.queryService.executeQuery("SELECT cod_track,ord_track_status,uk_track_status FROM aim_track_status WHERE cod_track='" + cod_track + "' ORDER BY cod_track,ord_track_status",null)[0];
		log.info("record dello stato approvativo di interesse: " + rec_status_app);
		// aggiungo lo stato approvativo ai dati del contenuto revisionato
		RevisionData.status_approval = rec_status_app.uk_track_status;
		log.info("stato approvativo: " + RevisionData.status_approval);	
	



		// RECUPERO TIPO DI DATABASE (X SCELTA DELLA QUERY DI INSERT)
		def db_type = services.queryService.executeQuery("SELECT param_value as db_type FROM aim_product_setting WHERE param_name='Database' AND status='Y'",null)[0].db_type;
		log.info("tipo di database: " + db_type);		

		// caso di database = Postgres (chiave primaria record da sequence)
		if (db_type=='Postgres'){
			// INSERIMENTO REVISIONE
			//definisco query per inserimento della revision nella tabella AIM_CONTENT
			def insertRevision = "INSERT INTO AIM_CONTENT (id_content,cod_content, cod_building, num_content, rev_content, cod_function, cod_position, content_class, cod_class_arc, cod_class_cat,cod_class_subcat, cod_class_type, author, internal_referent, descr_content, creation_date, content_area, status_approval, content_note,tenant_code, is_uploaded, single_insert, usergroup, cod_action_type, role_action, from_revision, is_blocked, is_invalid, is_approved, class_name,is_sch_complete,is_mandatory,is_risk,cod_permission_type,send_to_risk,is_send_to_risk)";
			insertRevision+="VALUES (nextval('seq_fb'),#{map.cod_content},#{map.cod_building},#{map.num_content},#{map.rev_content},#{map.cod_function},#{map.cod_position},#{map.content_class},#{map.cod_class_arc},#{map.cod_class_cat},#{map.cod_class_subcat},#{map.cod_class_type},#{map.author},#{map.internal_referent},#{map.descr_content},#{map.creation_date},#{map.content_area},#{map.status_approval},#{map.content_note},#{map.tenant_code},#{map.is_uploaded},#{map.single_insert},#{map.usergroup},#{map.cod_action_type},#{map.role_action},#{map.from_revision},#{map.is_blocked},#{map.is_invalid},#{map.is_approved},#{map.class_name},#{map.is_sch_complete},#{map.is_mandatory},#{map.is_risk},#{map.cod_permission_type},#{map.send_to_risk},#{map.is_send_to_risk})";
			// eseguo query di inserimento della revisione nella tabella AIM_CONTENT
			def ins_rev = services.queryService.executeQuery(insertRevision,RevisionData);			

			// INSERIMENTO REVISIONE SU FILTRO DEI CONTENUTI
			// recupero i filtri di interesse
			def classFilterAll = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER WHERE  ((cod_class_filter=#{map.cod_class_arc} or cod_class_filter=#{map.cod_class_cat} or cod_class_filter is null) and  (cod_content_type is null or cod_content_type=#{map.cod_class_type}))",RevisionData);
			// ciclo l'inserimento
			for(int q=0;q<classFilterAll.size();q++){
				classFilterAll[q].cod_content=RevisionData.cod_content;	
				//predispongo l'inserimento dei record nella tabella AIM_BIM_FILTER_R_CONTENT
				def ContIns = "INSERT INTO aim_bim_filter_r_content (id_filter_r_content,cod_bim_filter, cod_content)";
				ContIns+=" VALUES ";
				ContIns+="(nextval('seq_fb'),#{map.cod_bim_filter},#{map.cod_content})";
				def ins_cont = services.queryService.executeQuery(ContIns,classFilterAll[q]);			
				};

			// INSERISCO REVISIONE NELLE TABELLE DI APPOGGIO DELLE FORME (DOC + GAL + SCH)

			//caso di forma del contenuto = DOC
			if(RevisionData.cod_class_type.equals('DOC')){
				RevisionData.file_path = RevisionData.cod_building + "/" + "DOC/" + RevisionData.cod_content;
				// definisco query di inserimento nella tabella delle forme
				def insertDoc = "INSERT INTO aim_content_doc (id_doc,cod_content, file_path, tenant_code) VALUES (nextval('seq_fb'),#{map.cod_content},#{map.file_path},#{map.tenant_code})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertDoc,RevisionData);
			};
			// caso di forma del contenuto = GAL
			if (RevisionData.cod_class_type.equals('GAL')){
				RevisionData.file_path = buildingCode + "/GAL/" + cod_content;
				// definisco query di inserimento nella tabella delle forme
				def insertGAL = "INSERT INTO aim_content_gal (id_gal,cod_content, file_path) VALUES (nextval('seq_fb'),#{map.cod_content}, #{map.file_path})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertGAL, RevisionData);			
				};
			// caso di forma del contenuto = SCH
			if (RevisionData.cod_class_type.equals('SCH')){
				// recupero chiave della classe della scheda digitale e colonna contenuto
				def info_sch = services.queryService.executeQuery("SELECT * FROM aim_content_sch WHERE cod_content=#{map.cod_content_orig}",RevisionData)[0];
				log.info("info scheda digitale di origine: " + info_sch);				
				// aggiungo chiave della classe della scheda digitale e colonna contenuto ai dati del contenuto revisionato 
				RevisionData.fk_sch_class = info_sch.fk_sch_class;
				log.info("classe scheda digitale: " + RevisionData.fk_sch_class);					
				RevisionData.sch_code_column = info_sch.sch_code_column;
				log.info("colonna contenuto: " + RevisionData.sch_code_column);
				// definisco query di inserimento nella tabella delle forme
				def insertSCH = "INSERT INTO aim_content_sch (id_sch,cod_content,fk_sch_class,sch_code_column,sch_code,author,creation_date) VALUES (nextval('seq_fb'),#{map.cod_content},#{map.fk_sch_class},#{map.sch_code_column},#{map.cod_content},#{map.author},#{map.creation_date})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertSCH, RevisionData);			
				};	


			// COPIO IL RECORD DELLA SCHEDA DIGITALE SULLA REVISIONE (PER CORREZIONE DA PARTE DELL'UTENTE)

			if (RevisionData.cod_class_type.equals('SCH')){
				
				//////// COPIO SCHEDA DIGITALE INTERVENTO (TESTATA + RIGHE)
			
				// definisco query di inserimento (testata)
				def ins_interv = "INSERT INTO aim_sch_scheda_intervento (id_scheda_intervento,cod_building,cod_content,is_sch_complete)";
				ins_interv+= "(SELECT nextval('seq_fb'),cod_building,#{map.cod_content},0 FROM aim_sch_scheda_intervento WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale intervento revisionato: " + ins_interv);
				// eseguo query di inserimento (testata)
				def ins_interv_exe = services.queryService.executeQuery(ins_interv, RevisionData);
				
				// definisco la query di inserimento (righe)
				def ins_interv_ls = "INSERT INTO aim_sch_scheda_intervento_ls (id_scheda_intervento_ls,cod_content,prog_tipo_intervento,tipo_intervento,riferimento_normativo,descr_intervento,num_unita_abitative,costo_tot_intervento,classe_intervento,descr_massimale)";
				ins_interv_ls+= "(SELECT   nextval('seq_fb'),#{map.cod_content},prog_tipo_intervento,tipo_intervento,riferimento_normativo,descr_intervento,num_unita_abitative,costo_tot_intervento,classe_intervento,descr_massimale FROM aim_sch_scheda_intervento_ls WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale intervento revisionato lista: " + ins_interv_ls);
				// eseguo query di inserimento (righe)
				def ins_interv_ls_exe = services.queryService.executeQuery(ins_interv_ls, RevisionData);				




				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO A (testata)
				
				// definisco query di inserimento
				def ins_quadro_a = "INSERT INTO aim_sch_fasc_fabbricato_qa (id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qa_01_complesso,qa_01_num_fabbricati,qa_01_dest_uso_prevalente,qa_01_anno_costruzione,qa_02_periodo_storico,qa_02_periodo_storico_note,qa_02_vincoli,qa_02_superfetazioni,qa_02_superfetazioni_note,qa_02_sopraelevazioni,qa_02_sopraelevazioni_note,qa_02_modifiche_statiche,qa_02_modifiche_statiche_note,qa_03_posizione_fabbricato,qa_03_autonomia_fabbricato,qa_03_autonomia_fabbricato_note,qa_04_num_scale,qa_04_cortile_interno,qa_04_num_piani_ft,qa_04_num_piani_et,qa_04_superficie_scoperta,qa_04_superficie_coperta,qa_04_altezza_massima,qa_04_altezza_minima,qa_04_volume_tot_ft,qa_04_volume_tot_et,qa_04_pertinenze_sup_coperta,qa_04_pertinenze_sup_scoperta,qa_04_pertinenze_note,qa_05_ct_fabbricato_riportato,qa_05_ct_foglio,qa_05_ct_allegato,qa_05_ct_particella,qa_05_ct_estratto_mappa,qa_06_cu_denunciato,qa_06_cu_data_denuncia,qa_06_cu_numero_denuncia,qa_06_cu_foglio,qa_06_cu_particelle,qa_08_licenza_abitabilita,qa_08_data_abitabilita,qa_08_numero_abitabilita,qa_08_dichiarazione_dl,qa_08_conc_edilizia_orig,qa_08_data_conc_edil_orig,qa_08_numero_conc_edil_orig,qa_08_conc_edilizia_var_1,qa_08_data_conc_edil_var_1,qa_08_numero_conc_edil_var_1,qa_08_conc_edilizia_var_2,qa_08_data_conc_edil_var_2,qa_08_numero_conc_edil_var_2,qa_08_conc_sanatoria_47_85_1,qa_08_data_conc_san_47_85_1,qa_08_numero_conc_san_47_85_1,qa_08_conc_sanatoria_47_85_2,qa_08_data_conc_san_47_85_2,qa_08_numero_conc_san_47_85_2,qa_08_conc_sanatoria_724_94,qa_08_conc_san_724_94_note,qa_08_autor_edilizia,qa_08_data_autor_edilizia,qa_08_dia,qa_08_data_dia,qa_08_data_fine_lavori_dia,qa_08_conf_impianto_nome_1,qa_08_conf_impianto_1,qa_08_data_conf_impianto_1,qa_08_numero_conf_impianto_1,qa_08_conf_impianto_nome_2,qa_08_conf_impianto_2,qa_08_data_conf_impianto_2,qa_08_numero_conf_impianto_2,qa_08_conf_impianto_nome_3,qa_08_conf_impianto_3,qa_08_data_conf_impianto_3,qa_08_numero_conf_impianto_3,qa_08_conf_impianto_nome_4,qa_08_conf_impianto_4,qa_08_data_conf_impianto_4,qa_08_numero_conf_impianto_4,qa_08_collaudi_statici,qa_08_data_collaudi_statici,qa_08_collaudi_statici_note,qa_08_previsto_cpi,qa_08_presenza_nop,qa_08_data_nop,qa_08_altre_attivita_dm,qa_08_altre_attivita_dm_note,qa_08_altre_attivita_dm_cpi,qa_08_altre_att_dm_data_cpi,qa_08_altre_att_dm_numero_cpi,qa_08_altre_att_dm_scad_cpi,qa_08_altre_attivita_dm_nop,qa_08_altre_att_dm_data_nop,qa_08_altre_att_dm_numero_nop,qa_08_altre_att_dm_scad_nop,qa_09_professionisti,qa_10_imprese,qa_08_tolleranza_abusi_edilizi,qa_08_data_conc_san_724_94,qa_08_autor_edilizia_note,qa_08_presenza_cpi,qa_08_data_cpi)";
				ins_quadro_a+= "(SELECT nextval('seq_fb'),#{map.cod_content},cod_building,0,qa_01_complesso,qa_01_num_fabbricati,qa_01_dest_uso_prevalente,qa_01_anno_costruzione,qa_02_periodo_storico,qa_02_periodo_storico_note,qa_02_vincoli,qa_02_superfetazioni,qa_02_superfetazioni_note,qa_02_sopraelevazioni,qa_02_sopraelevazioni_note,qa_02_modifiche_statiche,qa_02_modifiche_statiche_note,qa_03_posizione_fabbricato,qa_03_autonomia_fabbricato,qa_03_autonomia_fabbricato_note,qa_04_num_scale,qa_04_cortile_interno,qa_04_num_piani_ft,qa_04_num_piani_et,qa_04_superficie_scoperta,qa_04_superficie_coperta,qa_04_altezza_massima,qa_04_altezza_minima,qa_04_volume_tot_ft,qa_04_volume_tot_et,qa_04_pertinenze_sup_coperta,qa_04_pertinenze_sup_scoperta,qa_04_pertinenze_note,qa_05_ct_fabbricato_riportato,qa_05_ct_foglio,qa_05_ct_allegato,qa_05_ct_particella,qa_05_ct_estratto_mappa,qa_06_cu_denunciato,qa_06_cu_data_denuncia,qa_06_cu_numero_denuncia,qa_06_cu_foglio,qa_06_cu_particelle,qa_08_licenza_abitabilita,qa_08_data_abitabilita,qa_08_numero_abitabilita,qa_08_dichiarazione_dl,qa_08_conc_edilizia_orig,qa_08_data_conc_edil_orig,qa_08_numero_conc_edil_orig,qa_08_conc_edilizia_var_1,qa_08_data_conc_edil_var_1,qa_08_numero_conc_edil_var_1,qa_08_conc_edilizia_var_2,qa_08_data_conc_edil_var_2,qa_08_numero_conc_edil_var_2,qa_08_conc_sanatoria_47_85_1,qa_08_data_conc_san_47_85_1,qa_08_numero_conc_san_47_85_1,qa_08_conc_sanatoria_47_85_2,qa_08_data_conc_san_47_85_2,qa_08_numero_conc_san_47_85_2,qa_08_conc_sanatoria_724_94,qa_08_conc_san_724_94_note,qa_08_autor_edilizia,qa_08_data_autor_edilizia,qa_08_dia,qa_08_data_dia,qa_08_data_fine_lavori_dia,qa_08_conf_impianto_nome_1,qa_08_conf_impianto_1,qa_08_data_conf_impianto_1,qa_08_numero_conf_impianto_1,qa_08_conf_impianto_nome_2,qa_08_conf_impianto_2,qa_08_data_conf_impianto_2,qa_08_numero_conf_impianto_2,qa_08_conf_impianto_nome_3,qa_08_conf_impianto_3,qa_08_data_conf_impianto_3,qa_08_numero_conf_impianto_3,qa_08_conf_impianto_nome_4,qa_08_conf_impianto_4,qa_08_data_conf_impianto_4,qa_08_numero_conf_impianto_4,qa_08_collaudi_statici,qa_08_data_collaudi_statici,qa_08_collaudi_statici_note,qa_08_previsto_cpi,qa_08_presenza_nop,qa_08_data_nop,qa_08_altre_attivita_dm,qa_08_altre_attivita_dm_note,qa_08_altre_attivita_dm_cpi,qa_08_altre_att_dm_data_cpi,qa_08_altre_att_dm_numero_cpi,qa_08_altre_att_dm_scad_cpi,qa_08_altre_attivita_dm_nop,qa_08_altre_att_dm_data_nop,qa_08_altre_att_dm_numero_nop,qa_08_altre_att_dm_scad_nop,qa_09_professionisti,qa_10_imprese,qa_08_tolleranza_abusi_edilizi,qa_08_data_conc_san_724_94,qa_08_autor_edilizia_note,qa_08_presenza_cpi,qa_08_data_cpi FROM aim_sch_fasc_fabbricato_qa WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro a revisionato: " + ins_quadro_a);
				// eseguo query di inserimento (testata)
				def ins_quadro_a_exe = services.queryService.executeQuery(ins_quadro_a, RevisionData);

				// definisco la query di inserimento (righe)
				def ins_quadro_a_ui = "INSERT INTO aim_sch_fasc_fabbricato_qa_ui (id_fasc_fabbricato_qa_ui,cod_content,pro_ui,num_foglio,num_particella,num_subalterno,destinazione_uso,conforme,scala,piano,interno)";
				ins_quadro_a_ui+= "(SELECT nextval('seq_fb'),#{map.cod_content},pro_ui,num_foglio,num_particella,num_subalterno,destinazione_uso,conforme,scala,piano,interno FROM aim_sch_fasc_fabbricato_qa_ui WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale intervento quadro a revisionato lista: " + ins_quadro_a_ui);
				// eseguo query di inserimento (righe)
				def ins_quadro_a_ui_exe = services.queryService.executeQuery(ins_quadro_a_ui, RevisionData);	
				


				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO B
				
				// definisco query di inserimento
				def ins_quadro_b = "INSERT INTO aim_sch_fasc_fabbricato_qb (id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qb_doc_tecnica_proprieta,qb_progetto_orig,qb_progetto_orig_data,qb_progetto_orig_elab,qb_progetto_var,qb_progetto_var_data,qb_progetto_var_elab,qb_stato_attuale,qb_stato_attuale_elab,qb_disegni_tecnici_stato,qb_disegni_tecnici_note,qb_relazione_geologica,qb_relazione_geotecnica,qb_progetto_strutturale,qb_progetto_strutturale_elab,qb_relazione_agroforestale,qb_relazione_agroforestale_note)";
				ins_quadro_b+= "(SELECT nextval('seq_fb'),#{map.cod_content},cod_building,0,qb_doc_tecnica_proprieta,qb_progetto_orig,qb_progetto_orig_data,qb_progetto_orig_elab,qb_progetto_var,qb_progetto_var_data,qb_progetto_var_elab,qb_stato_attuale,qb_stato_attuale_elab,qb_disegni_tecnici_stato,qb_disegni_tecnici_note,qb_relazione_geologica,qb_relazione_geotecnica,qb_progetto_strutturale,qb_progetto_strutturale_elab,qb_relazione_agroforestale,qb_relazione_agroforestale_note FROM aim_sch_fasc_fabbricato_qb WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro b revisionato: " + ins_quadro_b);
				// eseguo query di inserimento 
				def ins_quadro_b_exe = services.queryService.executeQuery(ins_quadro_b, RevisionData);


				
				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO C
				// definisco query di inserimento (testata)
				def ins_quadro_c = "INSERT INTO aim_sch_fasc_fabbricato_qc (id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qc_01_descr_stato_luoghi,qc_02_relaz_fotografica,qc_03_servitu,qc_03_servitu_telefono,qc_03_servitu_elettrico,qc_03_servitu_gas,qc_03_servitu_antenne,qc_03_servitu_ferrovie,qc_03_servitu_passaggio,qc_03_servitu_altro,qc_03_servitu_altro_note,qc_04_giacitura_piano,qc_04_giacitura_declivio,qc_04_giacitura_scosceso,qc_04_giacitura_piani_scoscesi,qc_04_giacitura_altro,qc_04_giacitura_terreno_note,qc_05_corsi_acqua_fossi,qc_05_corsi_acqua_sorgenti,qc_05_corsi_acqua_fiumi,qc_05_corsi_acqua_altro,qc_05_corsi_acqua_no,qc_05_corsi_acqua_note,qc_06_alberi_af_presenti,qc_06_alberi_af_non_presenti,qc_06_alberi_af_adiacenti,qc_06_alberi_af_non_adiacenti,qc_06_alberi_af_note,qc_07_cons_prosp_fin_descr,qc_07_cons_prosp_fin_giudizio,qc_09_verifica_statica,qc_09_verifica_statica_data,qc_09_verifica_statica_int,qc_09_lesioni_struttura,qc_09_lesioni_epoca_comparsa,qc_09_lesioni_mezzi_indagine,qc_09_lesioni_mezzi_indagine_note,qc_09_forme_dissesto,qc_09_sv_lesioni_struttura_vert,qc_09_sv_lesioni_superficiali,qc_09_sv_lesioni_profonde,qc_09_sv_lesioni_passanti,qc_09_sv_andamento_lesioni,qc_09_sv_lesioni_architravi,qc_09_sv_manufatti_degradati,qc_09_sv_rilievo_quadro_fessurativo,qc_09_sv_indagine_specifiche,qc_09_sv_indagine_specifiche_descr,qc_09_so_lesioni_struttura_oriz,qc_09_so_lesioni_superficiali,qc_09_so_lesioni_profonde,qc_09_so_lesioni_passanti,qc_09_so_andamento_lesioni,qc_09_so_manufatti_degradati,qc_09_so_rilievo_quadro_fessurativo,qc_09_so_indagine_specifiche,qc_09_so_indagine_specifiche_descr,qc_09_cause_degrado,qc_09_modifiche_impianto_statico,qc_09_modifiche_impianto_statico_descr,qc_10_lavori_riordino_descr,qc_09_sv_distacchi_murari,qc_09_so_avvallamenti,qc_09_so_pavimenti_sconnessi)";
				ins_quadro_c+= "(SELECT  nextval('seq_fb'),#{map.cod_content},cod_building,0,qc_01_descr_stato_luoghi,qc_02_relaz_fotografica,qc_03_servitu,qc_03_servitu_telefono,qc_03_servitu_elettrico,qc_03_servitu_gas,qc_03_servitu_antenne,qc_03_servitu_ferrovie,qc_03_servitu_passaggio,qc_03_servitu_altro,qc_03_servitu_altro_note,qc_04_giacitura_piano,qc_04_giacitura_declivio,qc_04_giacitura_scosceso,qc_04_giacitura_piani_scoscesi,qc_04_giacitura_altro,qc_04_giacitura_terreno_note,qc_05_corsi_acqua_fossi,qc_05_corsi_acqua_sorgenti,qc_05_corsi_acqua_fiumi,qc_05_corsi_acqua_altro,qc_05_corsi_acqua_no,qc_05_corsi_acqua_note,qc_06_alberi_af_presenti,qc_06_alberi_af_non_presenti,qc_06_alberi_af_adiacenti,qc_06_alberi_af_non_adiacenti,qc_06_alberi_af_note,qc_07_cons_prosp_fin_descr,qc_07_cons_prosp_fin_giudizio,qc_09_verifica_statica,qc_09_verifica_statica_data,qc_09_verifica_statica_int,qc_09_lesioni_struttura,qc_09_lesioni_epoca_comparsa,qc_09_lesioni_mezzi_indagine,qc_09_lesioni_mezzi_indagine_note,qc_09_forme_dissesto,qc_09_sv_lesioni_struttura_vert,qc_09_sv_lesioni_superficiali,qc_09_sv_lesioni_profonde,qc_09_sv_lesioni_passanti,qc_09_sv_andamento_lesioni,qc_09_sv_lesioni_architravi,qc_09_sv_manufatti_degradati,qc_09_sv_rilievo_quadro_fessurativo,qc_09_sv_indagine_specifiche,qc_09_sv_indagine_specifiche_descr,qc_09_so_lesioni_struttura_oriz,qc_09_so_lesioni_superficiali,qc_09_so_lesioni_profonde,qc_09_so_lesioni_passanti,qc_09_so_andamento_lesioni,qc_09_so_manufatti_degradati,qc_09_so_rilievo_quadro_fessurativo,qc_09_so_indagine_specifiche,qc_09_so_indagine_specifiche_descr,qc_09_cause_degrado,qc_09_modifiche_impianto_statico,qc_09_modifiche_impianto_statico_descr,qc_10_lavori_riordino_descr,qc_09_sv_distacchi_murari,qc_09_so_avvallamenti,qc_09_so_pavimenti_sconnessi FROM aim_sch_fasc_fabbricato_qc WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro c revisionato: " + ins_quadro_c);
				// eseguo query di inserimento (testata)
				def ins_quadro_c_exe = services.queryService.executeQuery(ins_quadro_c, RevisionData);
				
				//definisco la query di inserimento (righe)
				def ins_quadro_c_con="INSERT INTO aim_sch_fasc_fabbricato_qc_con(id_fasc_fabbricato_qc_con,cod_content,categoria,tipologia,stato_buono,stato_medio,stato_cattivo,ord)";
				ins_quadro_c_con+="(SELECT nextval('seq_fb'),#{map.cod_content},categoria,tipologia,stato_buono,stato_medio,stato_cattivo,ord FROM aim_sch_fasc_fabbricato_qc_con WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro c revisionato lista:"+ins_quadro_c_con);
				//eseguo query di inserimento (righe)
				def ins_quadro_c_con_exe=services.queryService.executeQuery(ins_quadro_c_con,RevisionData);					
				



				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO D 
				//definisco query di inserimento (testata)
				def ins_quadro_d="INSERT INTO aim_sch_fasc_fabbricato_qd(id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qd_01_fognario_allaccio_pubblico,qd_01_fognario_smaltimento_terreno,qd_01_idrico_sanitario,qd_01_idrico_antincendio,qd_01_acqua_calda_centrallizata,qd_01_elettrico,qd_01_prot_scariche_atmosferiche,qd_01_messa_terra,qd_01_telefonico,qd_01_citofonico,qd_01_videocitofonico,qd_01_telecomunicazioni,qd_01_trasmissione_dati,qd_01_allarme_tvcc,qd_01_antenna_tv_centrallizata,qd_01_riscaldamento_centralizzato,qd_01_riscaldamento_autonomo,qd_01_condizionamento_centralizzato,qd_01_condizionamento_autonomo,qd_01_gas_allaccio_pubblico,qd_01_gas_deposito_autonomo,qd_01_ascensore,qd_01_montacarichi,qd_01_scale_mobili,qd_01_prod_fonti_energ_alter,qd_01_altro_descr,qd_01_impianti_note,qd_02_fognatura_comunale,qd_02_dispersione_fossa_biologica,qd_02_dispersione_subirragazione,qd_02_dispersione_evapotraspirazione,qd_02_dispersione_a_perdere,qd_02_dispersione_altro,qd_02_impianto_depurazione,qd_02_impianto_depurazione_aut,qd_02_dep_cons_manut_doc,qd_02_dep_cons_manut_ispezione,qd_03_idr_cons_manut_doc,qd_03_idr_cons_manut_ispezione,qd_04_idranti_esterni,qd_04_idranti_esterni_num,qd_04_attacchi_uni_70,qd_04_attacchi_uni_70_num,qd_04_attacchi_uni_70_local,qd_04_attacchi_uni_45,qd_04_attacchi_uni_45_num,qd_04_attacchi_uni_45_local,qd_04_cassette_custodia,qd_04_tubazioni_fless,qd_04_tubazioni_fless_stato,qd_04_press_residua_bar,qd_04_portata_lt_min,qd_04_imp_antincendio_note)";
				ins_quadro_d+="(SELECT nextval('seq_fb'),#{map.cod_content},cod_building,0,qd_01_fognario_allaccio_pubblico,qd_01_fognario_smaltimento_terreno,qd_01_idrico_sanitario,qd_01_idrico_antincendio,qd_01_acqua_calda_centrallizata,qd_01_elettrico,qd_01_prot_scariche_atmosferiche,qd_01_messa_terra,qd_01_telefonico,qd_01_citofonico,qd_01_videocitofonico,qd_01_telecomunicazioni,qd_01_trasmissione_dati,qd_01_allarme_tvcc,qd_01_antenna_tv_centrallizata,qd_01_riscaldamento_centralizzato,qd_01_riscaldamento_autonomo,qd_01_condizionamento_centralizzato,qd_01_condizionamento_autonomo,qd_01_gas_allaccio_pubblico,qd_01_gas_deposito_autonomo,qd_01_ascensore,qd_01_montacarichi,qd_01_scale_mobili,qd_01_prod_fonti_energ_alter,qd_01_altro_descr,qd_01_impianti_note,qd_02_fognatura_comunale,qd_02_dispersione_fossa_biologica,qd_02_dispersione_subirragazione,qd_02_dispersione_evapotraspirazione,qd_02_dispersione_a_perdere,qd_02_dispersione_altro,qd_02_impianto_depurazione,qd_02_impianto_depurazione_aut,qd_02_dep_cons_manut_doc,qd_02_dep_cons_manut_ispezione,qd_03_idr_cons_manut_doc,qd_03_idr_cons_manut_ispezione,qd_04_idranti_esterni,qd_04_idranti_esterni_num,qd_04_attacchi_uni_70,qd_04_attacchi_uni_70_num,qd_04_attacchi_uni_70_local,qd_04_attacchi_uni_45,qd_04_attacchi_uni_45_num,qd_04_attacchi_uni_45_local,qd_04_cassette_custodia,qd_04_tubazioni_fless,qd_04_tubazioni_fless_stato,qd_04_press_residua_bar,qd_04_portata_lt_min,qd_04_imp_antincendio_note FROM aim_sch_fasc_fabbricato_qd WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro D revisionato:" + ins_quadro_d);
				//eseguo query di inserimento (testata)
				def ins_quadro_d_exe=services.queryService.executeQuery(ins_quadro_d,RevisionData);

				// definisco la query di inserimento (righe fgn)
				def ins_quadro_d_fgn = "INSERT INTO aim_sch_fasc_fabbricato_qd_fgn (id_fasc_fabbricato_qd_fgn,cod_content,tipologia,materiali_componenti,stato_buono,stato_medio,stato_cattivo,ord)";
				ins_quadro_d_fgn+= "(SELECT nextval('seq_fb'),#{map.cod_content},tipologia,materiali_componenti,stato_buono,stato_medio,stato_cattivo,ord FROM aim_sch_fasc_fabbricato_qd_fgn WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro D revisionato lista fgn: " + ins_quadro_d_fgn);
				// eseguo query di inserimento (righe fgn)
				def ins_quadro_d_fgn_exe = services.queryService.executeQuery(ins_quadro_d_fgn, RevisionData);	

				// definisco la query di inserimento (righe idr)
				def ins_quadro_d_idr = "INSERT INTO aim_sch_fasc_fabbricato_qd_idr (id_fasc_fabbricato_qd_idr,cod_content,tipologia,materiali_componenti,stato_buono,stato_medio,stato_cattivo,ord)";
				ins_quadro_d_idr+= "(SELECT nextval('seq_fb'),#{map.cod_content},tipologia,materiali_componenti,stato_buono,stato_medio,stato_cattivo,ord FROM aim_sch_fasc_fabbricato_qd_idr WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro d revisionato lista idr: " + ins_quadro_d_idr);
				// eseguo query di inserimento (righe)
				def ins_quadro_d_idr_exe = services.queryService.executeQuery(ins_quadro_d_idr, RevisionData);	


			
			
				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO E
				// definisco query di inserimento
				def ins_quadro_e = "INSERT INTO aim_sch_fasc_fabbricato_qe (id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qe_piano_sicurezza_dlgs_626_94,qe_piano_emergenza_dm_10031998,qe_sicurezza_note)";
				ins_quadro_e+= "(SELECT nextval('seq_fb'),#{map.cod_content},cod_building,0,qe_piano_sicurezza_dlgs_626_94,qe_piano_emergenza_dm_10031998,qe_sicurezza_note FROM aim_sch_fasc_fabbricato_qe WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro E revisionato: " + ins_quadro_e);
				// eseguo query di inserimento 
				def ins_quadro_e_exe = services.queryService.executeQuery(ins_quadro_e, RevisionData);




				//////// COPIO SCHEDA DIGITALE FASCICOLO FABBRICATO - QUADRO F
				// definisco query di inserimento
				def ins_quadro_f = "INSERT INTO aim_sch_fasc_fabbricato_qf  (id_fasc_fabbricato,cod_content,cod_building,is_sch_complete,qf_compilato_quadro_a01,qf_compilato_quadro_a02,qf_compilato_quadro_a03,qf_compilato_quadro_a04,qf_compilato_quadro_a05,qf_compilato_quadro_a06,qf_compilato_quadro_a07,qf_compilato_quadro_a08,qf_compilato_quadro_a09,qf_compilato_quadro_a10,qf_compilato_quadro_b,qf_compilato_quadro_c01,qf_compilato_quadro_c02,qf_compilato_quadro_c03,qf_compilato_quadro_c04,qf_compilato_quadro_c05,qf_compilato_quadro_c06,qf_compilato_quadro_c07,qf_compilato_quadro_c08,qf_compilato_quadro_c09,qf_compilato_quadro_c10,qf_compilato_quadro_d01,qf_compilato_quadro_d02,qf_compilato_quadro_d03,qf_compilato_quadro_d04,qf_compilato_quadro_e,qf_compilato_quadro_f,qf_compilazione_note,qf_doc_allegati,qf_note_aggiuntive,qf_sopralluogo_01_data,qf_sopralluogo_01_incaricato,qf_sopralluogo_02_data,qf_sopralluogo_02_incaricato,qf_sopralluogo_03_data,qf_sopralluogo_03_incaricato,qf_sopralluogo_04_data,qf_sopralluogo_04_incaricato)";
				ins_quadro_f+= "(SELECT nextval('seq_fb'),#{map.cod_content},cod_building,0,qf_compilato_quadro_a01,qf_compilato_quadro_a02,qf_compilato_quadro_a03,qf_compilato_quadro_a04,qf_compilato_quadro_a05,qf_compilato_quadro_a06,qf_compilato_quadro_a07,qf_compilato_quadro_a08,qf_compilato_quadro_a09,qf_compilato_quadro_a10,qf_compilato_quadro_b,qf_compilato_quadro_c01,qf_compilato_quadro_c02,qf_compilato_quadro_c03,qf_compilato_quadro_c04,qf_compilato_quadro_c05,qf_compilato_quadro_c06,qf_compilato_quadro_c07,qf_compilato_quadro_c08,qf_compilato_quadro_c09,qf_compilato_quadro_c10,qf_compilato_quadro_d01,qf_compilato_quadro_d02,qf_compilato_quadro_d03,qf_compilato_quadro_d04,qf_compilato_quadro_e,qf_compilato_quadro_f,qf_compilazione_note,qf_doc_allegati,qf_note_aggiuntive,qf_sopralluogo_01_data,qf_sopralluogo_01_incaricato,qf_sopralluogo_02_data,qf_sopralluogo_02_incaricato,qf_sopralluogo_03_data,qf_sopralluogo_03_incaricato,qf_sopralluogo_04_data,qf_sopralluogo_04_incaricato FROM aim_sch_fasc_fabbricato_qf WHERE cod_content=#{map.cod_content_orig})";
				log.info("query di inserimento scheda digitale quadro F revisionato: " + ins_quadro_f);
				// eseguo query di inserimento 
				def ins_quadro_f_exe = services.queryService.executeQuery(ins_quadro_f, RevisionData);

				
				}; // chiuso IF copiatura schede digitali

				
			}; // chiuso IF database postgres
		
		
		
		// caso di database = SQL SERVER (chiave primaria record da identity)
		if (db_type=='SQLServer'){		
			// INSERIMENTO REVISIONE
			//definisco query per inserimento della revision nella tabella AIM_CONTENT
			def insertRevision = "INSERT INTO AIM_CONTENT (cod_content, cod_building, num_content, rev_content, cod_function, cod_position, content_class, cod_class_arc, cod_class_cat,cod_class_subcat, cod_class_type, author, internal_referent, descr_content, creation_date, content_area, status_approval, content_note,tenant_code, is_uploaded, single_insert, usergroup, cod_action_type, role_action, from_revision, is_blocked, is_invalid, is_approved, class_name,is_sch_complete,is_mandatory,is_risk,cod_permission_type,send_to_risk,is_send_to_risk)";
			insertRevision+="VALUES (#{map.cod_content},#{map.cod_building},#{map.num_content},#{map.rev_content},#{map.cod_function},#{map.cod_position},#{map.content_class},#{map.cod_class_arc},#{map.cod_class_cat},#{map.cod_class_subcat},#{map.cod_class_type},#{map.author},#{map.internal_referent},#{map.descr_content},#{map.creation_date},#{map.content_area},#{map.status_approval},#{map.content_note},#{map.tenant_code},#{map.is_uploaded},#{map.single_insert},#{map.usergroup},#{map.cod_action_type},#{map.role_action},#{map.from_revision},#{map.is_blocked},#{map.is_invalid},#{map.is_approved},#{map.class_name},#{map.is_sch_complete},#{map.is_mandatory},#{map.is_risk},#{map.cod_permission_type},#{map.send_to_risk},#{map.is_send_to_risk})";
			// eseguo query di inserimento della revisione nella tabella AIM_CONTENT
			def ins_rev = services.queryService.executeQuery(insertRevision,RevisionData);	
		
		
			// INSERIMENTO REVISIONE SU FILTRO DEI CONTENUTI
			// recupero i filtri di interesse
			def classFilterAll = services.queryService.executeQuery("SELECT * FROM V_AIM_BIM_FILTER WHERE  ((cod_class_filter=#{map.cod_class_arc} or cod_class_filter=#{map.cod_class_cat} or cod_class_filter is null) and  (cod_content_type is null or cod_content_type=#{map.cod_class_type}))",RevisionData);
			// ciclo l'inserimento
			for(int q=0;q<classFilterAll.size();q++){
				classFilterAll[q].cod_content=RevisionData.cod_content;	
				//predispongo l'inserimento dei record nella tabella AIM_BIM_FILTER_R_CONTENT
				def ContIns = "INSERT INTO aim_bim_filter_r_content (cod_bim_filter, cod_content)";
				ContIns+=" VALUES ";
				ContIns+="(#{map.cod_bim_filter},#{map.cod_content})";
				def ins_cont = services.queryService.executeQuery(ContIns,classFilterAll[q]);			
				};

			// INSERISCO REVISIONE NELLE TABELLE DI APPOGGIO DELLE FORME (DOC + GAL + SCH)

			//caso di forma del contenuto = DOC
			if(RevisionData.cod_class_type.equals('DOC')){
				RevisionData.file_path = RevisionData.cod_building + "/" + "DOC/" + RevisionData.cod_content;
				// definisco query di inserimento nella tabella delle forme
				def insertDoc = "INSERT INTO aim_content_doc (cod_content, file_path, tenant_code) VALUES (#{map.cod_content},#{map.file_path},#{map.tenant_code})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertDoc,RevisionData);
			};
			// caso di forma del contenuto = GAL
			if (RevisionData.cod_class_type.equals('GAL')){
				RevisionData.file_path = buildingCode + "/GAL/" + cod_content;
				// definisco query di inserimento nella tabella delle forme
				def insertGAL = "INSERT INTO aim_content_gal (cod_content, file_path) VALUES (#{map.cod_content}, #{map.file_path})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertGAL, RevisionData);			
				};
			// caso di forma del contenuto = SCH
			if (RevisionData.cod_class_type.equals('SCH')){
				// recupero chiave della classe della scheda digitale e colonna contenuto
				def info_sch = services.queryService.executeQuery("SELECT * FROM aim_content_sch WHERE cod_content='" + cod_content_orig + "'",null)[0];
				log.info("info scheda digitale di origine: " + info_sch);				
				// aggiungo chiave della classe della scheda digitale e colonna contenuto ai dati del contenuto revisionato 
				RevisionData.fk_sch_class = info_sch.fk_sch_class;
				log.info("classe scheda digitale: " + RevisionData.fk_sch_class);					
				RevisionData.sch_code_column = info_sch.sch_code_column;
				log.info("colonna contenuto: " + RevisionData.sch_code_column);
				// definisco query di inserimento nella tabella delle forme
				def insertSCH = "INSERT INTO aim_content_sch (cod_content,fk_sch_class,sch_code_column,sch_code,author,creation_date) VALUES (#{map.cod_content},#{map.fk_sch_class},#{map.sch_code_column},#{map.cod_content},#{map.author},#{map.creation_date})";
				// eseguo query di inserimento nella tabella delle forme
				def ins = services.queryService.executeQuery(insertSCH, RevisionData);			
				};


				// DA AGGIUNGERE, SE NECESSARIO, LE ISTRUZIONI PER LA DUPLICAZIONE DELLE SCHEDE DIGITALI SPECIFICHE

				
			};

	return true;
	}	
		
}
