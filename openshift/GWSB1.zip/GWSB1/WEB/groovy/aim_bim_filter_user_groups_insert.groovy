
import org.springframework.context.i18n.LocaleContextHolder;

public class BaseGroovyTrigger extends com.geowebframework.dataservice.querybuilder.EventTrigger {
    
    public boolean beforeInsert(HashMap<String,Object> valuesMap){
		
		String cod_bim_filter = valuesMap.get("cod_bim_filter");
		String username = valuesMap.get("username");
		String groups = valuesMap.get("groups");
		//controllo che non vengano associati stesso utente e stesso gruppo più di una volta
		def query = services.queryService.executeQuery("SELECT id_filter_user_group FROM AIM_BIM_FILTER_USER_GROUPS WHERE cod_bim_filter='"+cod_bim_filter+"' and username='"+username+"' and groups='"+groups+"'", null)[0];
		if(query!=null && query.size()>0){
			throw new RuntimeException("Attenzione: Associazione Utente Gruppo già in uso!");
		}
    };
    

    public boolean afterInsert(HashMap<String,Object> valuesMap){
			
        return true;
    };
    
    public boolean beforeUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){

		//CREAZIONE DI UNA TERZA MAPPA CHE PRENDE TUTTI I VALORI DELL'ATTRIBUTO!
		//SE TROVA VALORI NUOVI, PRENDE QUELLI, ALTRIMENTI PRENDE I VECCHI VALORI
		HashMap<String,Object> valuesMapAll = new HashMap<String,Object>();
		def team = services.queryService.executeQuery("SELECT * FROM AIM_BIM_FILTER_USER_GROUPS WHERE id_filter_user_group="+oldvaluesMap.id_filter_user_group, null)[0];
		valuesMapAll.putAll(team);
		valuesMapAll.putAll(valuesMap);		
		def cod_bim_filter = valuesMapAll.cod_bim_filter;
		def groups = valuesMapAll.groups;
		def username = valuesMapAll.username;
		def query = services.queryService.executeQuery("SELECT id_filter_user_group FROM AIM_BIM_FILTER_USER_GROUPS WHERE cod_bim_filter='"+cod_bim_filter+"' and groups='"+groups+"' and username='"+username+"'", null)[0];
			if(query!=null && query.size()>0){	
				throw new RuntimeException("Attenzione: Associazione Utente Gruppo già in uso!");
			}
		
		
        return true;
    };
    
    public boolean afterUpdate(HashMap<String,Object> valuesMap,HashMap<String,Object> oldvaluesMap){
		

		
        return true;
		
    };
    
    public boolean beforeDelete(HashMap<String,Object> valuesMap){

		
        return true;
    };
    
    public boolean afterDelete(HashMap<String,Object> valuesMap){
				
        return true;
    };

} 